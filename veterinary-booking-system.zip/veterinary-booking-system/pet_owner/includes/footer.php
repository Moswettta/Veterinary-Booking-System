</div> </div> <style>
    .po-footer-bar {
        background-color: #1e3d59;
        color: #a7bdd1;
        text-align: center;
        padding: 12px;
        font-size: 13px;
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 40px;
        z-index: 1000;
        border-top: 1px solid #13283b;
    }
</style>

<footer class="po-footer-bar">
    <p>&copy; <?php echo date('Y'); ?> Oakland Veterinary Clinic. All Rights Reserved.</p>
</footer>

</body>
</html>