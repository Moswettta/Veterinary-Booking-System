<style>
    .po-sidebar {
        width: 260px;
        background-color: #17b978; /* Vibrant hospital/medical green accent */
        position: fixed;
        top: 60px;
        bottom: 40px; /* Reserves breathing space for bottom footer layer */
        left: 0;
        padding-top: 25px;
        z-index: 999;
        box-shadow: 2px 0 5px rgba(0,0,0,0.05);
    }
    .sidebar-menu-list {
        list-style: none;
    }
    .menu-item {
        margin-bottom: 4px;
    }
    .menu-item a {
        display: block;
        color: #ffffff;
        text-decoration: none;
        padding: 14px 25px;
        font-weight: 500;
        font-size: 15px;
        border-left: 4px solid transparent;
        transition: all 0.2s ease;
    }
    .menu-item a:hover, .menu-item.active a {
        background-color: #119961;
        border-left-color: #ffc107; /* Clear amber highlight bar */
        padding-left: 30px;
    }
    .menu-section-lbl {
        padding: 10px 25px;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: #a7f3d0;
        font-weight: bold;
    }
</style>

<nav class="po-sidebar">
    <div class="menu-section-lbl">Client Workspace</div>
    <ul class="sidebar-menu-list">
        <li class="menu-item"><a href="dashboard.php">📊 Dashboard Overview</a></li>
        <li class="menu-item"><a href="manage_pets.php">🐾 My Registered Pets</a></li>
        <li class="menu-item"><a href="book_appointment.php">📅 Book Appointment</a></li>
        <li class="menu-item"><a href="history.php">📜 Medical Visit History</a></li>
    </ul>
</nav>