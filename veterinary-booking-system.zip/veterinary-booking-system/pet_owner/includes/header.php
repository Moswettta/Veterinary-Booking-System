<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Owner Dashboard | Veterinary Portal</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: #f4f6f9;
            min-height: 100vh;
        }
        
        /* Top Navigation Header bar */
        .po-header {
            background-color: #1e3d59; /* Solid deep corporate blue */
            color: #ffffff;
            height: 60px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        /* Left-aligned navigation cluster grouping brand and account actions */
        .header-left-cluster {
            display: flex;
            align-items: center;
            gap: 25px; /* Spacing between Brand, Profile and Logout links */
        }
        .clinic-brand {
            font-size: 18px;
            font-weight: 700;
            letter-spacing: 0.5px;
            color: #ffffff;
        }
        .account-actions {
            display: flex;
            align-items: center;
            gap: 15px;
            border-left: 1px solid #3a5a78;
            padding-left: 20px;
            font-size: 14px;
        }
        .account-actions a {
            color: #cbd5e1;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s ease;
        }
        .account-actions a:hover {
            color: #ffffff;
        }
        .account-actions .logout-link {
            color: #fca5a5; /* Distinct soft red color for visibility */
        }
        .account-actions .logout-link:hover {
            color: #ff6b6b;
        }

        /* Layout framework structures below fixed elements */
        .po-main-layout {
            display: flex;
            margin-top: 60px; /* Shifts viewport context directly below header */
            min-height: calc(100vh - 100px); /* Adjusts height avoiding footer overlaps */
        }
        .po-workspace-content {
            flex: 1;
            margin-left: 260px; /* Provides precise margin to skip fixed sidebar */
            padding: 35px;
            padding-bottom: 60px;
        }
    </style>
</head>
<body>

    <header class="po-header" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; background-color: #0f172a;">

    <div class="clinic-brand" style="color: white; font-size: 22px; font-weight: bold;">
        Oakland Vet Clinic
    </div>

    <div class="account-actions" style="display: flex; gap: 20px; margin-left: auto;">

        <a href="profile.php" 
           style="text-decoration: none; color: white; font-weight: 600;">
            👤 My Profile
        </a>

        <a href="../logout.php" 
           class="logout-link"
           style="text-decoration: none; color: #ff4d4d; font-weight: 600;">
            🚪 Log Out
        </a>

    </div>

</header>

    <div class="po-main-layout">