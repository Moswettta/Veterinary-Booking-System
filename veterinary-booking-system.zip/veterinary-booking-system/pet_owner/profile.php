<?php
// Start session to identify the logged-in Pet Owner
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated (using fallback mock session for testing)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pet_owner') {
    $_SESSION['user_id'] = 1; 
    $_SESSION['role'] = 'pet_owner';
}

$user_id = $_SESSION['user_id'];

// Ingest secure database config connection
require_once('../config/db.php');

$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// POST ACTIONS: Handle Profile or Password Updates
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // ACTION 1: UPDATE GENERAL PROFILE INFO
    if (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);

        if (!empty($username) && !empty($email)) {
            try {
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, phone = ? WHERE user_id = ?");
                $stmt->execute([$username, $email, $phone, $user_id]);
                
                // Update active session name variable
                $_SESSION['username'] = $username;
                
                $message = "👤 Profile personal details updated successfully!";
                $message_class = "msg-success";
            } catch (PDOException $e) {
                $message = "Error updating profile details: " . $e->getMessage();
                $message_class = "msg-danger";
            }
        } else {
            $message = "Username and Email fields cannot be left empty.";
            $message_class = "msg-danger";
        }
    }

    // ACTION 2: UPDATE ACCOUNT PASSWORD SECURELY
    if (isset($_POST['action']) && $_POST['action'] === 'update_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
            if ($new_password !== $confirm_password) {
                $message = "⚠️ New passwords do not match. Please re-enter.";
                $message_class = "msg-danger";
            } else {
                try {
                    // Fetch current password hash from database
                    $pwd_stmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
                    $pwd_stmt->execute([$user_id]);
                    $user_hash = $pwd_stmt->fetchColumn();

                    // Verify current password matches database records
                    if (password_verify($current_password, $user_hash)) {
                        // Hash the new password securely
                        $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
                        
                        $update_pwd = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                        $update_pwd->execute([$new_hash, $user_id]);
                        
                        $message = "🔒 Password changed successfully!";
                        $message_class = "msg-success";
                    } else {
                        $message = "❌ Incorrect current password. Changes rejected.";
                        $message_class = "msg-danger";
                    }
                } catch (PDOException $e) {
                    $message = "Error updating security keys: " . $e->getMessage();
                    $message_class = "msg-danger";
                }
            }
        } else {
            $message = "Please complete all password input blocks.";
            $message_class = "msg-danger";
        }
    }
}

// -------------------------------------------------------------------------
// READ ACTION: Dynamic Fetch of Latest Account Details
// -------------------------------------------------------------------------
try {
    $user_stmt = $pdo->prepare("SELECT username, email, phone FROM users WHERE user_id = ?");
    $user_stmt->execute([$user_id]);
    $user_data = $user_stmt->fetch();
} catch (PDOException $e) {
    $user_data = ['username' => 'User', 'email' => '', 'phone' => ''];
}

// Ingest local independent layout wrappers
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="po-workspace-content">
    
    <style>
        .profile-container {
            max-width: 1100px;
            margin: 0 auto;
        }
        .page-title {
            color: #1e3d59;
            margin-bottom: 25px;
            font-size: 24px;
        }
        
        /* Grid split logic separating profile information vs credentials updating */
        .profile-grid-split {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }
        .profile-card-block {
            flex: 1;
            min-width: 340px;
            background-color: #ffffff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.04);
            border: 1px solid #e2e8f0;
            height: fit-content;
        }
        .card-heading {
            color: #1e3d59;
            margin-bottom: 20px;
            font-size: 18px;
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 10px;
        }

        /* Form Styling Core configurations */
        .form-group {
            margin-bottom: 18px;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
            font-weight: 600;
            color: #475569;
        }
        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            color: #334155;
            background-color: #ffffff;
            transition: border-color 0.2s;
        }
        .form-control:focus {
            outline: none;
            border-color: #17b978;
        }
        
        .update-submit-btn {
            background-color: #17b978;
            color: #ffffff;
            border: none;
            padding: 11px 18px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            font-size: 14px;
            transition: background 0.2s;
        }
        .update-submit-btn:hover {
            background-color: #119961;
        }
        .update-submit-btn.blue-btn {
            background-color: #1e3d59;
        }
        .update-submit-btn.blue-btn:hover {
            background-color: #13283b;
        }

        /* Status Alert Panels */
        .alert-banner {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 25px;
            font-size: 14px;
            font-weight: 500;
        }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
    </style>

    <div class="profile-container">
        <h2 class="page-title">Account Settings</h2>

        <?php if (!empty($message)): ?>
            <div class="alert-banner <?php echo $message_class; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="profile-grid-split">
            
            <div class="profile-card-block">
                <h3 class="card-heading">Personal Details</h3>
                <form action="profile.php" method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-group">
                        <label for="username">Full Name *</label>
                        <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($user_data['username']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" id="phone" name="phone" class="form-control" value="<?php echo htmlspecialchars($user_data['phone'] ?: ''); ?>" placeholder="e.g., +254 700 000000">
                    </div>

                    <button type="submit" class="update-submit-btn">💾 Save Personal Changes</button>
                </form>
            </div>

            <div class="profile-card-block">
                <h3 class="card-heading">Security Credentials</h3>
                <form action="profile.php" method="POST">
                    <input type="hidden" name="action" value="update_password">
                    
                    <div class="form-group">
                        <label for="current_password">Current Password *</label>
                        <input type="password" id="current_password" name="current_password" class="form-control" placeholder="••••••••" required>
                    </div>

                    <div class="form-group">
                        <label for="new_password">New Secure Password *</label>
                        <input type="password" id="new_password" name="new_password" class="form-control" placeholder="••••••••" required>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password *</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="••••••••" required>
                    </div>

                    <button type="submit" class="update-submit-btn blue-btn">🔒 Update Account Password</button>
                </form>
            </div>

        </div>
    </div>

</div> <?php 
// Pull in the local footer frame block cleanly
include('includes/footer.php'); 
?>