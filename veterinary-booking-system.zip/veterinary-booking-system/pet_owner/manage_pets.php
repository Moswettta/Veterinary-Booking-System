<?php
// Start session to identify the logged-in Pet Owner
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated (using fallback mock session for testing)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pet_owner') {
    $_SESSION['user_id'] = 1; 
    $_SESSION['role'] = 'pet_owner';
}

$user_id = $_SESSION['user_id'];

// Ingest secure database config connection
require_once('../config/db.php');

$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// POST ACTIONS: Handle Form Submissions (Add, Update, Delete)
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // ACTION 1: ADD NEW PET
    if (isset($_POST['action']) && $_POST['action'] === 'add_pet') {
        $pet_name = trim($_POST['pet_name']);
        $species = trim($_POST['species']);
        $breed = trim($_POST['breed']);
        $age = intval($_POST['age']);

        if (!empty($pet_name) && !empty($species)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO pets (owner_id, pet_name, species, breed, age) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $pet_name, $species, $breed, $age]);
                $message = "🐾 Pet profile created successfully!";
                $message_class = "msg-success";
            } catch (PDOException $e) {
                $message = "Error adding pet: " . $e->getMessage();
                $message_class = "msg-danger";
            }
        } else {
            $message = "Please complete all required fields.";
            $message_class = "msg-danger";
        }
    }

    // ACTION 2: DELETE PET profile
    if (isset($_POST['action']) && $_POST['action'] === 'delete_pet') {
        $pet_id = intval($_POST['pet_id']);
        try {
            // Verify ownership before deleting
            $stmt = $pdo->prepare("DELETE FROM pets WHERE pet_id = ? AND owner_id = ?");
            $stmt->execute([$pet_id, $user_id]);
            $message = "Pet record removed successfully.";
            $message_class = "msg-success";
        } catch (PDOException $e) {
            $message = "Could not delete pet record: " . $e->getMessage();
            $message_class = "msg-danger";
        }
    }
}

// -------------------------------------------------------------------------
// READ ACTION: Fetch current pet collection to display in table
// -------------------------------------------------------------------------
try {
    $fetch_stmt = $pdo->prepare("SELECT * FROM pets WHERE owner_id = ? ORDER BY pet_id DESC");
    $fetch_stmt->execute([$user_id]);
    $my_pets = $fetch_stmt->fetchAll();
} catch (PDOException $e) {
    $my_pets = [];
}

// Ingest local independent layouts
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="po-workspace-content">
    
    <style>
        .page-container {
            max-width: 1100px;
            margin: 0 auto;
        }
        .page-title {
            color: #1e3d59;
            margin-bottom: 25px;
            font-size: 24px;
        }
        
        /* Layout split: Form on Left, Registered Table on Right */
        .workspace-split {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }
        .form-panel {
            flex: 1;
            min-width: 320px;
            background-color: #ffffff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.04);
            border: 1px solid #e2e8f0;
            height: fit-content;
        }
        .table-panel {
            flex: 2;
            min-width: 450px;
            background-color: #ffffff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.04);
            border: 1px solid #e2e8f0;
        }
        
        .panel-heading {
            color: #1e3d59;
            margin-bottom: 15px;
            font-size: 18px;
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 8px;
        }

        /* Form Controls Setup */
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
            font-weight: 600;
            color: #475569;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.2s;
        }
        .form-control:focus {
            outline: none;
            border-color: #17b978;
        }
        
        .save-btn {
            background-color: #17b978;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            font-size: 14px;
            transition: background 0.2s;
        }
        .save-btn:hover {
            background-color: #119961;
        }

        /* Responsive Data Table Styles */
        .pets-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 14px;
        }
        .pets-table th {
            background-color: #f8fafc;
            color: #64748b;
            padding: 12px;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }
        .pets-table td {
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
            color: #334155;
        }
        .no-data-msg {
            text-align: center;
            padding: 30px;
            color: #94a3b8;
            font-style: italic;
        }

        /* Alert System Banners */
        .alert-banner {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
        }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

        .delete-inline-btn {
            background: none;
            border: none;
            color: #ef4444;
            font-weight: 600;
            cursor: pointer;
            font-size: 13px;
        }
        .delete-inline-btn:hover {
            text-decoration: underline;
        }
    </style>

    <div class="page-container">
        <h2 class="page-title">Manage Pet Profiles</h2>

        <?php if (!empty($message)): ?>
            <div class="alert-banner <?php echo $message_class; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="workspace-split">
            
            <div class="form-panel">
                <h3 class="panel-heading">Add New Patient Pet</h3>
                <form action="manage_pets.php" method="POST">
                    <input type="hidden" name="action" value="add_pet">
                    
                    <div class="form-group">
                        <label for="pet_name">Pet Name *</label>
                        <input type="text" id="pet_name" name="pet_name" class="form-control" placeholder="e.g., Max" required>
                    </div>

                    <div class="form-group">
                        <label for="species">Species Category *</label>
                        <select id="species" name="species" class="form-control" required>
                            <option value="">-- Select Type --</option>
                            <option value="Dog">Dog (Canine)</option>
                            <option value="Cat">Cat (Feline)</option>
                            <option value="Bird">Bird (Avian)</option>
                            <option value="Other">Other Species</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="breed">Breed Identification</label>
                        <input type="text" id="breed" name="breed" class="form-control" placeholder="e.g., German Shepherd">
                    </div>

                    <div class="form-group">
                        <label for="age">Age (Years)</label>
                        <input type="number" id="age" name="age" class="form-control" min="0" max="40" placeholder="e.g., 3">
                    </div>

                    <button type="submit" class="save-btn">🐾 Add Pet Record</button>
                </form>
            </div>

            <div class="table-panel">
                <h3 class="panel-heading">My Registered Pets</h3>
                
                <?php if (count($my_pets) > 0): ?>
                    <table class="pets-table">
                        <thead>
                            <tr>
                                <th>Pet Name</th>
                                <th>Species</th>
                                <th>Breed</th>
                                <th>Age (Yrs)</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($my_pets as $pet): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($pet['pet_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($pet['species']); ?></td>
                                    <td><?php echo htmlspecialchars($pet['breed'] ?: 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($pet['age']); ?></td>
                                    <td>
                                        <form action="manage_pets.php" method="POST" onsubmit="return confirm('Remove this pet profile permanently?');" style="display:inline;">
                                            <input type="hidden" name="action" value="delete_pet">
                                            <input type="hidden" name="pet_id" value="<?php echo $pet['pet_id']; ?>">
                                            <button type="submit" class="delete-inline-btn">❌ Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-data-msg">No pets registered yet. Add a pet profile on the left panel to begin booking appointments!</div>
                <?php endif; ?>
            </div>

        </div>
    </div>

</div> <?php 
// Close global body markup and render localized sticky footer block
include('includes/footer.php'); 
?>