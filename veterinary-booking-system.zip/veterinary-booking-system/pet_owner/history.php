<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pet_owner') {
    header("Location: ../login.php");
    exit;
}

require_once('../config/db.php');
$user_id = $_SESSION['user_id'];

try {
    // Fetches appointment details, joined with treatment records and status info
    $sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.reason, a.status, 
                   a.cancellation_reason, p.pet_name, p.species, u.full_name AS vet_name,
                   tr.diagnosis, tr.treatment, tr.follow_up_date
            FROM appointments a
            JOIN pets p ON a.pet_id = p.pet_id
            JOIN users u ON a.vet_id = u.user_id
            LEFT JOIN treatment_records tr ON a.appointment_id = tr.appointment_id
            WHERE p.owner_id = ?
            ORDER BY a.appointment_date DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $history = [];
}

include('includes/header.php');
include('includes/sidebar.php');
?>

<style>
    .content-area { margin-left: 260px; padding: 40px; background-color: #f8fafc; min-height: 100vh; }
    .history-card { background: #fff; padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
    
    .badge { padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
    .status-completed { background: #dcfce7; color: #166534; }
    .status-pending { background: #fef3c7; color: #92400e; }
    .status-cancelled { background: #fee2e2; color: #991b1b; }
    
    .clinical-box { background: #f1f5f9; padding: 15px; border-radius: 6px; margin-top: 15px; border-left: 4px solid #3b82f6; }
    .cancellation-box { background: #fef2f2; padding: 15px; border-radius: 6px; margin-top: 15px; border-left: 4px solid #ef4444; }
    
    .clinical-label { color: #475569; font-weight: 700; font-size: 11px; text-transform: uppercase; display: block; margin-bottom: 4px; }
    .clinical-text { color: #1e293b; font-size: 14px; margin-bottom: 12px; }
</style>

<div class="content-area">
    <h2>My Appointment History</h2>

    <?php if (empty($history)): ?>
        <p>You have no appointment records yet.</p>
    <?php else: ?>
        <?php foreach ($history as $row): ?>
            <div class="history-card">
                <div style="display:flex; justify-content:space-between; align-items: start;">
                    <div>
                        <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong> (<?php echo htmlspecialchars($row['species']); ?>)
                        <br><small style="color: #64748b;">Dr. <?php echo htmlspecialchars($row['vet_name']); ?> • <?php echo htmlspecialchars($row['appointment_date']); ?></small>
                    </div>
                    <span class="badge status-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span>
                </div>

                <?php if ($row['status'] === 'completed' && !empty($row['diagnosis'])): ?>
                    <div class="clinical-box">
                        <span class="clinical-label">Verified Diagnosis Findings</span>
                        <div class="clinical-text"><?php echo htmlspecialchars($row['diagnosis']); ?></div>
                        
                        <span class="clinical-label">Administered Treatment Interventions</span>
                        <div class="clinical-text"><?php echo htmlspecialchars($row['treatment']); ?></div>
                        
                        <span class="clinical-label">📅 Follow-Up Threshold</span>
                        <div class="clinical-text"><?php echo !empty($row['follow_up_date']) ? htmlspecialchars($row['follow_up_date']) : 'None'; ?></div>
                    </div>
                <?php endif; ?>

                <?php if ($row['status'] === 'cancelled' && !empty($row['cancellation_reason'])): ?>
                    <div class="cancellation-box">
                        <span class="clinical-label" style="color: #991b1b;">Reason for Cancellation</span>
                        <div class="clinical-text" style="margin-bottom: 0;"><?php echo htmlspecialchars($row['cancellation_reason']); ?></div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include('includes/footer.php'); ?>