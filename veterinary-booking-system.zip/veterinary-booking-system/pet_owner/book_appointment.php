<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pet_owner') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
require_once('../config/db.php');

$message = "";
$message_class = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book_appointment') {
    $pet_id = intval($_POST['pet_id']);
    $vet_id = intval($_POST['vet_id']);
    $date = $_POST['appointment_date'];
    $time = $_POST['appointment_time'];
    $reason = trim($_POST['reason']);

    try {
        $insert_sql = "INSERT INTO appointments (pet_id, vet_id, appointment_date, appointment_time, reason, status) VALUES (?, ?, ?, ?, ?, 'pending')";
        $stmt = $pdo->prepare($insert_sql);
        $stmt->execute([$pet_id, $vet_id, $date, $time, $reason]);
        $message = "📅 Appointment requested successfully!";
        $message_class = "msg-success";
    } catch (PDOException $e) {
        $message = "Booking failed: " . $e->getMessage();
        $message_class = "msg-danger";
    }
}

$pets = $pdo->prepare("SELECT pet_id, pet_name FROM pets WHERE owner_id = ?");
$pets->execute([$user_id]);
$my_pets = $pets->fetchAll();

$vets = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'vet'")->fetchAll();

include('includes/header.php');
include('includes/sidebar.php');
?>

<style>
    /* Internal CSS Module for Booking Interface */
    .booking-wrapper { max-width: 600px; margin: 40px auto; background: #ffffff; padding: 30px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
    .page-header { margin-bottom: 25px; border-bottom: 2px solid #f1f5f9; padding-bottom: 15px; }
    .page-header h2 { color: #0f172a; margin: 0; }
    
    .form-group { margin-bottom: 20px; }
    .form-group label { display: block; font-weight: 600; color: #475569; margin-bottom: 8px; font-size: 14px; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 6px; box-sizing: border-box; }
    
    .btn-book { width: 100%; background: #10b981; color: white; border: none; padding: 14px; border-radius: 6px; font-weight: 700; cursor: pointer; transition: 0.2s; }
    .btn-book:hover { background: #059669; }
    
    .msg-success { padding: 15px; background: #d1fae5; color: #065f46; border-radius: 6px; margin-bottom: 20px; }
    .msg-danger { padding: 15px; background: #fee2e2; color: #991b1b; border-radius: 6px; margin-bottom: 20px; }
</style>

<div class="booking-wrapper">
    <div class="page-header">
        <h2>Book a Consultation</h2>
    </div>

    <?php if ($message): ?>
        <div class="<?php echo $message_class; ?>"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="action" value="book_appointment">
        
        <div class="form-group">
            <label>Patient (Pet)</label>
            <select name="pet_id" class="form-control" required>
                <?php foreach ($my_pets as $p): ?>
                    <option value="<?php echo $p['pet_id']; ?>"><?php echo htmlspecialchars($p['pet_name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Veterinarian</label>
            <select name="vet_id" class="form-control" required>
                <?php foreach ($vets as $v): ?>
                    <option value="<?php echo $v['user_id']; ?>">Dr. <?php echo htmlspecialchars($v['full_name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Date</label>
            <input type="date" name="appointment_date" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Time</label>
            <input type="time" name="appointment_time" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Reason for Visit</label>
            <textarea name="reason" class="form-control" rows="4" required></textarea>
        </div>

        <button type="submit" class="btn-book">Confirm Booking Request</button>
    </form>
</div>

<?php include('includes/footer.php'); ?>