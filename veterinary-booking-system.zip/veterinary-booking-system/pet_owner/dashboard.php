<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pet_owner') {
    header("Location: ../login.php"); exit;
}

require_once('../config/db.php');
$user_id = $_SESSION['user_id'];

// FIX: Ensure we have the user's name
if (!isset($_SESSION['full_name'])) {
    $stmt = $pdo->prepare("SELECT full_name FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $_SESSION['full_name'] = $stmt->fetchColumn() ?: 'Valued Client';
}

// Stats and Appointments Query
// ... (Your existing $stats and $upcoming queries remain the same)
$stats = $pdo->prepare("SELECT 
    (SELECT COUNT(*) FROM pets WHERE owner_id = ?) as total_pets,
    (SELECT COUNT(*) FROM appointments a JOIN pets p ON a.pet_id = p.pet_id WHERE p.owner_id = ?) as total_appts,
    (SELECT COUNT(*) FROM appointments a JOIN pets p ON a.pet_id = p.pet_id WHERE p.owner_id = ? AND a.status = 'cancelled') as cancelled_appts");
$stats->execute([$user_id, $user_id, $user_id]);
$data = $stats->fetch(PDO::FETCH_ASSOC);

$upcoming = $pdo->prepare("SELECT a.appointment_date, a.reason, p.pet_name FROM appointments a JOIN pets p ON a.pet_id = p.pet_id WHERE p.owner_id = ? AND a.status = 'pending' ORDER BY a.appointment_date ASC LIMIT 3");
$upcoming->execute([$user_id]);
$appts = $upcoming->fetchAll(PDO::FETCH_ASSOC);

include('includes/header.php');
include('includes/sidebar.php');
?>

<style>
    /* Main Content Area */
    .content-area { 
        margin-left: 260px; 
        padding: 40px; 
        background-color: #f8fafc; 
        min-height: 100vh; 
        font-family: 'Segoe UI', system-ui, sans-serif;
    }

    /* Dashboard Header */
    .page-header { margin-bottom: 30px; }
    .page-header h2 { font-size: 28px; color: #1e293b; margin: 0; }
    .page-header p { color: #64748b; margin-top: 5px; }

    /* Stats Grid */
    .stats-grid { 
        display: grid; 
        grid-template-columns: repeat(3, 1fr); 
        gap: 20px; 
        margin-bottom: 30px; 
    }
    .stat-card { 
        background: #ffffff; 
        padding: 25px; 
        border-radius: 12px; 
        border: 1px solid #e2e8f0; 
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .stat-val { font-size: 32px; font-weight: 800; color: #0f172a; display: block; }
    .stat-lbl { font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px; }

    /* Main Grid Layout */
    .main-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
    .card { background: #ffffff; padding: 30px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
    .card h3 { margin: 0 0 20px 0; font-size: 18px; color: #1e293b; }

    /* Button Styling */
    .btn-action { 
        display: block; 
        width: 100%; 
        padding: 14px; 
        background: #2563eb; 
        color: white; 
        text-align: center; 
        border-radius: 8px; 
        text-decoration: none; 
        font-weight: 600; 
        transition: background 0.2s;
    }
    .btn-action:hover { background: #1d4ed8; }
</style>

<div class="content-area">
    <div class="page-header">
        <h2>Dashboard</h2>
        <p>Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>. Here is your practice summary.</p>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">🐾</div>
            <div><span class="stat-val"><?php echo $data['total_pets']; ?></span><br><span class="stat-lbl">Pets Registered</span></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">📅</div>
            <div><span class="stat-val"><?php echo $data['total_appts']; ?></span><br><span class="stat-lbl">Total Bookings</span></div>
        </div>
        <div class="stat-card" style="border-left: 4px solid #ef4444;">
            <div class="stat-icon">🚫</div>
            <div><span class="stat-val"><?php echo $data['cancelled_appts']; ?></span><br><span class="stat-lbl">Cancelled</span></div>
        </div>
    </div>

    <div class="main-grid">
        <div class="card">
            <h3>Upcoming Consultations</h3>
            <?php if ($appts): ?>
                <ul class="appt-list">
                    <?php foreach ($appts as $a): ?>
                        <li class="appt-item">
                            <div><strong><?php echo htmlspecialchars($a['pet_name']); ?></strong><br><small><?php echo htmlspecialchars($a['reason']); ?></small></div>
                            <div style="text-align: right; color: var(--text-light); font-size: 14px;"><?php echo $a['appointment_date']; ?></div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="color:var(--text-light)">No upcoming sessions.</p>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>Quick Actions</h3>
            <p style="color:var(--text-light); font-size: 14px;">Need help? You can book a new session or check your past records.</p>
            <a href="book_appointment.php" class="btn-primary">Book New Session</a>
            <a href="history.php" style="display:block; margin-top:15px; text-align:center; color:var(--primary); font-size:14px; font-weight:600;">View History</a>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>