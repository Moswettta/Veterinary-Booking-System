<?php
// Start session to check if a user is already logged in
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Oakland Veterinary Clinic</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            scroll-behavior:smooth;
        }

        :root{
            --primary:#0f172a;
            --secondary:#1e293b;
            --accent:#10b981;
            --light:#f8fafc;
            --muted:#64748b;
            --white:#ffffff;
            --border:#e2e8f0;
        }

        body{
            font-family:'Poppins',sans-serif;
            background:var(--light);
            color:var(--primary);
            overflow-x:hidden;
        }

        /* ================= NAVBAR ================= */

        .navbar{
            width:100%;
            height:75px;
            background:rgba(255,255,255,0.95);
            backdrop-filter:blur(10px);
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:0 8%;
            position:fixed;
            top:0;
            left:0;
            z-index:1000;
            border-bottom:1px solid rgba(226,232,240,0.7);
        }

        .nav-logo{
            display:flex;
            align-items:center;
            gap:10px;
            font-size:24px;
            font-weight:700;
            color:var(--primary);
        }

        .nav-logo span{
            font-size:30px;
        }

        .nav-links{
            display:flex;
            align-items:center;
            gap:30px;
            list-style:none;
        }

        .nav-links a{
            text-decoration:none;
            color:var(--muted);
            font-size:15px;
            font-weight:500;
            transition:0.3s;
        }

        .nav-links a:hover{
            color:var(--accent);
        }

        .portal-btn{
            background:var(--accent);
            color:var(--white) !important;
            padding:12px 22px;
            border-radius:10px;
            box-shadow:0 10px 20px rgba(16,185,129,0.2);
            transition:0.3s;
        }

        .portal-btn:hover{
            transform:translateY(-2px);
            background:#0da271;
        }

        /* ================= HERO ================= */

        .hero-section{
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:120px 8% 80px;
            background:
            radial-gradient(circle at top left, rgba(16,185,129,0.08), transparent 30%),
            radial-gradient(circle at bottom right, rgba(30,41,59,0.08), transparent 30%),
            linear-gradient(to right, #f8fafc, #eef2f7);
            gap:50px;
        }

        .hero-content{
            flex:1;
        }

        .hero-badge{
            display:inline-block;
            background:#dcfce7;
            color:#15803d;
            padding:8px 18px;
            border-radius:30px;
            font-size:13px;
            font-weight:600;
            margin-bottom:25px;
        }

        .hero-content h1{
            font-size:58px;
            line-height:1.1;
            margin-bottom:25px;
            color:var(--primary);
        }

        .hero-content p{
            font-size:18px;
            line-height:1.8;
            color:var(--muted);
            margin-bottom:35px;
            max-width:650px;
        }

        .hero-buttons{
            display:flex;
            gap:20px;
            flex-wrap:wrap;
        }

        .cta-btn{
            text-decoration:none;
            padding:15px 28px;
            border-radius:12px;
            font-weight:600;
            transition:0.3s;
        }

        .primary-btn{
            background:var(--accent);
            color:white;
            box-shadow:0 12px 24px rgba(16,185,129,0.25);
        }

        .primary-btn:hover{
            transform:translateY(-3px);
            background:#0da271;
        }

        .secondary-btn{
            border:2px solid var(--border);
            color:var(--primary);
            background:white;
        }

        .secondary-btn:hover{
            border-color:var(--accent);
            color:var(--accent);
        }

        .hero-graphic{
            flex:1;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .hero-card{
            width:380px;
            height:380px;
            background:white;
            border-radius:35px;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:160px;
            box-shadow:0 30px 60px rgba(15,23,42,0.08);
            border:1px solid rgba(255,255,255,0.6);
            animation:float 4s ease-in-out infinite;
        }

        @keyframes float{
            0%{ transform:translateY(0px);}
            50%{ transform:translateY(-12px);}
            100%{ transform:translateY(0px);}
        }

        /* ================= SERVICES ================= */

        .services-section{
            padding:100px 8%;
            background:white;
        }

        .section-header{
            text-align:center;
            margin-bottom:60px;
        }

        .section-title{
            font-size:42px;
            color:var(--primary);
            margin-bottom:15px;
        }

        .section-subtitle{
            color:var(--muted);
            max-width:700px;
            margin:auto;
            line-height:1.7;
        }

        .services-grid{
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
            gap:30px;
        }

        .service-card{
            background:linear-gradient(to bottom right,#ffffff,#f8fafc);
            border:1px solid var(--border);
            border-radius:22px;
            padding:40px 30px;
            transition:0.4s ease;
            position:relative;
            overflow:hidden;
        }

        .service-card::before{
            content:'';
            position:absolute;
            width:100%;
            height:5px;
            background:var(--accent);
            top:0;
            left:0;
            transform:scaleX(0);
            transition:0.4s;
        }

        .service-card:hover::before{
            transform:scaleX(1);
        }

        .service-card:hover{
            transform:translateY(-10px);
            box-shadow:0 20px 40px rgba(15,23,42,0.08);
        }

        .service-icon{
            width:70px;
            height:70px;
            border-radius:18px;
            background:#ecfdf5;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:32px;
            margin-bottom:25px;
        }

        .service-card h3{
            font-size:22px;
            margin-bottom:15px;
            color:var(--primary);
        }

        .service-card p{
            color:var(--muted);
            line-height:1.8;
            font-size:15px;
        }

        /* ================= STATS ================= */

        .stats-section{
            padding:70px 8%;
            background:var(--primary);
        }

        .stats-grid{
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
            gap:30px;
            text-align:center;
        }

        .stat-box h2{
            font-size:42px;
            color:white;
            margin-bottom:10px;
        }

        .stat-box p{
            color:#cbd5e1;
            font-size:15px;
        }

        /* ================= FOOTER ================= */

        .public-footer{
            background:#020617;
            color:#cbd5e1;
            padding:60px 8% 20px;
        }

        .footer-info{
            display:flex;
            justify-content:space-between;
            flex-wrap:wrap;
            gap:40px;
            padding-bottom:30px;
            border-bottom:1px solid rgba(255,255,255,0.08);
            margin-bottom:25px;
        }

        .footer-logo{
            font-size:24px;
            font-weight:700;
            color:white;
            margin-bottom:10px;
        }

        .footer-text{
            max-width:400px;
            line-height:1.8;
            color:#94a3b8;
        }

        .footer-contact p{
            margin-bottom:10px;
            color:#cbd5e1;
        }

        .copyright{
            text-align:center;
            font-size:14px;
            color:#94a3b8;
        }

        /* ================= RESPONSIVE ================= */

        @media(max-width:950px){

            .hero-section{
                flex-direction:column;
                text-align:center;
                padding-top:140px;
            }

            .hero-content h1{
                font-size:42px;
            }

            .hero-buttons{
                justify-content:center;
            }

            .hero-card{
                width:300px;
                height:300px;
                font-size:120px;
            }

            .footer-info{
                flex-direction:column;
                text-align:center;
            }
        }

        @media(max-width:768px){

            .navbar{
                padding:0 5%;
            }

            .nav-links{
                gap:15px;
            }

            .nav-links a{
                font-size:13px;
            }

            .hero-content h1{
                font-size:34px;
            }

            .section-title{
                font-size:32px;
            }
        }

    </style>
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar">

        <div class="nav-logo">
            <span>🐾</span>
            Oakland Vet Clinic
        </div>

        <ul class="nav-links">
            <li><a href="#services">Services</a></li>
            <li><a href="#about">About</a></li>

            <?php if (isset($_SESSION['user_id']) && isset($_SESSION['role'])): ?>

                <li>
                    <a href="<?php echo htmlspecialchars($_SESSION['role']); ?>/dashboard.php" class="portal-btn">
                        Dashboard
                    </a>
                </li>

            <?php else: ?>

                <li>
                    <a href="login.php" class="portal-btn">
                        Login Portal
                    </a>
                </li>

            <?php endif; ?>
        </ul>

    </nav>

    <!-- HERO -->
    <section class="hero-section">

        <div class="hero-content">

            <div class="hero-badge">
                Trusted Veterinary Care in Nairobi
            </div>

            <h1>
                Professional Healthcare For Your Pets & Animal Companions
            </h1>

            <p>
                Oakland Veterinary Clinic delivers modern animal healthcare services,
                online appointment scheduling, emergency treatment, vaccinations,
                diagnostics, and compassionate care for every pet.
            </p>

            <div class="hero-buttons">

                <a href="login.php" class="cta-btn primary-btn">
                    📅 Book Appointment
                </a>

                <a href="#services" class="cta-btn secondary-btn">
                    Explore Services
                </a>

            </div>

        </div>

        <div class="hero-graphic">

            <div class="hero-card">
                🐕‍🦺
            </div>

        </div>

    </section>

    <!-- SERVICES -->
    <section class="services-section" id="services">

        <div class="section-header">
            <h2 class="section-title">Veterinary Services</h2>

            <p class="section-subtitle">
                We provide modern, compassionate, and professional veterinary
                solutions designed to keep your pets healthy, active, and safe.
            </p>
        </div>

        <div class="services-grid">

            <div class="service-card">

                <div class="service-icon">🩺</div>

                <h3>Routine Checkups</h3>

                <p>
                    Comprehensive wellness examinations, nutrition guidance,
                    preventive treatment plans, and regular health monitoring.
                </p>

            </div>

            <div class="service-card">

                <div class="service-icon">💉</div>

                <h3>Vaccination Programs</h3>

                <p>
                    Customized vaccination schedules and booster programs to
                    protect pets from dangerous diseases and infections.
                </p>

            </div>

            <div class="service-card">

                <div class="service-icon">⚡</div>

                <h3>Emergency Care</h3>

                <p>
                    Fast emergency response, surgical support, trauma care,
                    and real-time monitoring by experienced specialists.
                </p>

            </div>

        </div>

    </section>

    <!-- STATS -->
    <section class="stats-section">

        <div class="stats-grid">

            <div class="stat-box">
                <h2>5K+</h2>
                <p>Pets Treated</p>
            </div>

            <div class="stat-box">
                <h2>24/7</h2>
                <p>Emergency Support</p>
            </div>

            <div class="stat-box">
                <h2>12+</h2>
                <p>Veterinary Experts</p>
            </div>

            <div class="stat-box">
                <h2>98%</h2>
                <p>Client Satisfaction</p>
            </div>

        </div>

    </section>

    <!-- FOOTER -->
    <footer class="public-footer" id="about">

        <div class="footer-info">

            <div>
                <div class="footer-logo">
                    🐾 Oakland Veterinary Clinic
                </div>

                <p class="footer-text">
                    Delivering compassionate and advanced veterinary healthcare
                    solutions for pets across Nairobi and surrounding regions.
                </p>
            </div>

            <div class="footer-contact">
                <p>📍 Nairobi, Kenya</p>
                <p>📞 +254 700 000 000</p>
                <p>✉️ support@oaklandvet.com</p>
            </div>

        </div>

        <div class="copyright">
            &copy; <?php echo date('Y'); ?>
            Oakland Veterinary Booking System. All Rights Reserved.
        </div>

    </footer>

</body>
</html>