<?php
// 1. Initialize the session framework
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Unset all session variables associated with the logged-in user
$_SESSION = array();

// 3. If cookies are used to track the session, invalidate them completely
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// 4. Destroy the session register on the server side
session_destroy();

// 5. Securely redirect back to the central login gateway or marketing homepage
header("Location: login.php");
exit;
?>