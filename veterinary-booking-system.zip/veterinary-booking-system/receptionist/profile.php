<?php
// ============================================
// SESSION & SECURITY
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is a logged-in receptionist
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    header("Location: ../login.php");
    exit;
}

require_once('../config/db.php');
$user_id = $_SESSION['user_id'];

// Fetch Profile Data
$stmt = $pdo->prepare("SELECT full_name, email, phone, role, created_at FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

include('includes/header.php');
include('includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Receptionist</title>
    <style>
        /* ============================================
           RESET & BASE LAYOUT
           ============================================ */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
        }

        .content-area {
            margin-left: 260px;
            padding: 40px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f0f4f8 0%, #e8edf5 100%);
            display: flex;
            align-items: flex-start;
            justify-content: center;
        }

        /* ============================================
           PROFILE CARD - MAIN CONTAINER
           ============================================ */
        .profile-wrapper {
            width: 100%;
            max-width: 700px;
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .profile-card {
            background: #ffffff;
            border-radius: 20px;
            padding: 0;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08), 0 10px 30px rgba(0, 0, 0, 0.04);
            overflow: hidden;
            border: 1px solid rgba(226, 232, 240, 0.6);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .profile-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 25px 70px rgba(0, 0, 0, 0.12), 0 15px 40px rgba(0, 0, 0, 0.06);
        }

        /* ============================================
           PROFILE HEADER - COVER & AVATAR
           ============================================ */
        .profile-cover {
            background: linear-gradient(135deg, #1e3d59 0%, #2c5a7a 50%, #3b7a9e 100%);
            padding: 40px 40px 30px 40px;
            position: relative;
            min-height: 140px;
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 4px solid rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: #ffffff;
            flex-shrink: 0;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease;
        }

        .profile-avatar:hover {
            transform: scale(1.05);
        }

        .profile-title-section {
            flex: 1;
        }

        .profile-title-section h1 {
            color: #ffffff;
            font-size: 28px;
            font-weight: 700;
            margin: 0 0 6px 0;
            letter-spacing: -0.5px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .profile-title-section .role-badge {
            display: inline-block;
            padding: 6px 18px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(5px);
            color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .profile-title-section .member-since {
            color: rgba(255, 255, 255, 0.8);
            font-size: 13px;
            margin-top: 10px;
            display: block;
            font-weight: 400;
        }

        .profile-title-section .member-since strong {
            color: #ffffff;
            font-weight: 600;
        }

        /* ============================================
           PROFILE BODY - DETAILS
           ============================================ */
        .profile-body {
            padding: 35px 40px 40px 40px;
        }

        .profile-body .section-title {
            font-size: 16px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 25px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f1f5f9;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-body .section-title::after {
            content: '';
            flex: 1;
            height: 1px;
            background: linear-gradient(to right, #e2e8f0, transparent);
        }

        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px 40px;
        }

        .detail-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
            padding: 12px 16px;
            background: #f8fafc;
            border-radius: 12px;
            border: 1px solid #f1f5f9;
            transition: all 0.3s ease;
        }

        .detail-group:hover {
            background: #f1f5f9;
            border-color: #e2e8f0;
            transform: translateX(4px);
        }

        .detail-group .detail-icon {
            font-size: 18px;
            margin-right: 6px;
        }

        .detail-label {
            font-size: 11px;
            font-weight: 700;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .detail-value {
            font-size: 16px;
            color: #0f172a;
            font-weight: 600;
            padding-top: 2px;
            word-break: break-word;
        }

        .detail-value .email-copy {
            font-size: 13px;
            font-weight: 400;
            color: #64748b;
            background: #e2e8f0;
            padding: 2px 10px;
            border-radius: 4px;
            margin-left: 8px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .detail-value .email-copy:hover {
            background: #cbd5e1;
        }

        /* ============================================
           STATS / QUICK INFO BADGES
           ============================================ */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 2px solid #f1f5f9;
        }

        .stat-item {
            text-align: center;
            padding: 12px;
            background: #f8fafc;
            border-radius: 12px;
            border: 1px solid #f1f5f9;
            transition: all 0.3s ease;
        }

        .stat-item:hover {
            background: #f1f5f9;
            transform: scale(1.02);
        }

        .stat-item .stat-number {
            font-size: 20px;
            font-weight: 700;
            color: #1e3d59;
            display: block;
        }

        .stat-item .stat-label {
            font-size: 11px;
            color: #94a3b8;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        /* ============================================
           ACTION BUTTONS
           ============================================ */
        .profile-actions {
            margin-top: 30px;
            padding-top: 25px;
            border-top: 2px solid #f1f5f9;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 28px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-primary {
            background: #1e3d59;
            color: #ffffff;
        }

        .btn-primary:hover {
            background: #13283b;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(30, 61, 89, 0.3);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #334155;
        }

        .btn-secondary:hover {
            background: #cbd5e1;
            transform: translateY(-2px);
        }

        .btn-danger {
            background: #ef4444;
            color: #ffffff;
        }

        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.3);
        }

        /* ============================================
           RESPONSIVE DESIGN
           ============================================ */
        @media (max-width: 1024px) {
            .content-area {
                margin-left: 0;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .content-area {
                padding: 15px;
            }

            .profile-cover {
                flex-direction: column;
                text-align: center;
                padding: 30px 20px;
                gap: 15px;
            }

            .profile-avatar {
                width: 80px;
                height: 80px;
                font-size: 38px;
            }

            .profile-title-section h1 {
                font-size: 22px;
            }

            .profile-body {
                padding: 25px 20px 30px 20px;
            }

            .details-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .stats-row {
                grid-template-columns: 1fr 1fr;
            }

            .stats-row .stat-item:last-child {
                grid-column: span 2;
            }

            .profile-actions {
                flex-direction: column;
            }

            .profile-actions .btn {
                width: 100%;
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .stats-row {
                grid-template-columns: 1fr;
            }

            .stats-row .stat-item:last-child {
                grid-column: span 1;
            }

            .profile-avatar {
                width: 70px;
                height: 70px;
                font-size: 32px;
            }

            .profile-title-section h1 {
                font-size: 20px;
            }

            .detail-value {
                font-size: 14px;
            }
        }

        /* ============================================
           PRINT STYLES
           ============================================ */
        @media print {
            .content-area {
                background: white;
                padding: 20px;
                margin: 0;
            }

            .profile-card {
                box-shadow: none;
                border: 1px solid #ddd;
            }

            .profile-cover {
                background: #f0f0f0 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .profile-cover h1,
            .profile-cover .role-badge,
            .profile-cover .member-since {
                color: #1a202c !important;
            }

            .profile-avatar {
                background: #e2e8f0 !important;
                border-color: #cbd5e1 !important;
                color: #1a202c !important;
            }

            .profile-actions {
                display: none;
            }

            .stat-item {
                background: #f8fafc !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>

<div class="content-area">
    <div class="profile-wrapper">
        <div class="profile-card">
            
            <!-- ==========================================
            PROFILE COVER & AVATAR
            ========================================== -->
            <div class="profile-cover">
                <div class="profile-avatar">
                    <?php 
                    // Get initials from full name
                    $name_parts = explode(' ', $user['full_name']);
                    $initials = '';
                    foreach ($name_parts as $part) {
                        if (!empty($part)) {
                            $initials .= strtoupper($part[0]);
                        }
                    }
                    echo strlen($initials) > 2 ? substr($initials, 0, 2) : $initials;
                    ?>
                </div>
                
                <div class="profile-title-section">
                    <h1><?php echo htmlspecialchars($user['full_name']); ?></h1>
                    <span class="role-badge"><?php echo ucfirst($user['role']); ?></span>
                    <span class="member-since">
                        <strong>Member since:</strong> <?php echo date('F d, Y', strtotime($user['created_at'])); ?>
                    </span>
                </div>
            </div>

            <!-- ==========================================
            PROFILE BODY - DETAILS
            ========================================== -->
            <div class="profile-body">
                
                <div class="section-title">
                    👤 Personal Information
                </div>

                <div class="details-grid">
                    <div class="detail-group">
                        <span class="detail-label">
                            <span class="detail-icon">📧</span> Email Address
                        </span>
                        <span class="detail-value">
                            <?php echo htmlspecialchars($user['email']); ?>
                            <span class="email-copy" onclick="copyToClipboard('<?php echo htmlspecialchars($user['email']); ?>')">📋 Copy</span>
                        </span>
                    </div>

                    <div class="detail-group">
                        <span class="detail-label">
                            <span class="detail-icon">📱</span> Phone Number
                        </span>
                        <span class="detail-value"><?php echo htmlspecialchars($user['phone'] ?? 'Not provided'); ?></span>
                    </div>

                    <div class="detail-group" style="grid-column: 1 / -1;">
                        <span class="detail-label">
                            <span class="detail-icon">🆔</span> User ID
                        </span>
                        <span class="detail-value" style="font-family: monospace; font-size: 14px;">
                            #<?php echo str_pad($user_id, 6, '0', STR_PAD_LEFT); ?>
                        </span>
                    </div>
                </div>

                <!-- ==========================================
                STATS ROW - Quick Info
                ========================================== -->
                <div class="stats-row">
                    <div class="stat-item">
                        <span class="stat-number"><?php echo date('Y'); ?></span>
                        <span class="stat-label">Current Year</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo date('F'); ?></span>
                        <span class="stat-label">Current Month</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo date('l'); ?></span>
                        <span class="stat-label">Today</span>
                    </div>
                </div>

                <!-- ==========================================
                ACTION BUTTONS
                ========================================== -->
                <div class="profile-actions">
                    <a href="manage_appointments.php" class="btn btn-primary">
                        📅 Manage Appointments
                    </a>
                    <a href="edit_profile.php" class="btn btn-secondary">
                        ✏️ Edit Profile
                    </a>
                    <a href="../logout.php" class="btn btn-danger">
                        🚪 Logout
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
// Function to copy email to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        // Show temporary feedback
        const copyBtn = document.querySelector('.email-copy');
        const originalText = copyBtn.textContent;
        copyBtn.textContent = '✅ Copied!';
        copyBtn.style.background = '#22c55e';
        copyBtn.style.color = '#ffffff';
        
        setTimeout(function() {
            copyBtn.textContent = originalText;
            copyBtn.style.background = '#e2e8f0';
            copyBtn.style.color = '#64748b';
        }, 2000);
    }).catch(function(err) {
        alert('Failed to copy email. Please copy manually.');
    });
}

// Auto-dismiss any alerts (if any are present)
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert-banner');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.style.display = 'none';
            }, 500);
        }, 5000);
    });
});
</script>

<?php include('includes/footer.php'); ?>
</body>
</html>