<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as receptionist
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// FUNCTION: Clear/Reset Filters
// -------------------------------------------------------------------------
function clearFilters() {
    // Redirect to the same page without GET parameters
    header("Location: manage_appointments.php");
    exit;
}

// Check if clear action is triggered
if (isset($_GET['action']) && $_GET['action'] === 'clear') {
    clearFilters();
}

// -------------------------------------------------------------------------
// POST ACTION 1: CREATE A NEW APPOINTMENT (BOOKING SYSTEM)
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book_appointment') {
    $pet_id           = $_POST['pet_id'];
    $vet_id           = $_POST['vet_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $reason           = trim($_POST['reason']);
    $status           = $_POST['status'];

    if (!empty($pet_id) && !empty($vet_id) && !empty($appointment_date) && !empty($appointment_time) && !empty($reason)) {
        try {
            $insert_sql = "INSERT INTO appointments (pet_id, vet_id, appointment_date, appointment_time, reason, status) VALUES (?, ?, ?, ?, ?, ?)";
            $insert_stmt = $pdo->prepare($insert_sql);
            $insert_stmt->execute([$pet_id, $vet_id, $appointment_date, $appointment_time, $reason, $status]);
            
            $message = "📅 Appointment booked successfully in the database queue!";
            $message_class = "msg-success";
        } catch (PDOException $e) {
            $message = "Booking System Error: " . $e->getMessage();
            $message_class = "msg-danger";
        }
    } else {
        $message = "Please fill out all required validation fields for the booking record.";
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// POST ACTION 2: UPDATE STATUS FOR AN EXISTING QUEUED APPOINTMENT
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $appointment_id = $_POST['appointment_id'];
    $new_status     = $_POST['new_status'];

    try {
        $update_stmt = $pdo->prepare("UPDATE appointments SET status = ? WHERE appointment_id = ?");
        $update_stmt->execute([$new_status, $appointment_id]);
        
        $message = "🔄 Appointment status flags updated cleanly!";
        $message_class = "msg-success";
    } catch (PDOException $e) {
        $message = "Status Update Error: " . $e->getMessage();
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// POST ACTION 3: DELETE APPOINTMENT
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_appointment') {
    $appointment_id = $_POST['appointment_id'];
    
    try {
        // Start transaction for safety
        $pdo->beginTransaction();
        
        // Check if appointment exists
        $check_stmt = $pdo->prepare("SELECT appointment_id FROM appointments WHERE appointment_id = ?");
        $check_stmt->execute([$appointment_id]);
        
        if ($check_stmt->rowCount() > 0) {
            // Delete the appointment
            $delete_stmt = $pdo->prepare("DELETE FROM appointments WHERE appointment_id = ?");
            $delete_stmt->execute([$appointment_id]);
            
            $pdo->commit();
            $message = "🗑️ Appointment #" . $appointment_id . " has been permanently deleted!";
            $message_class = "msg-success";
        } else {
            $pdo->rollBack();
            $message = "⚠️ Appointment not found or already deleted.";
            $message_class = "msg-danger";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        $message = "Delete Error: " . $e->getMessage();
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// DATA LOOKUP DROPDOWNS: Fetch Pets & Vets for Selection Lists
// -------------------------------------------------------------------------
try {
    // Fetch all pets and their owners to populate structural choice dropdown inputs
    $pets_lookup = $pdo->query("SELECT p.pet_id, p.pet_name, u.full_name AS owner_name FROM pets p INNER JOIN users u ON p.owner_id = u.user_id ORDER BY p.pet_name ASC")->fetchAll();
    
    // Fetch all active medical veterinary officers matching 'vet' column data role
    $vets_lookup = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'vet' ORDER BY full_name ASC")->fetchAll();
} catch (PDOException $e) {
    $pets_lookup = [];
    $vets_lookup = [];
}

// -------------------------------------------------------------------------
// READ ACTION: Fetch & Search Comprehensive Historical Queue Entries
// -------------------------------------------------------------------------
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : '';
$search_query  = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    $query_str = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.reason, a.status, a.notes,
                         p.pet_name, p.species, u_owner.full_name AS owner_name, u_owner.phone AS owner_phone,
                         u_vet.full_name AS vet_name
                  FROM appointments a
                  INNER JOIN pets p ON a.pet_id = p.pet_id
                  INNER JOIN users u_owner ON p.owner_id = u_owner.user_id
                  INNER JOIN users u_vet ON a.vet_id = u_vet.user_id WHERE 1=1";
    
    $params = [];

    if (!empty($filter_status)) {
        $query_str .= " AND a.status = ?";
        $params[] = $filter_status;
    }

    if (!empty($search_query)) {
        $query_str .= " AND (p.pet_name LIKE ? OR u_owner.full_name LIKE ?)";
        $params[] = '%' . $search_query . '%';
        $params[] = '%' . $search_query . '%';
    }

    $query_str .= " ORDER BY a.appointment_date DESC, a.appointment_time ASC";
    
    $queue_stmt = $pdo->prepare($query_str);
    $queue_stmt->execute($params);
    $appointments_records = $queue_stmt->fetchAll();
} catch (PDOException $e) {
    $appointments_records = [];
    $message = "Error fetching queue data streams: " . $e->getMessage();
    $message_class = "msg-danger";
}

// Ingest layout wrappers
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="rcp-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #1e3d59; font-size: 24px; font-weight: 700; }
        
        .appointments-split-layout { display: flex; flex-direction: column; gap: 30px; }
        
        /* Interactive Component Cards */
        .workspace-form-card {
            background-color: #ffffff;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            padding: 25px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }
        .card-heading {
            color: #1e3d59; font-size: 18px; font-weight: 600;
            border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 20px;
        }

        /* Form Grid Mechanics */
        .form-grid-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px; margin-bottom: 20px;
        }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control {
            padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px;
            font-size: 14px; color: #334155; background-color: #ffffff;
        }
        .form-control:focus { outline: none; border-color: #17b978; }

        .submit-action-btn {
            background-color: #17b978; color: #ffffff; border: none;
            padding: 11px 24px; border-radius: 6px; font-weight: 600;
            cursor: pointer; font-size: 14px; transition: background 0.2s;
            align-self: flex-end; height: 42px; width: 100%; max-width: 240px;
        }
        .submit-action-btn:hover { background-color: #119961; }

        /* Filter Controls Styling */
        .filter-controls-row {
            display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap; align-items: flex-end;
        }
        .search-control { min-width: 280px; flex: 1; }
        .filter-btn {
            background-color: #1e3d59; color: #ffffff; text-decoration: none;
            padding: 10px 20px; border-radius: 6px; font-weight: 600; font-size: 14px;
            text-align: center; border: none; cursor: pointer; height: 42px;
        }
        .filter-btn:hover { background-color: #13283b; }
        .clear-btn { background-color: #64748b; }
        .clear-btn:hover { background-color: #475569; }

        /* Delete Button Styling */
        .delete-btn {
            background-color: #dc2626; color: #ffffff; border: none;
            padding: 8px 14px; border-radius: 4px; font-size: 12px; font-weight: 600;
            cursor: pointer; transition: background 0.2s;
        }
        .delete-btn:hover { background-color: #b91c1c; }

        /* General Records Queue Data Table Framework */
        .queue-data-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .queue-data-table th {
            background-color: #f8fafc; color: #64748b; padding: 12px 16px;
            font-weight: 600; font-size: 12px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;
        }
        .queue-data-table td { padding: 14px 16px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: middle; }
        .queue-data-table tr:hover { background-color: #f8fafc; }

        /* Dynamic Status Selector inline component modification */
        .inline-status-form { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .select-status-sm { padding: 6px 10px; font-size: 12px; border-radius: 4px; font-weight: 600; }
        .inline-update-btn {
            background-color: #e2e8f0; color: #334155; border: none; padding: 6px 10px;
            border-radius: 4px; font-size: 12px; font-weight: 600; cursor: pointer;
        }
        .inline-update-btn:hover { background-color: #cbd5e1; }

        /* Alert Status Feedback Banners */
        .alert-banner { padding: 12px 15px; border-radius: 6px; margin-bottom: 25px; font-size: 14px; font-weight: 500; }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        .meta-subtext { font-size: 12px; color: #64748b; margin-top: 1px; }

        /* Action Button Group */
        .action-group { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }

        /* Status Badge */
        .status-badge {
            display: inline-block; padding: 4px 12px; border-radius: 20px;
            font-size: 11px; font-weight: 700; text-transform: uppercase;
        }
        .status-pending { background-color: #fef3c7; color: #92400e; }
        .status-confirmed { background-color: #dbeafe; color: #1e40af; }
        .status-completed { background-color: #d1fae5; color: #065f46; }
        .status-cancelled { background-color: #fee2e2; color: #991b1b; }
    </style>

    <div class="page-title-block">
        <h2>Manage Appointments Queue</h2>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="appointments-split-layout">
        
        <div class="workspace-form-card">
            <h3 class="card-heading">➕ Book & Schedule New Appointment</h3>
            <form action="manage_appointments.php" method="POST">
                <input type="hidden" name="action" value="book_appointment">
                
                <div class="form-grid-row">
                    <div class="form-group">
                        <label for="pet_id">Select Patient (Pet) *</label>
                        <select id="pet_id" name="pet_id" class="form-control" required>
                            <option value="">-- Choose Patient Record --</option>
                            <?php foreach ($pets_lookup as $pet): ?>
                                <option value="<?php echo $pet['pet_id']; ?>">
                                    <?php echo htmlspecialchars($pet['pet_name'] . " (Owner: " . $pet['owner_name'] . ")"); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="vet_id">Assigned Veterinarian *</label>
                        <select id="vet_id" name="vet_id" class="form-control" required>
                            <option value="">-- Choose Medical Officer --</option>
                            <?php foreach ($vets_lookup as $vet): ?>
                                <option value="<?php echo $vet['user_id']; ?>">
                                    Dr. <?php echo htmlspecialchars($vet['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="appointment_date">Appointment Date *</label>
                        <input type="date" id="appointment_date" name="appointment_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="appointment_time">Time Slot *</label>
                        <input type="time" id="appointment_time" name="appointment_time" class="form-control" required>
                    </div>
                </div>

                <div class="form-grid-row">
                    <div class="form-group" style="grid-column: span 2;">
                        <label for="reason">Reason for Visit / Chief Medical Complaint *</label>
                        <input type="text" id="reason" name="reason" class="form-control" placeholder="e.g., Annual Rabies booster immunization, Persistent dry cough" required>
                    </div>

                    <div class="form-group">
                        <label for="status">Initial Booking Status</label>
                        <select id="status" name="status" class="form-control">
                            <option value="pending" selected>Pending Verification</option>
                            <option value="confirmed">Confirmed / Checked-In</option>
                        </select>
                    </div>

                    <div class="form-group" style="justify-content: flex-end;">
                        <button type="submit" class="submit-action-btn">📅 Process Queue Booking</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="workspace-form-card">
            <h3 class="card-heading">🗂️ Front Desk Operational Queue Records</h3>
            
            <form action="manage_appointments.php" method="GET">
                <div class="filter-controls-row">
                    <div class="form-group search-control">
                        <label for="search">Search Patient or Client Name</label>
                        <input type="text" id="search" name="search" class="form-control" placeholder="Type pet name or owner identity..." value="<?php echo htmlspecialchars($search_query); ?>">
                    </div>

                    <div class="form-group" style="min-width: 180px;">
                        <label for="filter_status">Filter Status Flag</label>
                        <select id="filter_status" name="filter_status" class="form-control">
                            <option value="">-- View All Statuses --</option>
                            <option value="pending" <?php echo ($filter_status === 'pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="confirmed" <?php echo ($filter_status === 'confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                            <option value="completed" <?php echo ($filter_status === 'completed') ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo ($filter_status === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>

                    <button type="submit" class="filter-btn">🔍 Apply Sorting Filter</button>
                    <a href="manage_appointments.php?action=clear" class="filter-btn clear-btn">🧹 Clear All Filters</a>
                </div>
            </form>

            <?php if (count($appointments_records) > 0): ?>
                <table class="queue-data-table">
                    <thead>
                        <tr>
                            <th>Schedule Date/Time</th>
                            <th>Patient (Animal)</th>
                            <th>Owner Details</th>
                            <th>Assigned Vet doctor</th>
                            <th>Reason Description</th>
                            <th>Queue Pipeline Action Modifiers</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($appointments_records as $row): ?>
                            <tr>
                                <td>
                                    <strong><?php echo date('M d, Y', strtotime($row['appointment_date'])); ?></strong>
                                    <div class="meta-subtext">⏰ <?php echo date('h:i A', strtotime($row['appointment_time'])); ?></div>
                                    <div class="meta-subtext" style="margin-top: 4px;">
                                        <span class="status-badge status-<?php echo $row['status']; ?>"><?php echo $row['status']; ?></span>
                                    </div>
                                </td>

                                <td>
                                    <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong>
                                    <div class="meta-subtext"><?php echo htmlspecialchars($row['species']); ?></div>
                                </td>

                                <td>
                                    <strong><?php echo htmlspecialchars($row['owner_name']); ?></strong>
                                    <div class="meta-subtext">📞 <?php echo htmlspecialchars($row['owner_phone'] ?: 'No Phone'); ?></div>
                                </td>

                                <td>Dr. <?php echo htmlspecialchars($row['vet_name']); ?></td>

                                <td><?php echo htmlspecialchars($row['reason']); ?></td>

                                <td>
                                    <div class="action-group">
                                        <form action="manage_appointments.php" method="POST" class="inline-status-form">
                                            <input type="hidden" name="action" value="update_status">
                                            <input type="hidden" name="appointment_id" value="<?php echo $row['appointment_id']; ?>">
                                            
                                            <select name="new_status" class="form-control select-status-sm">
                                                <option value="pending" <?php echo ($row['status'] === 'pending') ? 'selected' : ''; ?>>Pending</option>
                                                <option value="confirmed" <?php echo ($row['status'] === 'confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                                                <option value="completed" <?php echo ($row['status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                                                <option value="cancelled" <?php echo ($row['status'] === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                            </select>
                                            <button type="submit" class="inline-update-btn">💾 Update</button>
                                        </form>
                                        
                                        <!-- Delete Button -->
                                        <form action="manage_appointments.php" method="POST" onsubmit="return confirmDelete(<?php echo $row['appointment_id']; ?>)">
                                            <input type="hidden" name="action" value="delete_appointment">
                                            <input type="hidden" name="appointment_id" value="<?php echo $row['appointment_id']; ?>">
                                            <button type="submit" class="delete-btn">🗑️ Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #94a3b8; font-style: italic;">
                    No operational appointment parameters found matching your search criteria.
                </div>
            <?php endif; ?>

            <!-- Display Record Count -->
            <?php if (count($appointments_records) > 0): ?>
                <div style="margin-top: 15px; padding: 10px; background: #f8fafc; border-radius: 6px; color: #475569; font-size: 14px; text-align: center;">
                    Total Records: <strong><?php echo count($appointments_records); ?></strong>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<script>
// JavaScript function to confirm deletion
function confirmDelete(appointmentId) {
    return confirm("⚠️ Are you sure you want to permanently delete appointment #" + appointmentId + "?\n\nThis action cannot be undone!");
}

// Auto-dismiss alert after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alertBanner = document.querySelector('.alert-banner');
    if (alertBanner) {
        setTimeout(function() {
            alertBanner.style.transition = 'opacity 0.5s';
            alertBanner.style.opacity = '0';
            setTimeout(function() {
                alertBanner.style.display = 'none';
            }, 500);
        }, 5000);
    }
});
</script>

<?php 
// Ingest dynamic systemic bottom closing wrapper blocks frames safely
include('includes/footer.php'); 
?>