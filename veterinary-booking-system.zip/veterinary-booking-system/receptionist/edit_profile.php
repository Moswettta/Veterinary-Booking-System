<?php
// ============================================
// SESSION & SECURITY
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is a logged-in receptionist
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    header("Location: ../login.php");
    exit;
}

require_once('../config/db.php');
$user_id = $_SESSION['user_id'];
$message = "";
$message_type = "";

// ============================================
// FETCH CURRENT USER DATA
// ============================================
$stmt = $pdo->prepare("SELECT full_name, email, phone, role, created_at FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// ============================================
// HANDLE FORM SUBMISSION
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $errors = [];
    
    // Validate required fields
    if (empty($full_name)) {
        $errors[] = "Full name is required.";
    }
    if (empty($email)) {
        $errors[] = "Email address is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    
    // Check if email already exists for another user
    if (!empty($email)) {
        $check_stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
        $check_stmt->execute([$email, $user_id]);
        if ($check_stmt->rowCount() > 0) {
            $errors[] = "This email is already registered to another account.";
        }
    }
    
    // Handle password change
    $password_update = false;
    if (!empty($current_password) || !empty($new_password) || !empty($confirm_password)) {
        // Verify current password
        $pass_stmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
        $pass_stmt->execute([$user_id]);
        $user_data = $pass_stmt->fetch();
        
        if (!password_verify($current_password, $user_data['password'])) {
            $errors[] = "Current password is incorrect.";
        }
        
        if (empty($current_password)) {
            $errors[] = "Current password is required to change password.";
        }
        if (empty($new_password)) {
            $errors[] = "New password is required.";
        } elseif (strlen($new_password) < 6) {
            $errors[] = "New password must be at least 6 characters long.";
        }
        if ($new_password !== $confirm_password) {
            $errors[] = "New passwords do not match.";
        }
        
        if (empty($errors)) {
            $password_update = true;
        }
    }
    
    // If no errors, update the profile
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Update basic info
            $update_sql = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?";
            $update_params = [$full_name, $email, $phone, $user_id];
            
            if ($password_update) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, password = ? WHERE user_id = ?";
                $update_params = [$full_name, $email, $phone, $hashed_password, $user_id];
            }
            
            $update_stmt = $pdo->prepare($update_sql);
            $update_stmt->execute($update_params);
            
            $pdo->commit();
            
            // Update session name if changed
            $_SESSION['full_name'] = $full_name;
            
            $message = "✅ Profile updated successfully!";
            $message_type = "success";
            
            // Refresh user data
            $stmt = $pdo->prepare("SELECT full_name, email, phone, role, created_at FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = "❌ Error updating profile: " . $e->getMessage();
            $message_type = "error";
        }
    } else {
        $message = "❌ Please fix the following errors: " . implode(" ", $errors);
        $message_type = "error";
    }
}

include('includes/header.php');
include('includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Receptionist</title>
    <style>
        /* ============================================
           RESET & BASE LAYOUT
           ============================================ */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
        }

        .content-area {
            margin-left: 260px;
            padding: 40px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f0f4f8 0%, #e8edf5 100%);
            display: flex;
            align-items: flex-start;
            justify-content: center;
        }

        /* ============================================
           EDIT PROFILE CARD
           ============================================ */
        .profile-wrapper {
            width: 100%;
            max-width: 750px;
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .edit-card {
            background: #ffffff;
            border-radius: 20px;
            padding: 0;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08), 0 10px 30px rgba(0, 0, 0, 0.04);
            overflow: hidden;
            border: 1px solid rgba(226, 232, 240, 0.6);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .edit-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 25px 70px rgba(0, 0, 0, 0.12), 0 15px 40px rgba(0, 0, 0, 0.06);
        }

        /* ============================================
           HEADER SECTION
           ============================================ */
        .edit-header {
            background: linear-gradient(135deg, #1e3d59 0%, #2c5a7a 50%, #3b7a9e 100%);
            padding: 30px 40px;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .edit-header .back-icon {
            width: 44px;
            height: 44px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(5px);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #ffffff;
            text-decoration: none;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .edit-header .back-icon:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: scale(1.05);
        }

        .edit-header h1 {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .edit-header p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 14px;
            margin: 2px 0 0 0;
        }

        /* ============================================
           ALERT MESSAGES
           ============================================ */
        .alert-container {
            padding: 20px 40px 0 40px;
        }

        .alert {
            padding: 14px 20px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid;
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: #f0fdf4;
            border-left-color: #22c55e;
            color: #166534;
        }

        .alert-error {
            background: #fef2f2;
            border-left-color: #ef4444;
            color: #991b1b;
        }

        .alert .alert-close {
            margin-left: auto;
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: inherit;
            opacity: 0.6;
            transition: opacity 0.2s;
            padding: 0 5px;
        }

        .alert .alert-close:hover {
            opacity: 1;
        }

        /* ============================================
           FORM BODY
           ============================================ */
        .edit-body {
            padding: 35px 40px 40px 40px;
        }

        .form-section {
            margin-bottom: 30px;
        }

        .form-section:last-child {
            margin-bottom: 0;
        }

        .form-section-title {
            font-size: 16px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f1f5f9;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-section-title::after {
            content: '';
            flex: 1;
            height: 1px;
            background: linear-gradient(to right, #e2e8f0, transparent);
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px 30px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: #334155;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .form-group label .required {
            color: #ef4444;
            font-size: 16px;
        }

        .form-group .field-hint {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 3px;
        }

        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: #fafbfc;
            color: #1a202c;
        }

        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15);
            background: #ffffff;
        }

        .form-control:disabled {
            background: #f1f5f9;
            cursor: not-allowed;
            opacity: 0.7;
        }

        .form-control::placeholder {
            color: #a0aec0;
        }

        /* Password toggle */
        .password-wrapper {
            position: relative;
        }

        .password-wrapper .form-control {
            padding-right: 50px;
        }

        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            padding: 5px;
            color: #94a3b8;
            transition: color 0.2s;
        }

        .password-toggle:hover {
            color: #334155;
        }

        /* Password strength indicator */
        .password-strength {
            margin-top: 8px;
            height: 4px;
            border-radius: 4px;
            background: #e2e8f0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .password-strength .strength-bar {
            height: 100%;
            width: 0%;
            border-radius: 4px;
            transition: width 0.3s ease, background 0.3s ease;
        }

        .password-strength-text {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 4px;
            display: block;
        }

        /* ============================================
           FORM ACTIONS
           ============================================ */
        .form-actions {
            margin-top: 35px;
            padding-top: 25px;
            border-top: 2px solid #f1f5f9;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 32px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            justify-content: center;
            min-width: 140px;
        }

        .btn-primary {
            background: #1e3d59;
            color: #ffffff;
        }

        .btn-primary:hover {
            background: #13283b;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(30, 61, 89, 0.3);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #334155;
        }

        .btn-secondary:hover {
            background: #cbd5e1;
            transform: translateY(-2px);
        }

        .btn-success {
            background: #22c55e;
            color: #ffffff;
        }

        .btn-success:hover {
            background: #16a34a;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(34, 197, 94, 0.3);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none !important;
        }

        /* ============================================
           RESPONSIVE DESIGN
           ============================================ */
        @media (max-width: 1024px) {
            .content-area {
                margin-left: 0;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .content-area {
                padding: 15px;
            }

            .edit-header {
                flex-direction: column;
                text-align: center;
                padding: 25px 20px;
            }

            .edit-header h1 {
                font-size: 20px;
            }

            .edit-body {
                padding: 25px 20px 30px 20px;
            }

            .form-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .form-group.full-width {
                grid-column: 1;
            }

            .form-actions {
                flex-direction: column;
            }

            .form-actions .btn {
                width: 100%;
            }

            .alert-container {
                padding: 15px 20px 0 20px;
            }

            .alert {
                font-size: 13px;
                padding: 12px 16px;
            }
        }

        @media (max-width: 480px) {
            .edit-header h1 {
                font-size: 18px;
            }

            .edit-header .back-icon {
                width: 38px;
                height: 38px;
                font-size: 17px;
            }

            .form-control {
                font-size: 14px;
                padding: 10px 14px;
            }
        }

        /* ============================================
           PRINT STYLES
           ============================================ */
        @media print {
            .content-area {
                background: white;
                padding: 20px;
                margin: 0;
            }

            .edit-card {
                box-shadow: none;
                border: 1px solid #ddd;
            }

            .edit-header {
                background: #f0f0f0 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .edit-header h1,
            .edit-header p {
                color: #1a202c !important;
            }

            .edit-header .back-icon {
                display: none;
            }

            .form-actions {
                display: none;
            }

            .alert-container {
                display: none;
            }

            .form-control {
                border: 1px solid #ddd;
                background: white !important;
            }
        }
    </style>
</head>
<body>

<div class="content-area">
    <div class="profile-wrapper">
        <div class="edit-card">
            
            <!-- ==========================================
            HEADER
            ========================================== -->
            <div class="edit-header">
                <a href="profile.php" class="back-icon">←</a>
                <div>
                    <h1>✏️ Edit Profile</h1>
                    <p>Update your personal information and account settings</p>
                </div>
            </div>

            <!-- ==========================================
            ALERT MESSAGES
            ========================================== -->
            <?php if (!empty($message)): ?>
            <div class="alert-container">
                <div class="alert alert-<?php echo $message_type; ?>">
                    <span><?php echo $message; ?></span>
                    <button class="alert-close" onclick="this.parentElement.parentElement.style.display='none'">✕</button>
                </div>
            </div>
            <?php endif; ?>

            <!-- ==========================================
            FORM BODY
            ========================================== -->
            <div class="edit-body">
                <form method="POST" id="editProfileForm" novalidate>
                    
                    <!-- Personal Information -->
                    <div class="form-section">
                        <div class="form-section-title">
                            👤 Personal Information
                        </div>

                        <div class="form-grid">
                            <div class="form-group full-width">
                                <label for="full_name">
                                    Full Name <span class="required">*</span>
                                </label>
                                <input 
                                    type="text" 
                                    id="full_name" 
                                    name="full_name" 
                                    class="form-control" 
                                    value="<?php echo htmlspecialchars($user['full_name']); ?>"
                                    required
                                    placeholder="Enter your full name"
                                >
                            </div>

                            <div class="form-group">
                                <label for="email">
                                    Email Address <span class="required">*</span>
                                </label>
                                <input 
                                    type="email" 
                                    id="email" 
                                    name="email" 
                                    class="form-control" 
                                    value="<?php echo htmlspecialchars($user['email']); ?>"
                                    required
                                    placeholder="your@email.com"
                                >
                            </div>

                            <div class="form-group">
                                <label for="phone">
                                    Phone Number
                                </label>
                                <input 
                                    type="tel" 
                                    id="phone" 
                                    name="phone" 
                                    class="form-control" 
                                    value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                                    placeholder="+254 700 000 000"
                                >
                                <span class="field-hint">Include country code if applicable</span>
                            </div>

                            <div class="form-group">
                                <label>Role</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    value="<?php echo ucfirst($user['role']); ?>"
                                    disabled
                                >
                                <span class="field-hint">Role cannot be changed</span>
                            </div>

                            <div class="form-group">
                                <label>Member Since</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    value="<?php echo date('F d, Y', strtotime($user['created_at'])); ?>"
                                    disabled
                                >
                            </div>
                        </div>
                    </div>

                    <!-- Change Password -->
                    <div class="form-section">
                        <div class="form-section-title">
                            🔒 Change Password
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label for="current_password">
                                    Current Password
                                </label>
                                <div class="password-wrapper">
                                    <input 
                                        type="password" 
                                        id="current_password" 
                                        name="current_password" 
                                        class="form-control" 
                                        placeholder="Enter current password"
                                        autocomplete="current-password"
                                    >
                                    <button type="button" class="password-toggle" onclick="togglePassword('current_password')">👁️</button>
                                </div>
                                <span class="field-hint">Required to change password</span>
                            </div>

                            <div class="form-group">
                                <label for="new_password">
                                    New Password
                                </label>
                                <div class="password-wrapper">
                                    <input 
                                        type="password" 
                                        id="new_password" 
                                        name="new_password" 
                                        class="form-control" 
                                        placeholder="Enter new password (min 6 chars)"
                                        autocomplete="new-password"
                                        oninput="checkPasswordStrength(this.value)"
                                    >
                                    <button type="button" class="password-toggle" onclick="togglePassword('new_password')">👁️</button>
                                </div>
                                <div class="password-strength">
                                    <div class="strength-bar" id="strengthBar"></div>
                                </div>
                                <span class="password-strength-text" id="strengthText">Enter a new password</span>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">
                                    Confirm New Password
                                </label>
                                <div class="password-wrapper">
                                    <input 
                                        type="password" 
                                        id="confirm_password" 
                                        name="confirm_password" 
                                        class="form-control" 
                                        placeholder="Confirm new password"
                                        autocomplete="new-password"
                                    >
                                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">👁️</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">
                            💾 Save Changes
                        </button>
                        <a href="profile.php" class="btn btn-secondary">
                            ↩️ Cancel
                        </a>
                        <a href="profile.php" class="btn btn-primary" style="margin-left: auto;">
                            📋 View Profile
                        </a>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<script>
// ============================================
// PASSWORD TOGGLE FUNCTION
// ============================================
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return;
    
    const type = field.getAttribute('type') === 'password' ? 'text' : 'password';
    field.setAttribute('type', type);
    
    // Update button text
    const wrapper = field.closest('.password-wrapper');
    const button = wrapper.querySelector('.password-toggle');
    button.textContent = type === 'password' ? '👁️' : '🙈';
}

// ============================================
// PASSWORD STRENGTH CHECKER
// ============================================
function checkPasswordStrength(password) {
    const bar = document.getElementById('strengthBar');
    const text = document.getElementById('strengthText');
    
    if (!password || password.length === 0) {
        bar.style.width = '0%';
        bar.style.background = '#e2e8f0';
        text.textContent = 'Enter a new password';
        text.style.color = '#94a3b8';
        return;
    }
    
    let strength = 0;
    let color = '#ef4444';
    let label = 'Weak';
    
    // Length check
    if (password.length >= 6) strength += 1;
    if (password.length >= 10) strength += 1;
    
    // Contains uppercase
    if (/[A-Z]/.test(password)) strength += 1;
    
    // Contains lowercase
    if (/[a-z]/.test(password)) strength += 1;
    
    // Contains numbers
    if (/\d/.test(password)) strength += 1;
    
    // Contains special characters
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    // Calculate percentage (max 6)
    const percentage = (strength / 6) * 100;
    
    if (strength <= 2) {
        color = '#ef4444';
        label = 'Weak';
    } else if (strength <= 4) {
        color = '#f59e0b';
        label = 'Medium';
    } else {
        color = '#22c55e';
        label = 'Strong';
    }
    
    bar.style.width = percentage + '%';
    bar.style.background = color;
    text.textContent = 'Strength: ' + label + ' (' + Math.round(percentage) + '%)';
    text.style.color = color;
}

// ============================================
// FORM VALIDATION
// ============================================
document.getElementById('editProfileForm').addEventListener('submit', function(e) {
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    const currentPassword = document.getElementById('current_password').value;
    
    // If user is trying to change password
    if (currentPassword || newPassword || confirmPassword) {
        if (newPassword && newPassword.length < 6) {
            e.preventDefault();
            alert('New password must be at least 6 characters long.');
            document.getElementById('new_password').focus();
            return false;
        }
        
        if (newPassword !== confirmPassword) {
            e.preventDefault();
            alert('New passwords do not match.');
            document.getElementById('confirm_password').focus();
            return false;
        }
    }
    
    return true;
});

// ============================================
// AUTO-DISMISS ALERTS
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    const alertContainer = document.querySelector('.alert-container');
    if (alertContainer) {
        setTimeout(function() {
            alertContainer.style.transition = 'opacity 0.6s';
            alertContainer.style.opacity = '0';
            setTimeout(function() {
                alertContainer.style.display = 'none';
            }, 600);
        }, 6000);
    }
});

// ============================================
// REAL-TIME PASSWORD CONFIRMATION CHECK
// ============================================
document.getElementById('confirm_password').addEventListener('input', function() {
    const password = document.getElementById('new_password').value;
    const confirm = this.value;
    
    if (confirm.length > 0 && password !== confirm) {
        this.style.borderColor = '#ef4444';
        this.style.boxShadow = '0 0 0 4px rgba(239, 68, 68, 0.15)';
    } else if (confirm.length > 0 && password === confirm) {
        this.style.borderColor = '#22c55e';
        this.style.boxShadow = '0 0 0 4px rgba(34, 197, 94, 0.15)';
    } else {
        this.style.borderColor = '#e2e8f0';
        this.style.boxShadow = 'none';
    }
});
</script>

<?php include('includes/footer.php'); ?>
</body>
</html>