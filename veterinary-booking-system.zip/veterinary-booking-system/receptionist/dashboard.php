<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as receptionist
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration
require_once('../config/db.php');

$current_date = date('Y-m-d');

// -------------------------------------------------------------------------
// DATA AGGREGATION: Fetch KPI Metrics Cards Indicators
// -------------------------------------------------------------------------
try {
    // 1. Total Pending appointments waiting for approval/action today
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE appointment_date = ? AND status = 'pending'");
    $stmt->execute([$current_date]);
    $metrics['pending_today'] = $stmt->fetchColumn();

    // 2. Total Confirmed/Active check-ins remaining today
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE appointment_date = ? AND status = 'confirmed'");
    $stmt->execute([$current_date]);
    $metrics['confirmed_today'] = $stmt->fetchColumn();

    // 3. Total overall registered clients inside the users matrix
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'pet_owner'");
    $metrics['total_owners'] = $stmt->fetchColumn();

    // 4. Total registered patient animal profiles
    $stmt = $pdo->query("SELECT COUNT(*) FROM pets");
    $metrics['total_pets'] = $stmt->fetchColumn();

    // -------------------------------------------------------------------------
// READ ACTION: Fetch Today's Comprehensive Real-time Appointments Queue
// -------------------------------------------------------------------------
    $queue_query = "SELECT a.appointment_id, a.appointment_time, a.reason, a.status,
                           p.pet_name, p.species,
                           u_owner.full_name AS owner_name, u_owner.phone AS owner_phone,
                           u_vet.full_name AS vet_name
                    FROM appointments a
                    INNER JOIN pets p ON a.pet_id = p.pet_id
                    INNER JOIN users u_owner ON p.owner_id = u_owner.user_id
                    INNER JOIN users u_vet ON a.vet_id = u_vet.user_id
                    WHERE a.appointment_date = ?
                    ORDER BY a.appointment_time ASC";
                    
    $queue_stmt = $pdo->prepare($queue_query);
    $queue_stmt->execute([$current_date]);
    $todays_queue = $queue_stmt->fetchAll();

} catch (PDOException $e) {
    $metrics = ['pending_today' => 0, 'confirmed_today' => 0, 'total_owners' => 0, 'total_pets' => 0];
    $todays_queue = [];
    $error_msg = "Database extraction error: " . $e->getMessage();
}

// Ingest front office structural frames layouts
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="rcp-main-content-canvas">

    <style>
        .dashboard-header-block {
            margin-bottom: 25px;
        }
        .dashboard-header-block h2 {
            color: #1e3d59;
            font-size: 24px;
            font-weight: 700;
        }
        .dashboard-header-block p {
            color: #64748b;
            font-size: 14px;
            margin-top: 2px;
        }

        /* Metrics Display Grid Configuration */
        .metrics-grid-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .metric-card-box {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .metric-info-data h3 {
            font-size: 28px;
            color: #1e3d59;
            font-weight: 700;
            line-height: 1.2;
        }
        .metric-info-data p {
            font-size: 13px;
            color: #64748b;
            font-weight: 500;
            margin-top: 4px;
        }
        .metric-icon-badge {
            width: 48px;
            height: 48px;
            border-radius: 6px;
            font-size: 22px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .badge-amber { background-color: #fef3c7; color: #d97706; }
        .badge-blue { background-color: #dbeafe; color: #1d4ed8; }
        .badge-green { background-color: #d1fae5; color: #065f46; }
        .badge-purple { background-color: #f3e8ff; color: #6b21a8; }

        /* Queue Data View Workspace Card */
        .queue-data-card {
            background-color: #ffffff;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
            padding: 25px;
        }
        .card-title-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .card-title-bar h3 {
            color: #1e3d59;
            font-size: 18px;
            font-weight: 600;
        }
        .shortcut-action-btn {
            background-color: #17b978;
            color: #ffffff;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 6px;
            transition: background 0.2s;
        }
        .shortcut-action-btn:hover { background-color: #119961; }

        /* Unified Queue Table Framework */
        .queue-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 14px;
        }
        .queue-table th {
            background-color: #f8fafc;
            color: #64748b;
            padding: 12px 16px;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid #e2e8f0;
        }
        .queue-table td {
            padding: 14px 16px;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            vertical-align: middle;
        }
        .queue-table tr:hover { background-color: #f8fafc; }

        /* Status Badge Indicators mapping schema */
        .status-pill {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            text-align: center;
        }
        .status-pill.pending { background-color: #fef3c7; color: #d97706; }
        .status-pill.confirmed { background-color: #dbeafe; color: #1d4ed8; }
        .status-pill.completed { background-color: #d1fae5; color: #065f46; }
        .status-pill.cancelled { background-color: #fee2e2; color: #991b1b; }

        .meta-subtext {
            font-size: 12px;
            color: #64748b;
            margin-top: 1px;
        }
        .empty-state-notice {
            text-align: center;
            padding: 40px 20px;
            color: #94a3b8;
            font-style: italic;
        }
    </style>

    <div class="dashboard-header-block">
        <h2>Front Desk Command Overview</h2>
        <p>Today is <?php echo date('l, M d, Y'); ?> — Monitoring current clinical reception pipelines.</p>
    </div>

    <div class="metrics-grid-row">
        <div class="metric-card-box">
            <div class="metric-info-data">
                <h3><?php echo $metrics['pending_today']; ?></h3>
                <p>Pending Today</p>
            </div>
            <div class="metric-icon-badge badge-amber">⏳</div>
        </div>

        <div class="metric-card-box">
            <div class="metric-info-data">
                <h3><?php echo $metrics['confirmed_today']; ?></h3>
                <p>Checked-In / Confirmed</p>
            </div>
            <div class="metric-icon-badge badge-blue">✅</div>
        </div>

        <div class="metric-card-box">
            <div class="metric-info-data">
                <h3><?php echo $metrics['total_owners']; ?></h3>
                <p>Total Registered Clients</p>
            </div>
            <div class="metric-icon-badge badge-green">👥</div>
        </div>

        <div class="metric-card-box">
            <div class="metric-info-data">
                <h3><?php echo $metrics['total_pets']; ?></h3>
                <p>Animal Patients Records</p>
            </div>
            <div class="metric-icon-badge badge-purple">🐾</div>
        </div>
    </div>

    <div class="queue-data-card">
        <div class="card-title-bar">
            <h3>Today's Patient Schedule Queue</h3>
            <a href="manage_appointments.php" class="shortcut-action-btn">⚙️ Manage Desk Queue</a>
        </div>

        <?php if (isset($error_msg)): ?>
            <div style="color: #991b1b; background-color: #fee2e2; padding: 12px; border-radius: 6px; font-size: 14px; margin-bottom: 15px;">
                <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>

        <?php if (count($todays_queue) > 0): ?>
            <table class="queue-table">
                <thead>
                    <tr>
                        <th>Time Slot</th>
                        <th>Patient (Pet)</th>
                        <th>Owner (Client)</th>
                        <th>Assigned Vet</th>
                        <th>Reason for Visit</th>
                        <th>Queue Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($todays_queue as $row): ?>
                        <tr>
                            <td>
                                <strong><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></strong>
                            </td>
                            
                            <td>
                                <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong>
                                <div class="meta-subtext"><?php echo htmlspecialchars($row['species']); ?></div>
                            </td>
                            
                            <td>
                                <strong><?php echo htmlspecialchars($row['owner_name']); ?></strong>
                                <div class="meta-subtext">📞 <?php echo htmlspecialchars($row['owner_phone'] ?: 'N/A'); ?></div>
                            </td>
                            
                            <td>
                                Dr. <?php echo htmlspecialchars($row['vet_name']); ?>
                            </td>
                            
                            <td>
                                <?php echo htmlspecialchars($row['reason']); ?>
                            </td>
                            
                            <td>
                                <span class="status-pill <?php echo htmlspecialchars(strtolower($row['status'])); ?>">
                                    <?php echo htmlspecialchars($row['status']); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="empty-state-notice">
                <p>No animal patient visits or schedule logs are queued for today's date block.</p>
            </div>
        <?php endif; ?>
    </div>

</div>

<?php 
// Ingest layout closures safely
include('includes/footer.php'); 
?>