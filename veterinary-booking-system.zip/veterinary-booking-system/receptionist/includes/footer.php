</div> </div> <footer class="reception-footer">
    <div class="footer-copyright-text">
        &copy; <?php echo date('Y'); ?> <strong>Oakland Veterinary Clinic</strong> — Front Desk Dashboard Portal. All Rights Reserved.
    </div>
    <div class="system-time-stamp">
        📍 Desk Node: Nairobi Office
    </div>
</footer>

<style>
    .reception-footer {
        background-color: #ffffff;
        height: 45px;
        width: 100%;
        border-top: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 25px;
        font-size: 12px;
        color: #64748b;
        position: relative;
        z-index: 1000;
        margin-top: auto; /* Pushes footer flush down to the screen edge if content is short */
    }
    
    .footer-copyright-text strong {
        color: #1e3d59;
        font-weight: 600;
    }

    .system-time-stamp {
        font-weight: 500;
        color: #475569;
    }

    /* Pushes the footer area outwards to sit perfectly on screen monitors matching sidebar alignment widths */
    @media (min-width: 993px) {
        .reception-footer {
            padding-left: 285px; /* Aligns footer text exactly parallel to the 260px vertical sidebar offset */
        }
    }
</style>

</body>
</html>