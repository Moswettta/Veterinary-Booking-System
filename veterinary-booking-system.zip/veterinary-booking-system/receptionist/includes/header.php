<?php
// Establish secure session isolation framework
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Access Control Guard: Ensure only logged-in receptionists can pass
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    // If no valid session exists, boot the browser back to the root-level gateway login file
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reception Desk Portal | Oakland Veterinary Clinic</title>
    
    <style>
        /* Modern Minimalist Reset Grid and CSS Root Variables */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --primary-navy: #1e3d59;     /* Deep corporate navy for anchors and title structures */
            --accent-mint: #17b978;      /* Clean functional actions teal */
            --bg-canvas: #f4f6f9;        /* Soft neutral main page viewport background */
            --panel-border: #e2e8f0;     /* Minimal card divider framework borders */
            --text-main: #334155;        /* Balanced text visibility slate */
            --text-muted: #64748b;       /* Secondary labeling element color */
        }

        body {
            background-color: var(--bg-canvas);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Front Office Top Utility Control Bar Layer */
        .reception-topbar {
            background-color: #ffffff;
            height: 65px;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 25px;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);
            border-bottom: 1px solid var(--panel-border);
        }

        .brand-desk-identity {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--primary-navy);
            font-weight: 700;
            font-size: 18px;
            letter-spacing: -0.3px;
        }
        
        .brand-desk-badge {
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 11px;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 4px;
            border: 1px solid #bfdbfe;
            text-transform: uppercase;
        }

        /* Right Hand Account Status Blocks */
        .receptionist-meta-box {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .active-user-tag {
            text-align: right;
        }

        .user-greeting {
            font-size: 13px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .user-profile-name {
            font-size: 14px;
            color: var(--primary-navy);
            font-weight: 600;
        }

        .avatar-circle {
            width: 38px;
            height: 38px;
            background-color: var(--primary-navy);
            color: #ffffff;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 600;
            font-size: 14px;
            border: 2px solid #ffffff;
            box-shadow: 0 0 0 2px var(--accent-mint);
        }

        /* Core Application Split Layout Alignment System */
        .reception-workspace-wrapper {
            display: flex;
            margin-top: 65px; /* Offset push to prevent content hiding beneath topbar */
            min-height: calc(100vh - 65px);
            width: 100%;
        }

        /* This target class defines the working interface canvas windows.
           It will be cleanly closed by the independent includes/footer.php layer.
        */
        .rcp-main-content-canvas {
            flex: 1;
            padding: 30px;
            background-color: var(--bg-canvas);
            margin-left: 260px; /* Aligns canvas directly out of sidebar width boundary */
            transition: all 0.3s ease;
        }

        /* Responsive Breakpoint Adaptors for Smaller Screen Monitors */
        @media (max-width: 992px) {
            .rcp-main-content-canvas {
                margin-left: 0; /* Snap full width if dynamic mobile grids scale down */
                padding: 20px;
            }
        }
    </style>
</head>
<body>

    <nav class="reception-topbar" 
     style="display:flex; justify-content:space-between; align-items:center; padding:15px 25px; background:#0f172a;">

    <div class="brand-desk-identity" 
         style="color:white; font-size:22px; font-weight:bold;">
        <span>🛎️</span> Oakland Vet Clinic 
        <span class="brand-desk-badge" 
              style="background:#2563eb; padding:4px 10px; border-radius:20px; font-size:12px; margin-left:10px;">
            Front Office
        </span>
    </div>
    
    <div class="receptionist-meta-box" 
         style="display:flex; align-items:center; gap:20px;">

        <div class="active-user-tag" style="text-align:right; color:white;">
            <div class="user-greeting" style="font-size:13px; color:#cbd5e1;">
                Duty Officer
            </div>

            <div class="user-profile-name" style="font-weight:bold;">
                <?php echo htmlspecialchars($_SESSION['username']); ?>
            </div>
        </div>

        <div class="avatar-circle" 
             style="width:45px; height:45px; border-radius:50%; background:#2563eb; color:white; display:flex; align-items:center; justify-content:center; font-weight:bold;">
            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
        </div>

        <!-- Profile & Logout -->
        <div style="display:flex; gap:15px; margin-left:15px;">

            <a href="profile.php" 
               style="text-decoration:none; color:white; font-weight:600;">
                👤 Profile
            </a>

            <a href="../logout.php" 
               style="text-decoration:none; color:#ff4d4d; font-weight:600;">
                🚪 Logout
            </a>

        </div>

    </div>
</nav>

<div class="reception-workspace-wrapper">