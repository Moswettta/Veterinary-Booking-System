<?php
// Secure session verification framework 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Extract the active page filename to dynamically highlight the current sidebar button link
$current_page = basename($_SERVER['PHP_SELF']);
?>

<aside class="reception-sidebar">
    
    <div class="sidebar-nav-group">
        <a href="dashboard.php" class="sidebar-link <?php echo ($current_page == 'dashboard.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">📊</span> Dashboard Overview
        </a>
        
        <a href="manage_appointments.php" class="sidebar-link <?php echo ($current_page == 'manage_appointments.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">📅</span> Appointments Queue
        </a>
        
        <a href="pet_owner_profiles.php" class="sidebar-link <?php echo ($current_page == 'pet_owner_profiles.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">👥</span> Pet Owner Profiles
        </a>
        
        <a href="reports.php" class="sidebar-link <?php echo ($current_page == 'reports.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">📈</span> Operational Reports
        </a>
    </div>

    <div class="sidebar-footer-group">
        <a href="profile.php" class="sidebar-link <?php echo ($current_page == 'profile.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">👤</span> My Profile Settings
        </a>
        
        <a href="../logout.php" class="sidebar-link logout-btn">
            <span class="link-icon">🚪</span> Sign Out Account
        </a>
    </div>

</aside>

<style>
    .reception-sidebar {
        width: 260px;
        background-color: #1e3d59; /* Deep corporate navy branding */
        height: calc(100vh - 65px);
        position: fixed;
        top: 65px; /* Sits flush beneath your 65px header topbar layout */
        left: 0;
        z-index: 999;
        display: flex;
        flex-direction: column;
        justify-content: space-between; /* Securely pins navigation items at the top and profile/logout at the bottom */
        padding: 20px 0;
        border-right: 1px solid rgba(255, 255, 255, 0.05);
    }

    .sidebar-nav-group, 
    .sidebar-footer-group {
        display: flex;
        flex-direction: column;
        width: 100%;
        padding: 0 12px;
    }

    /* Set up strict separation padding layout above your bottom profile elements */
    .sidebar-footer-group {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        padding-top: 15px;
        margin-top: auto;
    }

    /* Core link styling variables configuration */
    .sidebar-link {
        display: flex;
        align-items: center;
        gap: 12px;
        color: #cbd5e1;
        text-decoration: none;
        padding: 12px 16px;
        font-size: 14px;
        font-weight: 500;
        border-radius: 6px;
        margin-bottom: 4px;
        transition: all 0.2s ease;
    }

    .sidebar-link:hover {
        background-color: rgba(255, 255, 255, 0.07);
        color: #ffffff;
    }

    /* Dynamic page location visual tracking highlight selector class */
    .active-link {
        background-color: #17b978 !important; /* Functional actions teal highlighting your active pages */
        color: #ffffff !important;
        font-weight: 600;
    }

    .link-icon {
        font-size: 16px;
        display: inline-block;
        width: 20px;
        text-align: center;
    }

    /* Specialized hover styling elements targeting logout link safety checks */
    .logout-btn:hover {
        background-color: #ef4444 !important;
        color: #ffffff !important;
    }

    /* Responsive adjustments for mid-range desktop resolution parameters */
    @media (max-width: 992px) {
        .reception-sidebar {
            transform: translateX(-100%); /* Hides sidebar smoothly to optimize dynamic canvas content scaling */
        }
    }
</style>