<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as receptionist
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$error_msg = "";
$report_period = isset($_GET['period']) ? $_GET['period'] : 'daily';
$report_date = isset($_GET['report_date']) ? $_GET['report_date'] : date('Y-m-d');

// -------------------------------------------------------------------------
// COMPILATION METRICS 1: Pipeline Breakdown by Appointment Status
// -------------------------------------------------------------------------
try {
    $status_sql = "SELECT status, COUNT(*) as total_count FROM appointments GROUP BY status ORDER BY total_count DESC";
    $status_stmt = $pdo->query($status_sql);
    $status_breakdown = $status_stmt->fetchAll();
} catch (PDOException $e) {
    $status_breakdown = [];
    $error_msg = "Metrics Extraction Error: " . $e->getMessage();
}

// -------------------------------------------------------------------------
// COMPILATION METRICS 2: Patient Mix Distribution by Species Density
// -------------------------------------------------------------------------
try {
    $species_sql = "SELECT species, COUNT(*) as patient_count FROM pets GROUP BY species ORDER BY patient_count DESC";
    $species_stmt = $pdo->query($species_sql);
    $species_breakdown = $species_stmt->fetchAll();
} catch (PDOException $e) {
    $species_breakdown = [];
}

// -------------------------------------------------------------------------
// COMPILATION METRICS 3: Workload Case Distribution Matrix per Vet Doctor
// -------------------------------------------------------------------------
try {
    $vet_sql = "SELECT u.full_name AS vet_name, 
                       COUNT(a.appointment_id) AS total_assigned_cases,
                       SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) AS resolved_cases,
                       SUM(CASE WHEN a.status = 'pending' THEN 1 ELSE 0 END) AS pending_cases,
                       SUM(CASE WHEN a.status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed_cases,
                       SUM(CASE WHEN a.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_cases
                FROM users u
                LEFT JOIN appointments a ON u.user_id = a.vet_id
                WHERE u.role = 'vet'
                GROUP BY u.user_id
                ORDER BY total_assigned_cases DESC";
    $vet_stmt = $pdo->query($vet_sql);
    $vet_breakdown = $vet_stmt->fetchAll();
} catch (PDOException $e) {
    $vet_breakdown = [];
}

// -------------------------------------------------------------------------
// COMPILATION METRICS 4: Appointment Summary by Period (using appointment_date)
// -------------------------------------------------------------------------
try {
    $appointment_sql = "";
    $appointment_params = [];
    
    if ($report_period === 'daily') {
        $appointment_sql = "SELECT 
                                DATE(appointment_date) as period_date, 
                                COUNT(*) as total_appointments,
                                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                                SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_count,
                                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count
                          FROM appointments 
                          WHERE DATE(appointment_date) = ? 
                          GROUP BY DATE(appointment_date)";
        $appointment_params = [$report_date];
    } elseif ($report_period === 'monthly') {
        $appointment_sql = "SELECT 
                                DATE_FORMAT(appointment_date, '%Y-%m') as period_date, 
                                COUNT(*) as total_appointments,
                                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                                SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_count,
                                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count
                          FROM appointments 
                          WHERE DATE_FORMAT(appointment_date, '%Y-%m') = ? 
                          GROUP BY DATE_FORMAT(appointment_date, '%Y-%m')";
        $appointment_params = [date('Y-m', strtotime($report_date))];
    } elseif ($report_period === 'yearly') {
        $appointment_sql = "SELECT 
                                DATE_FORMAT(appointment_date, '%Y') as period_date, 
                                COUNT(*) as total_appointments,
                                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                                SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_count,
                                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count
                          FROM appointments 
                          WHERE DATE_FORMAT(appointment_date, '%Y') = ? 
                          GROUP BY DATE_FORMAT(appointment_date, '%Y')";
        $appointment_params = [date('Y', strtotime($report_date))];
    }
    
    $appointment_stmt = $pdo->prepare($appointment_sql);
    $appointment_stmt->execute($appointment_params);
    $appointment_summary = $appointment_stmt->fetchAll();
} catch (PDOException $e) {
    $appointment_summary = [];
    $error_msg = "Appointment Summary Extraction Error: " . $e->getMessage();
}

// -------------------------------------------------------------------------
// COMPILATION METRICS 5: Detailed Appointment List by Period (using appointment_date)
// -------------------------------------------------------------------------
try {
    $details_sql = "";
    $details_params = [];
    
    if ($report_period === 'daily') {
        $details_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status,
                               u.full_name as vet_name,
                               p.pet_name, p.species,
                               o.full_name as owner_name
                        FROM appointments a
                        LEFT JOIN users u ON a.vet_id = u.user_id
                        LEFT JOIN pets p ON a.pet_id = p.pet_id
                        LEFT JOIN users o ON p.owner_id = o.user_id
                        WHERE DATE(a.appointment_date) = ?
                        ORDER BY a.appointment_date DESC, a.appointment_time DESC";
        $details_params = [$report_date];
    } elseif ($report_period === 'monthly') {
        $details_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status,
                               u.full_name as vet_name,
                               p.pet_name, p.species,
                               o.full_name as owner_name
                        FROM appointments a
                        LEFT JOIN users u ON a.vet_id = u.user_id
                        LEFT JOIN pets p ON a.pet_id = p.pet_id
                        LEFT JOIN users o ON p.owner_id = o.user_id
                        WHERE DATE_FORMAT(a.appointment_date, '%Y-%m') = ?
                        ORDER BY a.appointment_date DESC, a.appointment_time DESC";
        $details_params = [date('Y-m', strtotime($report_date))];
    } elseif ($report_period === 'yearly') {
        $details_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status,
                               u.full_name as vet_name,
                               p.pet_name, p.species,
                               o.full_name as owner_name
                        FROM appointments a
                        LEFT JOIN users u ON a.vet_id = u.user_id
                        LEFT JOIN pets p ON a.pet_id = p.pet_id
                        LEFT JOIN users o ON p.owner_id = o.user_id
                        WHERE DATE_FORMAT(a.appointment_date, '%Y') = ?
                        ORDER BY a.appointment_date DESC, a.appointment_time DESC";
        $details_params = [date('Y', strtotime($report_date))];
    }
    
    $details_stmt = $pdo->prepare($details_sql);
    $details_stmt->execute($details_params);
    $appointment_details = $details_stmt->fetchAll();
} catch (PDOException $e) {
    $appointment_details = [];
    $error_msg = "Appointment Details Extraction Error: " . $e->getMessage();
}

// Ingest structural frontend layout blocks wrappers
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="rcp-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #1e3d59; font-size: 24px; font-weight: 700; }
        .page-title-block p { color: #64748b; font-size: 14px; margin-top: 2px; }
        
        /* Print Button Styles */
        .report-controls {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8fafc;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }
        .report-controls .control-group {
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .report-controls label {
            font-size: 13px;
            font-weight: 600;
            color: #475569;
        }
        .report-controls select, 
        .report-controls input[type="date"],
        .report-controls input[type="month"],
        .report-controls input[type="number"] {
            padding: 8px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            color: #334155;
            background: #ffffff;
        }
        .btn-print {
            background-color: #1e3d59;
            color: #ffffff;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-print:hover {
            background-color: #13283b;
        }
        .btn-print-secondary {
            background-color: #17b978;
            color: #ffffff;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-print-secondary:hover {
            background-color: #119961;
        }
        
        /* Analytics Grid Infrastructure Layout */
        .analytics-dashboard-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 25px;
            margin-bottom: 30px;
        }
        @media (min-width: 992px) {
            .analytics-dashboard-grid { grid-template-columns: repeat(2, 1fr); }
        }

        .report-widget-card {
            background-color: #ffffff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0;
            padding: 25px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }
        .report-widget-card.wide-span { grid-column: 1 / -1; }
        
        .card-heading {
            color: #1e3d59; 
            font-size: 16px; 
            font-weight: 600;
            border-bottom: 2px solid #f1f5f9; 
            padding-bottom: 12px; 
            margin-bottom: 18px;
            display: flex; 
            justify-content: space-between; 
            align-items: center;
        }
        .card-heading-tag {
            background-color: #eff6ff; 
            color: #1e40af; 
            font-size: 11px;
            padding: 3px 8px; 
            border-radius: 4px; 
            border: 1px solid #bfdbfe; 
            font-weight: 600;
        }

        /* Unified Clean Report Data Tables Minimal Architecture */
        .report-data-table { 
            width: 100%; 
            border-collapse: collapse; 
            font-size: 14px; 
            text-align: left; 
        }
        .report-data-table th {
            background-color: #f8fafc; 
            color: #64748b; 
            padding: 10px 14px;
            font-weight: 600; 
            font-size: 12px; 
            text-transform: uppercase; 
            border-bottom: 1px solid #e2e8f0;
        }
        .report-data-table td { 
            padding: 12px 14px; 
            border-bottom: 1px solid #f1f5f9; 
            color: #334155; 
            vertical-align: middle; 
        }
        .report-data-table tr:hover { background-color: #f8fafc; }

        /* Status Pills Indicators Match Mapping */
        .status-badge {
            display: inline-block; 
            padding: 2px 8px; 
            border-radius: 4px; 
            font-size: 11px; 
            font-weight: 600; 
            text-transform: uppercase;
        }
        .status-badge.pending { background-color: #fef3c7; color: #d97706; }
        .status-badge.confirmed { background-color: #dbeafe; color: #1d4ed8; }
        .status-badge.completed { background-color: #d1fae5; color: #065f46; }
        .status-badge.cancelled { background-color: #fee2e2; color: #991b1b; }

        .species-icon-tag { font-size: 15px; margin-right: 6px; }
        .numeric-highlight { font-weight: 700; color: #1e3d59; font-size: 15px; }
        .empty-state-notice { text-align: center; padding: 30px; color: #94a3b8; font-style: italic; }

        /* Print-specific styles */
        @media print {
            .no-print {
                display: none !important;
            }
            .report-widget-card {
                border: 1px solid #ddd !important;
                break-inside: avoid;
                page-break-inside: avoid;
            }
            .analytics-dashboard-grid {
                display: block !important;
            }
            .report-widget-card {
                margin-bottom: 20px !important;
            }
            body {
                padding: 20px !important;
            }
            .rcp-main-content-canvas {
                margin: 0 !important;
                padding: 0 !important;
            }
            .report-data-table {
                font-size: 12px !important;
            }
            .report-data-table th,
            .report-data-table td {
                padding: 6px 10px !important;
            }
        }
    </style>

    <div class="page-title-block">
        <h2>Front Office Appointment Reports</h2>
        <p>Real-time analytics and management compilation summaries for appointment schedules and medical caseload metrics.</p>
    </div>

    <!-- Report Controls -->
    <div class="report-controls no-print">
        <form method="GET" action="" style="display: flex; gap: 15px; flex-wrap: wrap; align-items: center; width: 100%;">
            <div class="control-group">
                <label for="period">Report Period:</label>
                <select name="period" id="period" onchange="this.form.submit()">
                    <option value="daily" <?php echo $report_period === 'daily' ? 'selected' : ''; ?>>Daily</option>
                    <option value="monthly" <?php echo $report_period === 'monthly' ? 'selected' : ''; ?>>Monthly</option>
                    <option value="yearly" <?php echo $report_period === 'yearly' ? 'selected' : ''; ?>>Yearly</option>
                </select>
            </div>
            
            <div class="control-group">
                <label for="report_date">Date:</label>
                <?php if ($report_period === 'daily'): ?>
                    <input type="date" name="report_date" value="<?php echo $report_date; ?>" onchange="this.form.submit()">
                <?php elseif ($report_period === 'monthly'): ?>
                    <input type="month" name="report_date" value="<?php echo date('Y-m', strtotime($report_date)); ?>" onchange="this.form.submit()">
                <?php else: ?>
                    <input type="number" name="report_date" min="2020" max="2030" value="<?php echo date('Y', strtotime($report_date)); ?>" onchange="this.form.submit()" style="width: 100px;">
                <?php endif; ?>
            </div>
            
            <div class="control-group">
                <button type="button" class="btn-print" onclick="window.print()">🖨️ Print Report</button>
                <button type="button" class="btn-print-secondary" onclick="window.location.href='<?php echo $_SERVER['PHP_SELF']; ?>?period=daily&report_date=<?php echo date('Y-m-d'); ?>'">Reset to Today</button>
            </div>
        </form>
    </div>

    <?php if (!empty($error_msg)): ?>
        <div style="padding: 12px; background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; border-radius: 6px; margin-bottom: 20px; font-size: 14px;">
            <?php echo htmlspecialchars($error_msg); ?>
        </div>
    <?php endif; ?>

    <!-- Report Period Summary -->
    <div class="report-widget-card wide-span" style="background: #f0f9ff; border: 1px solid #bae6fd; margin-bottom: 25px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div>
                <strong style="color: #0369a1; font-size: 16px;">
                    📅 <?php echo ucfirst($report_period); ?> Appointment Report Summary
                </strong>
                <span style="color: #475569; margin-left: 15px; font-size: 14px;">
                    <?php 
                    if ($report_period === 'daily') {
                        echo 'For: ' . date('F d, Y', strtotime($report_date));
                    } elseif ($report_period === 'monthly') {
                        echo 'For: ' . date('F Y', strtotime($report_date . '-01'));
                    } else {
                        echo 'For: ' . date('Y', strtotime($report_date . '-01-01'));
                    }
                    ?>
                </span>
            </div>
            <div style="font-size: 14px; color: #64748b;">
                Generated on: <?php echo date('F d, Y H:i:s'); ?>
            </div>
        </div>
        
        <?php if (count($appointment_summary) > 0): ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-top: 15px;">
                <?php foreach ($appointment_summary as $row): ?>
                    <div style="background: white; padding: 12px; border-radius: 6px; text-align: center; border: 1px solid #e2e8f0;">
                        <div style="font-size: 24px; font-weight: 700; color: #1e3d59;">
                            <?php echo (int)$row['total_appointments']; ?>
                        </div>
                        <div style="font-size: 12px; color: #64748b;">Total Appointments</div>
                    </div>
                    <div style="background: white; padding: 12px; border-radius: 6px; text-align: center; border: 1px solid #e2e8f0;">
                        <div style="font-size: 24px; font-weight: 700; color: #d97706;">
                            <?php echo (int)$row['pending_count']; ?>
                        </div>
                        <div style="font-size: 12px; color: #64748b;">Pending</div>
                    </div>
                    <div style="background: white; padding: 12px; border-radius: 6px; text-align: center; border: 1px solid #e2e8f0;">
                        <div style="font-size: 24px; font-weight: 700; color: #1d4ed8;">
                            <?php echo (int)$row['confirmed_count']; ?>
                        </div>
                        <div style="font-size: 12px; color: #64748b;">Confirmed</div>
                    </div>
                    <div style="background: white; padding: 12px; border-radius: 6px; text-align: center; border: 1px solid #e2e8f0;">
                        <div style="font-size: 24px; font-weight: 700; color: #065f46;">
                            <?php echo (int)$row['completed_count']; ?>
                        </div>
                        <div style="font-size: 12px; color: #64748b;">Completed</div>
                    </div>
                    <div style="background: white; padding: 12px; border-radius: 6px; text-align: center; border: 1px solid #e2e8f0;">
                        <div style="font-size: 24px; font-weight: 700; color: #991b1b;">
                            <?php echo (int)$row['cancelled_count']; ?>
                        </div>
                        <div style="font-size: 12px; color: #64748b;">Cancelled</div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="text-align: center; padding: 20px; color: #94a3b8;">
                No appointment data available for this period.
            </div>
        <?php endif; ?>
    </div>

    <div class="analytics-dashboard-grid">
        
        <!-- Status Breakdown Widget -->
        <div class="report-widget-card">
            <div class="card-heading">
                <span>📊 Appointment Pipeline Traffic Volumes</span>
                <span class="card-heading-tag">By Pipeline Stage</span>
            </div>
            
            <?php if (count($status_breakdown) > 0): ?>
                <table class="report-data-table">
                    <thead>
                        <tr>
                            <th>Pipeline Scheduling Stage</th>
                            <th style="text-align: right;">Total Aggregated Cases</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($status_breakdown as $row): ?>
                            <tr>
                                <td>
                                    <span class="status-badge <?php echo htmlspecialchars(strtolower($row['status'])); ?>">
                                        <?php echo htmlspecialchars($row['status']); ?>
                                    </span>
                                </td>
                                <td style="text-align: right;" class="numeric-highlight">
                                    <?php echo $row['total_count']; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state-notice">No booking history indicators registered to generate analytics pipelines.</div>
            <?php endif; ?>
        </div>

        <!-- Species Breakdown Widget -->
        <div class="report-widget-card">
            <div class="card-heading">
                <span>🐾 Patient Caseload Density Distribution</span>
                <span class="card-heading-tag">By Animal Species</span>
            </div>

            <?php if (count($species_breakdown) > 0): ?>
                <table class="report-data-table">
                    <thead>
                        <tr>
                            <th>Animal Classification Species</th>
                            <th style="text-align: right;">Active Patient Profiles</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($species_breakdown as $row): ?>
                            <tr>
                                <td>
                                    <span class="species-icon-tag">🩺</span> 
                                    <strong><?php echo htmlspecialchars(ucfirst($row['species'])); ?></strong>
                                </td>
                                <td style="text-align: right;" class="numeric-highlight">
                                    <?php echo $row['patient_count']; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state-notice">No patient animal profiles registered to compile species matrices.</div>
            <?php endif; ?>
        </div>

        <!-- Veterinarian Workload Widget -->
        <div class="report-widget-card wide-span">
            <div class="card-heading">
                <span>💼 Medical Practitioner Workload & Schedule Case Distribution</span>
                <span class="card-heading-tag">Veterinarian Logs Matrix</span>
            </div>

            <?php if (count($vet_breakdown) > 0): ?>
                <table class="report-data-table">
                    <thead>
                        <tr>
                            <th>Veterinary Medical Officer</th>
                            <th style="text-align: center;">Total Cases</th>
                            <th style="text-align: center;">Completed</th>
                            <th style="text-align: center;">Confirmed</th>
                            <th style="text-align: center;">Pending</th>
                            <th style="text-align: center;">Cancelled</th>
                            <th>Workload Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($vet_breakdown as $row): ?>
                            <tr>
                                <td><strong>Dr. <?php echo htmlspecialchars($row['vet_name']); ?></strong></td>
                                <td style="text-align: center;" class="numeric-highlight"><?php echo (int)$row['total_assigned_cases']; ?></td>
                                <td style="text-align: center; color: #065f46; font-weight: 600;"><?php echo (int)$row['resolved_cases']; ?></td>
                                <td style="text-align: center; color: #1d4ed8; font-weight: 600;"><?php echo (int)$row['confirmed_cases']; ?></td>
                                <td style="text-align: center; color: #d97706; font-weight: 600;"><?php echo (int)$row['pending_cases']; ?></td>
                                <td style="text-align: center; color: #991b1b; font-weight: 600;"><?php echo (int)$row['cancelled_cases']; ?></td>
                                <td>
                                    <?php 
                                    if ($row['total_assigned_cases'] == 0) {
                                        echo '<span style="color:#94a3b8; font-size:12px;">No assignments</span>';
                                    } elseif ($row['pending_cases'] > 3) {
                                        echo '<span style="color:#b91c1c; font-size:12px; font-weight:600;">⚠️ High Volume</span>';
                                    } elseif ($row['pending_cases'] > 1) {
                                        echo '<span style="color:#d97706; font-size:12px; font-weight:500;">🟡 Moderate</span>';
                                    } else {
                                        echo '<span style="color:#16a34a; font-size:12px; font-weight:500;">🟢 Optimal</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state-notice">No medical officer records available to compile tracking metrics.</div>
            <?php endif; ?>
        </div>

        <!-- Detailed Appointment List -->
        <div class="report-widget-card wide-span">
            <div class="card-heading">
                <span>📋 Detailed Appointment List</span>
                <span class="card-heading-tag"><?php echo ucfirst($report_period); ?> Records</span>
            </div>

            <?php if (count($appointment_details) > 0): ?>
                <div style="overflow-x: auto;">
                    <table class="report-data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Date & Time</th>
                                <th>Pet Name</th>
                                <th>Species</th>
                                <th>Owner</th>
                                <th>Veterinarian</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $counter = 1; ?>
                            <?php foreach ($appointment_details as $row): ?>
                                <tr>
                                    <td><?php echo $counter++; ?></td>
                                    <td>
                                        <?php echo date('M d, Y', strtotime($row['appointment_date'])); ?>
                                        <br>
                                        <span style="font-size: 12px; color: #64748b;">
                                            <?php echo date('h:i A', strtotime($row['appointment_time'])); ?>
                                        </span>
                                    </td>
                                    <td><strong><?php echo htmlspecialchars($row['pet_name'] ?? 'N/A'); ?></strong></td>
                                    <td><?php echo htmlspecialchars(ucfirst($row['species'] ?? 'N/A')); ?></td>
                                    <td><?php echo htmlspecialchars($row['owner_name'] ?? 'N/A'); ?></td>
                                    <td>Dr. <?php echo htmlspecialchars($row['vet_name'] ?? 'Unassigned'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo htmlspecialchars(strtolower($row['status'])); ?>">
                                            <?php echo htmlspecialchars($row['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div style="margin-top: 15px; font-size: 13px; color: #64748b; text-align: right;">
                    Total Records: <?php echo count($appointment_details); ?>
                </div>
            <?php else: ?>
                <div class="empty-state-notice">No appointment records found for this period.</div>
            <?php endif; ?>
        </div>

    </div>
</div>

<?php 
// Ingest secure architectural bottom structural components layout frames closures safely
include('includes/footer.php'); 
?>