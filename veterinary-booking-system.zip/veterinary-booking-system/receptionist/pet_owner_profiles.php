<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as receptionist
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// POST ACTION: CREATE A NEW CLIENT ACCOUNT (PET OWNER)
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register_owner') {
    $full_name = trim($_POST['full_name']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $password  = trim($_POST['password']);

    if (!empty($full_name) && !empty($email) && !empty($phone) && !empty($password)) {
        try {
            // Check if email already exists in the system registry
            $check_stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
            $check_stmt->execute([$email]);
            
            if ($check_stmt->rowCount() > 0) {
                $message = "❌ A client with this email address already exists.";
                $message_class = "msg-danger";
            } else {
                // Hash the provided password
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                
                $insert_sql = "INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, 'pet_owner')";
                $insert_stmt = $pdo->prepare($insert_sql);
                $insert_stmt->execute([$full_name, $email, $phone, $hashed_password]);
                
                $message = "🎉 New client profile created successfully!";
                $message_class = "msg-success";
            }
        } catch (PDOException $e) {
            $message = "Database Registration Error: " . $e->getMessage();
            $message_class = "msg-danger";
        }
    } else {
        $message = "Please complete all validation fields to register a client.";
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// READ ACTION: FETCH CLIENT DIRECTORY GRID WITH DYNAMIC PATIENT MATRICES
// -------------------------------------------------------------------------
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    // Advanced LEFT JOIN query with GROUP_CONCAT to compile a client's pets into a single row cell
    $query_str = "SELECT u.user_id, u.full_name, u.email, u.phone, u.created_at,
                         GROUP_CONCAT(CONCAT(p.pet_name, ' (', p.species, ')') SEPARATOR ', ') AS registered_pets
                  FROM users u
                  LEFT JOIN pets p ON u.user_id = p.owner_id
                  WHERE u.role = 'pet_owner'";
    
    $params = [];
    if (!empty($search_query)) {
        $query_str .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
        $params[] = '%' . $search_query . '%';
        $params[] = '%' . $search_query . '%';
        $params[] = '%' . $search_query . '%';
    }
    
    $query_str .= " GROUP BY u.user_id ORDER BY u.full_name ASC";
    
    $stmt = $pdo->prepare($query_str);
    $stmt->execute($params);
    $client_directory = $stmt->fetchAll();
} catch (PDOException $e) {
    $client_directory = [];
    $message = "Error extracting client profile matrices: " . $e->getMessage();
    $message_class = "msg-danger";
}

// Ingest layout frames layout architectures
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="rcp-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #1e3d59; font-size: 24px; font-weight: 700; }
        
        .profiles-split-layout { display: grid; grid-template-columns: 1fr; gap: 30px; }
        @media (min-width: 1200px) {
            .profiles-split-layout { grid-template-columns: 350px 1fr; align-items: start; }
        }

        /* Responsive UI Card Framework components */
        .workspace-form-card {
            background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0;
            padding: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); margin-bottom: 20px;
        }
        .card-heading {
            color: #1e3d59; font-size: 18px; font-weight: 600;
            border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 20px;
        }

        .form-group { display: flex; flex-direction: column; margin-bottom: 16px; }
        .form-group label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control {
            padding: 11px 13px; border: 1px solid #cbd5e1; border-radius: 6px;
            font-size: 14px; color: #334155; background-color: #ffffff;
        }
        .form-control:focus { outline: none; border-color: #17b978; }

        .submit-action-btn {
            background-color: #17b978; color: #ffffff; border: none; padding: 12px;
            border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px;
            width: 100%; transition: background 0.2s; margin-top: 5px;
        }
        .submit-action-btn:hover { background-color: #119961; }

        /* Filter Controls Styling */
        .search-container-box { display: flex; gap: 10px; margin-bottom: 20px; }
        .search-container-box .form-control { flex: 1; }
        .filter-btn {
            background-color: #1e3d59; color: #ffffff; border: none; padding: 0 20px;
            border-radius: 6px; font-weight: 600; font-size: 14px; cursor: pointer; height: 44px;
        }
        .filter-btn:hover { background-color: #13283b; }

        /* Directory Grid Table Elements */
        .directory-table { width: 100%; border-collapse: collapse; font-size: 14px; text-align: left; }
        .directory-table th {
            background-color: #f8fafc; color: #64748b; padding: 12px 16px;
            font-weight: 600; font-size: 12px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;
        }
        .directory-table td { padding: 14px 16px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: top; }
        .directory-table tr:hover { background-color: #f8fafc; }

        /* Patient Dynamic Badging Markers Styles */
        .pet-badge-string {
            display: inline-block; background-color: #eff6ff; color: #1e40af;
            font-size: 12px; font-weight: 500; padding: 4px 10px; border-radius: 4px;
            border: 1px solid #bfdbfe; line-height: 1.4; max-width: 340px;
        }
        .no-pets-text { color: #94a3b8; font-style: italic; font-size: 12px; }

        /* Flash Message Alert Elements */
        .alert-banner { padding: 12px 15px; border-radius: 6px; margin-bottom: 25px; font-size: 14px; font-weight: 500; }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        .meta-subtext { font-size: 12px; color: #64748b; margin-top: 2px; }
    </style>

    <div class="page-title-block">
        <h2>Pet Owner Profiles Registry</h2>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="profiles-split-layout">
        
        <!-- LEFT COLUMN: Registration Form -->
        <div class="workspace-form-card">
            <h3 class="card-heading">👤 Register New Owner</h3>
            <form action="pet_owner_profiles.php" method="POST">
                <input type="hidden" name="action" value="register_owner">
                
                <div class="form-group">
                    <label for="full_name">Full Name *</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" placeholder="e.g., Benson Omwega" required>
                </div>

                <div class="form-group">
                    <label for="email">Email Address *</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="benson@example.com" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number *</label>
                    <input type="text" id="phone" name="phone" class="form-control" placeholder="e.g., 0712345678" required>
                </div>
                
                <!-- FIXED: Changed type to password and name to password -->
                <div class="form-group">
                    <label for="password">Password *</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Create a strong password" required>
                </div>

                <button type="submit" class="submit-action-btn">👤 Initialize Client Account</button>
            </form>
        </div>

        <!-- RIGHT COLUMN: Client Directory -->
        <div class="workspace-form-card">
            <h3 class="card-heading">🗂️ Centralized Client Accounts Directory</h3>
            
            <form action="pet_owner_profiles.php" method="GET">
                <div class="search-container-box">
                    <input type="text" name="search" class="form-control" placeholder="Search accounts by name, email database values, or phone key registers..." value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit" class="filter-btn">🔍 Search Registry</button>
                    <?php if (!empty($search_query)): ?>
                        <a href="pet_owner_profiles.php" class="filter-btn" style="background-color:#64748b; display:flex; align-items:center; text-decoration:none;">Reset</a>
                    <?php endif; ?>
                </div>
            </form>

            <?php if (count($client_directory) > 0): ?>
                <table class="directory-table">
                    <thead>
                        <tr>
                            <th>Client Profile Details</th>
                            <th>Contact Information</th>
                            <th>Patient Records Registered</th>
                            <th>Onboarding Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($client_directory as $client): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($client['full_name']); ?></strong>
                                    <div class="meta-subtext">ID Reference: Account #<?php echo $client['user_id']; ?></div>
                                </td>

                                <td>
                                    <div>📧 <?php echo htmlspecialchars($client['email']); ?></div>
                                    <div class="meta-subtext" style="margin-top: 3px;">📞 <?php echo htmlspecialchars($client['phone']); ?></div>
                                </td>

                                <td>
                                    <?php if (!empty($client['registered_pets'])): ?>
                                        <div class="pet-badge-string">
                                            🐾 <?php echo htmlspecialchars($client['registered_pets']); ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="no-pets-text">❌ No pet records initialized yet</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <span class="meta-subtext"><?php echo date('M d, Y', strtotime($client['created_at'])); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 50px 20px; color: #94a3b8; font-style: italic;">
                    No client or pet owner records match your system search queries.
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php 
// Ingest secure architectural bottom layout closures framework safely
include('includes/footer.php'); 
?>