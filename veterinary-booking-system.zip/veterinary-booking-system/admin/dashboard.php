<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as system root administrator
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$telemetry = [];

// -------------------------------------------------------------------------
// DATA AGGREGATION: Fetch High-Level Enterprise System Statistics
// -------------------------------------------------------------------------
try {
    // Count breakdown by platform access role mapping attributes
    $role_counts = $pdo->query("SELECT role, COUNT(*) as volume FROM users GROUP BY role")->fetchAll(PDO::FETCH_KEY_PAIR);
    
    $telemetry['total_vets']          = $role_counts['vet'] ?? 0;
    $telemetry['total_receptionists'] = $role_counts['receptionist'] ?? 0;
    $telemetry['total_clients']       = $role_counts['pet_owner'] ?? 0;
    
    // Total aggregate count of registered veterinary medical patient profiles
    $telemetry['total_patients'] = $pdo->query("SELECT COUNT(*) FROM pets")->fetchColumn();
    
    // Total aggregate count of system appointment allocations processed
    $telemetry['total_appointments'] = $pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();

    // -------------------------------------------------------------------------
    // READ ACTION: Fetch Recent System User Registrations Across All Nodes
    // -------------------------------------------------------------------------
    $recent_users_sql = "SELECT user_id, full_name, email, role, created_at 
                         FROM users 
                         ORDER BY created_at DESC 
                         LIMIT 5";
    $recent_users = $pdo->query($recent_users_sql)->fetchAll();

    // -------------------------------------------------------------------------
    // READ ACTION: Fetch Global Clinic Schedule Overviews Breakdown
    // -------------------------------------------------------------------------
    $pipeline_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status,
                            p.pet_name, u_vet.full_name AS vet_name
                     FROM appointments a
                     INNER JOIN pets p ON a.pet_id = p.pet_id
                     INNER JOIN users u_vet ON a.vet_id = u_vet.user_id
                     ORDER BY a.appointment_date DESC, a.appointment_time DESC
                     LIMIT 5";
    $recent_pipeline = $pdo->query($pipeline_sql)->fetchAll();

} catch (PDOException $e) {
    $error_msg = "Critical Telemetry Ingestion Failure: " . $e->getMessage();
}

// Ingest system administrator structural frames layouts
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="adm-main-content-canvas">

    <style>
        .admin-header-block { margin-bottom: 25px; }
        .admin-header-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        .admin-header-block p { color: #64748b; font-size: 14px; margin-top: 2px; }

        /* Telemetry Cards Grid System Configuration */
        .telemetry-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .telemetry-card {
            background-color: #ffffff; border-radius: 8px; padding: 20px;
            border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.01);
            display: flex; align-items: center; justify-content: space-between;
        }
        .telemetry-info h3 { font-size: 26px; color: #0f172a; font-weight: 700; line-height: 1.2; }
        .telemetry-info p { font-size: 13px; color: #64748b; font-weight: 500; margin-top: 3px; }
        
        .telemetry-badge {
            width: 44px; height: 44px; border-radius: 6px; font-size: 20px;
            display: flex; justify-content: center; align-items: center;
        }
        .bg-slate { background-color: #f1f5f9; color: #334155; }
        .bg-emerald { background-color: #ecfdf5; color: #059669; }
        .bg-blue { background-color: #eff6ff; color: #2563eb; }
        .bg-indigo { background-color: #e0e7ff; color: #4f46e5; }

        /* Multi-Column Table Matrix Container */
        .matrix-split-row {
            display: grid;
            grid-template-columns: 1fr;
            gap: 25px;
        }
        @media (min-width: 1200px) {
            .matrix-split-row { grid-template-columns: repeat(2, 1fr); }
        }

        .matrix-data-card {
            background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0;
            padding: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.01);
        }
        .matrix-heading-bar {
            display: flex; justify-content: space-between; align-items: center;
            border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 18px;
        }
        .matrix-heading-bar h3 { color: #0f172a; font-size: 16px; font-weight: 600; }
        .matrix-action-link {
            font-size: 13px; color: #10b981; font-weight: 600; text-decoration: none;
        }
        .matrix-action-link:hover { text-decoration: underline; }

        /* Admin Module Minimalist Functional Table Structure */
        .admin-dashboard-table { width: 100%; border-collapse: collapse; font-size: 13.5px; text-align: left; }
        .admin-dashboard-table th {
            background-color: #f8fafc; color: #64748b; padding: 10px 14px;
            font-weight: 600; font-size: 11.5px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;
        }
        .admin-dashboard-table td { padding: 12px 14px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: middle; }
        .admin-dashboard-table tr:hover { background-color: #f8fafc; }

        /* System Node Role Tags */
        .role-tag {
            display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase;
        }
        .role-tag.admin { background-color: #fee2e2; color: #991b1b; }
        .role-tag.vet { background-color: #e0e7ff; color: #3730a3; }
        .role-tag.receptionist { background-color: #fef3c7; color: #92400e; }
        .role-tag.pet_owner { background-color: #e2e8f0; color: #334155; }

        .pipeline-status { font-size: 11px; font-weight: 600; text-transform: uppercase; color: #64748b; }
        .pipeline-status.completed { color: #16a34a; }
        .pipeline-status.pending { color: #d97706; }
        .pipeline-status.confirmed { color: #2563eb; }
        .pipeline-status.cancelled { color: #dc2626; }
        
        .meta-text-sm { font-size: 12px; color: #64748b; }
    </style>

    <div class="admin-header-block">
        <h2>System Engine Analytics</h2>
        <p>Enterprise administration command core — Monitoring active application matrices and node configurations.</p>
    </div>

    <?php if (isset($error_msg)): ?>
        <div style="padding: 12px; background-color: #fee2e2; color: #991b1b; border-radius: 6px; font-size: 14px; margin-bottom: 20px;">
            <?php echo htmlspecialchars($error_msg); ?>
        </div>
    <?php endif; ?>

    <div class="telemetry-grid">
        <div class="telemetry-card">
            <div class="telemetry-info">
                <h3><?php echo $telemetry['total_vets'] ?? 0; ?></h3>
                <p>Medical Vets</p>
            </div>
            <div class="telemetry-badge bg-indigo">🥼</div>
        </div>

        <div class="telemetry-card">
            <div class="telemetry-info">
                <h3><?php echo $telemetry['total_receptionists'] ?? 0; ?></h3>
                <p>Front Desk Personnel</p>
            </div>
            <div class="telemetry-badge bg-blue">🛎️</div>
        </div>

        <div class="telemetry-card">
            <div class="telemetry-info">
                <h3><?php echo $telemetry['total_clients'] ?? 0; ?></h3>
                <p>Registered Clients</p>
            </div>
            <div class="telemetry-badge bg-slate">👥</div>
        </div>

        <div class="telemetry-card">
            <div class="telemetry-info">
                <h3><?php echo $telemetry['total_patients'] ?? 0; ?></h3>
                <p>Animal Patient Profiles</p>
            </div>
            <div class="telemetry-badge bg-emerald">🐾</div>
        </div>

        <div class="telemetry-card">
            <div class="telemetry-info">
                <h3><?php echo $telemetry['total_appointments'] ?? 0; ?></h3>
                <p>Total Bookings Logged</p>
            </div>
            <div class="telemetry-badge bg-slate">📅</div>
        </div>
    </div>

    <div class="matrix-split-row">
        
        <div class="matrix-data-card">
            <div class="matrix-heading-bar">
                <h3>Recent System Registrations</h3>
                <a href="manage_users.php" class="matrix-action-link">⚙️ Access Identity Controls</a>
            </div>
            
            <table class="admin-dashboard-table">
                <thead>
                    <tr>
                        <th>User Account Identity</th>
                        <th>Access Role Node</th>
                        <th>Created Date Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($recent_users) > 0): ?>
                        <?php foreach ($recent_users as $user): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                    <div class="meta-text-sm"><?php echo htmlspecialchars($user['email']); ?></div>
                                </td>
                                <td>
                                    <span class="role-tag <?php echo htmlspecialchars($user['role']); ?>">
                                        <?php echo htmlspecialchars($user['role'] === 'pet_owner' ? 'Client' : $user['role']); ?>
                                    </span>
                                </td>
                                <td class="meta-text-sm"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3" style="text-align:center; color:#94a3b8; font-style:italic; padding:20px;">No account profiles found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="matrix-data-card">
            <div class="matrix-heading-bar">
                <h3>Global Appointment Queue Snapshot</h3>
                <a href="reports.php" class="matrix-action-link">📊 View System Reports</a>
            </div>

            <table class="admin-dashboard-table">
                <thead>
                    <tr>
                        <th>Date/Time Target</th>
                        <th>Patient/Doctor Matrix</th>
                        <th>Status Flag</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($recent_pipeline) > 0): ?>
                        <?php foreach ($recent_pipeline as $ap): ?>
                            <tr>
                                <td>
                                    <strong><?php echo date('M d, Y', strtotime($ap['appointment_date'])); ?></strong>
                                    <div class="meta-text-sm">⏰ <?php echo date('h:i A', strtotime($ap['appointment_time'])); ?></div>
                                </td>
                                <td>
                                    <strong>🐾 <?php echo htmlspecialchars($ap['pet_name']); ?></strong>
                                    <div class="meta-text-sm">Doctor: Dr. <?php echo htmlspecialchars($ap['vet_name']); ?></div>
                                </td>
                                <td>
                                    <span class="pipeline-status <?php echo htmlspecialchars(strtolower($ap['status'])); ?>">
                                        <?php echo htmlspecialchars($ap['status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3" style="text-align:center; color:#94a3b8; font-style:italic; padding:20px;">No operational clinical schedules logged.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

</div>

<?php 
// Ingest admin layout closure frames safely
include('includes/footer.php'); 
?>