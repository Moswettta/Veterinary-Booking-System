<?php
// Secure session verification framework 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Extract the active page filename to dynamically highlight the current sidebar button link
$current_page = basename($_SERVER['PHP_SELF']);
?>

<aside class="admin-sidebar">
    
    <div class="sidebar-nav-group">
        <a href="dashboard.php" class="sidebar-link <?php echo ($current_page == 'dashboard.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">🖥️</span> Admin Dashboard
        </a>
        
        <a href="manage_users.php" class="sidebar-link <?php echo ($current_page == 'manage_users.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">👥</span> Manage Users
        </a>
        
        <a href="assign_vet.php" class="sidebar-link <?php echo ($current_page == 'configurations.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">⚙️</span> assign vet
        </a>
        
        <a href="reports.php" class="sidebar-link <?php echo ($current_page == 'reports.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">📊</span> System Reports
        </a>
    </div>

    <div class="sidebar-footer-group">
        <a href="profile.php" class="sidebar-link <?php echo ($current_page == 'profile.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">👤</span> Profile Settings
        </a>
        
        <a href="../logout.php" class="sidebar-link logout-btn">
            <span class="link-icon">🚪</span> Emergency Exit
        </a>
    </div>

</aside>

<style>
    .admin-sidebar {
        width: 260px;
        background-color: #0f172a; /* Sleek slate/dark admin canvas identity */
        height: calc(100vh - 65px);
        position: fixed;
        top: 65px; /* Sits flush beneath your 65px header topbar layout */
        left: 0;
        z-index: 999;
        display: flex;
        flex-direction: column;
        justify-content: space-between; /* Securely pins navigation items at the top and actions at the bottom */
        padding: 20px 0;
        border-right: 1px solid #1e293b;
    }

    .sidebar-nav-group, 
    .sidebar-footer-group {
        display: flex;
        flex-direction: column;
        width: 100%;
        padding: 0 12px;
    }

    /* Strict isolation divider frame styling placed above bottom utilities */
    .sidebar-footer-group {
        border-top: 1px solid #1e293b;
        padding-top: 15px;
        margin-top: auto;
    }

    /* Core link styling configuration parameters */
    .sidebar-link {
        display: flex;
        align-items: center;
        gap: 12px;
        color: #94a3b8;
        text-decoration: none;
        padding: 12px 16px;
        font-size: 14px;
        font-weight: 500;
        border-radius: 6px;
        margin-bottom: 4px;
        transition: all 0.2s ease;
    }

    .sidebar-link:hover {
        background-color: #1e293b;
        color: #f8fafc;
    }

    /* Dynamic active directory highlighting utilizing administrative actions green */
    .active-link {
        background-color: #10b981 !important; 
        color: #ffffff !important;
        font-weight: 600;
    }

    .link-icon {
        font-size: 16px;
        display: inline-block;
        width: 20px;
        text-align: center;
    }

    /* Specialized hover styling elements targeting session exit parameters */
    .logout-btn:hover {
        background-color: #ef4444 !important;
        color: #ffffff !important;
    }

    /* Responsive adjustments for mid-range resolution monitoring parameters */
    @media (max-width: 992px) {
        .admin-sidebar {
            transform: translateX(-100%); /* Hides sidebar smoothly to optimize dynamic canvas content scaling */
        }
    }
</style>