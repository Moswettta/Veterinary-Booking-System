<?php
// Establish secure session isolation framework
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Access Control Guard: Ensure only logged-in administrators can pass
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // If no valid session exists, boot the browser back to the root-level gateway login file
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrative Command | Oakland Veterinary Clinic</title>
    
    <style>
        /* Modern Minimalist Reset Grid and CSS Root Variables */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --admin-navy: #0f172a;       /* Dark slate/navy for professional admin branding */
            --accent-green: #10b981;     /* Clean functional actions green */
            --bg-canvas: #f8fafc;        /* Soft neutral main page viewport background */
            --panel-border: #e2e8f0;     /* Minimal card divider framework borders */
            --text-main: #1e293b;        /* Balanced text visibility slate */
            --text-muted: #64748b;       /* Secondary labeling element color */
        }

        body {
            background-color: var(--bg-canvas);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Central Admin Top Control Bar Layer */
        .admin-topbar {
            background-color: #ffffff;
            height: 65px;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 25px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
            border-bottom: 1px solid var(--panel-border);
        }

        .brand-admin-identity {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--admin-navy);
            font-weight: 700;
            font-size: 18px;
            letter-spacing: -0.3px;
        }
        
        .brand-admin-badge {
            background-color: #fef2f2;
            color: #dc2626;
            font-size: 11px;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 4px;
            border: 1px solid #fca5a5;
            text-transform: uppercase;
        }

        /* Right Hand Account Status Blocks */
        .admin-meta-box {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .active-user-tag {
            text-align: right;
        }

        .user-role-label {
            font-size: 11px;
            color: var(--text-muted);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .user-profile-name {
            font-size: 14px;
            color: var(--admin-navy);
            font-weight: 600;
        }

        .avatar-circle {
            width: 38px;
            height: 38px;
            background-color: var(--admin-navy);
            color: #ffffff;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 600;
            font-size: 14px;
            border: 2px solid #ffffff;
            box-shadow: 0 0 0 2px var(--accent-green);
        }

        /* Core Application Split Layout Alignment System */
        .admin-workspace-wrapper {
            display: flex;
            margin-top: 65px; /* Offset push to prevent content hiding beneath topbar */
            min-height: calc(100vh - 65px);
            width: 100%;
        }

        /* Target class defining the working interface canvas windows */
        .adm-main-content-canvas {
            flex: 1;
            padding: 30px;
            background-color: var(--bg-canvas);
            margin-left: 260px; /* Aligns canvas directly out of sidebar width boundary */
            transition: all 0.3s ease;
        }

        /* Responsive Breakpoint Adaptors for Smaller Screen Monitors */
        @media (max-width: 992px) {
            .adm-main-content-canvas {
                margin-left: 0; /* Snap full width if grids scale down */
                padding: 20px;
            }
        }
    </style>
</head>
<body>

    <nav class="admin-topbar">
        <div class="brand-admin-identity">
            <span>🛡️</span> Oakland Vet Clinic 
            <span class="brand-admin-badge">System Root</span>
        </div>
        
        <div class="admin-meta-box">
            <div class="active-user-tag">
                <div class="user-role-label">System Admin</div>
                <div class="user-profile-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
            </div>
            <div class="avatar-circle">
                <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
            </div>
        </div>
    </nav>

    <div class="admin-workspace-wrapper">