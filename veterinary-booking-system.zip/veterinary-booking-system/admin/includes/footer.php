<?php
// Secure session framework validation
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
    </div> <footer class="admin-system-footer">
        <div class="footer-content-alignment">
            <div>&copy; <?php echo date('Y'); ?> <strong>Oakland Veterinary Clinic</strong>. All Rights Reserved.</div>
            <div class="system-engine-tag">Engine Node: <span class="status-indicator-dot"></span> Core v1.2.0</div>
        </div>
    </footer>

    <style>
        .admin-system-footer {
            background-color: #ffffff;
            border-top: 1px solid #e2e8f0;
            padding: 15px 30px;
            font-size: 12.5px;
            color: #64748b;
            width: 100%;
            position: relative;
            z-index: 998;
            margin-top: auto; /* Pushes footer to the bottom of the viewport canvas */
        }
        
        .footer-content-alignment {
            display: flex;
            justify-content: space-between;
            align-items: center;
            /* Offsets layout to match the sidebar restriction boundary */
            margin-left: 260px; 
            transition: all 0.3s ease;
        }

        .system-engine-tag {
            display: flex;
            align-items: center;
            gap: 6px;
            font-family: monospace;
            background-color: #f8fafc;
            padding: 2px 8px;
            border-radius: 4px;
            border: 1px solid #e2e8f0;
        }

        .status-indicator-dot {
            width: 7px;
            height: 7px;
            background-color: #10b981; /* Operations active green */
            border-radius: 50%;
            display: inline-block;
        }

        /* Responsive Adaptability Rule adjustments for screen resizing metrics */
        @media (max-width: 992px) {
            .footer-content-alignment {
                margin-left: 0;
                flex-direction: column;
                gap: 8px;
                text-align: center;
            }
        }
    </style>
</body>
</html>