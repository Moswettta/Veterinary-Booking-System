<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as system root administrator
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$message = "";
$message_class = "";
$admin_id = (int)$_SESSION['user_id'];

// -------------------------------------------------------------------------
// POST ACTION: PROCESS PROFILE METADATA & PASSWORD ALTERATIONS
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // ACTION A: UPDATE ACCOUNT PROFILE DATA
    if ($_POST['action'] === 'update_profile') {
        $full_name = trim($_POST['full_name']);
        $email     = trim($_POST['email']);
        $phone     = trim($_POST['phone']);

        if (!empty($full_name) && !empty($email) && !empty($phone)) {
            try {
                $update_sql = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ? AND role = 'admin'";
                $stmt = $pdo->prepare($update_sql);
                $stmt->execute([$full_name, $email, $phone, $admin_id]);

                $message = "👤 Profile configuration updates applied successfully!";
                $message_class = "msg-success";
            } catch (PDOException $e) {
                if ($e->getCode() == 23000) { // Catch duplicate key constraint check for email unique key
                    $message = "Profile Update Denied: The specified email address is already tied to another account node.";
                } else {
                    $message = "Pipeline Error: " . $e->getMessage();
                }
                $message_class = "msg-danger";
            }
        } else {
            $message = "Validation Error: All mandatory fields are required to process updates.";
            $message_class = "msg-danger";
        }
    }

    // ACTION B: PROCESS CRITICAL PASSWORD MODIFICATION LOCKS
    if ($_POST['action'] === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password     = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
            try {
                // Verify current password against stored argon2id/bcrypt cryptographic value hash string
                $auth_stmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
                $auth_stmt->execute([$admin_id]);
                $user_data = $auth_stmt->fetch();

                if ($user_data && password_verify($current_password, $user_data['password'])) {
                    if ($new_password === $confirm_password) {
                        // Re-hash secure configuration
                        $secured_hash = password_hash($new_password, PASSWORD_BCRYPT);
                        
                        $pass_update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                        $pass_update_stmt->execute([$secured_hash, $admin_id]);

                        $message = "🔒 Password token updated successfully across security arrays.";
                        $message_class = "msg-success";
                    } else {
                        $message = "Token Match Error: New password credentials do not match confirmed entry strings.";
                        $message_class = "msg-danger";
                    }
                } else {
                    $message = "Authentication Check Failed: Current password credentials invalid.";
                    $message_class = "msg-danger";
                }
            } catch (PDOException $e) {
                $message = "Security Module Failure: " . $e->getMessage();
                $message_class = "msg-danger";
            }
        } else {
            $message = "Validation Error: Password parameters cannot be compiled as blank nodes.";
            $message_class = "msg-danger";
        }
    }
}

// -------------------------------------------------------------------------
// READ ACTION: RE-FETCH CURRENT MASTER RECORD TO INGEST STATE REFRESHES
// -------------------------------------------------------------------------
try {
    $profile_stmt = $pdo->prepare("SELECT full_name, email, phone, created_at FROM users WHERE user_id = ?");
    $profile_stmt->execute([$admin_id]);
    $profile = $profile_stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "Error extracting account state fields: " . $e->getMessage();
    $message_class = "msg-danger";
}

// Ingest admin structure layout templates
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="adm-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        .page-title-block p { color: #64748b; font-size: 14px; margin-top: 2px; }

        .profile-split-layout {
            display: grid; grid-template-columns: 1fr; gap: 30px; max-width: 1100px;
        }
        @media (min-width: 992px) {
            .profile-split-layout { grid-template-columns: repeat(2, 1fr); }
        }

        .profile-card-canvas {
            background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0;
            padding: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.01);
        }
        .profile-section-heading {
            color: #0f172a; font-size: 16px; font-weight: 600; margin-bottom: 20px;
            padding-bottom: 8px; border-bottom: 1px solid #f1f5f9;
        }

        .form-group { display: flex; flex-direction: column; margin-bottom: 18px; }
        .form-group label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control {
            padding: 11px 13px; border: 1px solid #cbd5e1; border-radius: 6px;
            font-size: 14px; color: #334155; background-color: #ffffff;
        }
        .form-control:focus { outline: none; border-color: #10b981; }
        .form-control:disabled { background-color: #f8fafc; color: #94a3b8; border-color: #e2e8f0; }

        .action-btn {
            background-color: #0f172a; color: #ffffff; border: none; padding: 12px 24px;
            border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 13.5px;
            transition: background 0.2s;
        }
        .action-btn:hover { background-color: #1e293b; }
        .btn-green { background-color: #10b981; }
        .btn-green:hover { background-color: #059669; }

        /* Alert Status Feedback Banners styles */
        .alert-banner { padding: 12px 15px; border-radius: 6px; margin-bottom: 25px; font-size: 14px; font-weight: 500; max-width: 1100px; }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        
        .badge-admin { background-color: #fee2e2; color: #991b1b; font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 4px; text-transform: uppercase; width: max-content; margin-top: 5px;}
    </style>

    <div class="page-title-block">
        <h2>My Account Profile Settings</h2>
        <p>Manage security tokens, identity keys, contact nodes, and root system operational settings.</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="profile-split-layout">
        
        <div class="profile-card-canvas">
            <div class="profile-section-heading">🛡️ Identity Account Settings</div>
            
            <form action="profile.php" method="POST">
                <input type="hidden" name="action" value="update_profile">

                <div class="form-group">
                    <label>System Role Authorization Token</label>
                    <div class="badge-admin">Admin Node Level 1</div>
                </div>

                <div class="form-group">
                    <label for="full_name">Official Identity Name *</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" value="<?php echo htmlspecialchars($profile['full_name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Primary Communication Email Link *</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($profile['email']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="phone">System Contact Phone Vector *</label>
                    <input type="text" id="phone" name="phone" class="form-control" value="<?php echo htmlspecialchars($profile['phone']); ?>" required>
                </div>

                <div class="form-group">
                    <label>Account Node Registry Datetime</label>
                    <input type="text" class="form-control" value="<?php echo date('F d, Y \a\t g:i A', strtotime($profile['created_at'])); ?>" disabled>
                </div>

                <button type="submit" class="action-btn btn-green">💾 Save Profile Parameter Edits</button>
            </form>
        </div>

        <div class="profile-card-canvas">
            <div class="profile-section-heading">🔑 Security Credential Invalidation Engine</div>
            
            <form action="profile.php" method="POST">
                <input type="hidden" name="action" value="change_password">

                <div class="form-group">
                    <label for="current_password">Existing Account Access Key *</label>
                    <input type="password" id="current_password" name="current_password" class="form-control" placeholder="••••••••••••" required>
                </div>

                <div class="form-group">
                    <label for="new_password">Target High-Entropy New Password *</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" placeholder="••••••••••••" minlength="6" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Verify Target Password String *</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="••••••••••••" minlength="6" required>
                </div>

                <div style="margin-top: 10px; padding: 12px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 12.5px; color: #64748b; margin-bottom: 18px;">
                    💡 <strong>Security Metric:</strong> Altering security tokens forces invalidation vectors across external cache configurations. Choose passwords containing alpha-numeric symbols.
                </div>

                <button type="submit" class="action-btn">🔒 Re-Key Authentication String</button>
            </form>
        </div>

    </div>

</div>

<?php 
// Ingest secure bottom layout wrapper block closures framework safely
include('includes/footer.php'); 
?>