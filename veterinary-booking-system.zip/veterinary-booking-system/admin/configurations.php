<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as system root administrator
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// POST ACTION: PROCESS ENGINE SYSTEM KEY-VALUE CONFIGURATION SAVES
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_configs') {
    $clinic_name      = trim($_POST['clinic_name']);
    $clinic_email     = trim($_POST['clinic_email']);
    $clinic_phone     = trim($_POST['clinic_phone']);
    $clinic_address   = trim($_POST['clinic_address']);
    $max_slots_per_hr = (int)$_POST['max_slots_per_hour'];
    $system_status    = $_POST['system_operational_status'];

    if (!empty($clinic_name) && !empty($clinic_email)) {
        try {
            // Check if a configuration record already exists in the system variables block
            $check_stmt = $pdo->query("SELECT id FROM clinic_configs LIMIT 1");
            $config_row = $check_stmt->fetch();

            if ($config_row) {
                // Update existing parameters row setup
                $update_sql = "UPDATE clinic_configs 
                               SET clinic_name = ?, clinic_email = ?, clinic_phone = ?, clinic_address = ?, max_slots_per_hour = ?, system_operational_status = ? 
                               WHERE id = ?";
                $update_stmt = $pdo->prepare($update_sql);
                $update_stmt->execute([$clinic_name, $clinic_email, $clinic_phone, $clinic_address, $max_slots_per_hr, $system_status, $config_row['id']]);
            } else {
                // Initialize first configuration values profile parameters
                $insert_sql = "INSERT INTO clinic_configs (clinic_name, clinic_email, clinic_phone, clinic_address, max_slots_per_hour, system_operational_status) 
                               VALUES (?, ?, ?, ?, ?, ?)";
                $insert_stmt = $pdo->prepare($insert_sql);
                $insert_stmt->execute([$clinic_name, $clinic_email, $clinic_phone, $clinic_address, $max_slots_per_hr, $system_status]);
            }

            $message = "⚙️ System configurations updated successfully! Parameters initialized actively across execution modules.";
            $message_class = "msg-success";
        } catch (PDOException $e) {
            $message = "Configuration Engine Failure: " . $e->getMessage();
            $message_class = "msg-danger";
        }
    } else {
        $message = "Mandatory parameters missing. Clinic Name and System Email validations required.";
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// READ ACTION: INGEST CORE SYSTEM OPERATIONAL CONFIGURATIONS FOR VIEW LAYOUT
// -------------------------------------------------------------------------
try {
    $fetch_stmt = $pdo->query("SELECT * FROM clinic_configs LIMIT 1");
    $current_configs = $fetch_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Seed default baseline parameters if db row array data results return completely hollow arrays
    if (!$current_configs) {
        $current_configs = [
            'clinic_name' => 'Oakland Veterinary Clinic',
            'clinic_email' => 'info@oaklandvet.com',
            'clinic_phone' => '0722000111',
            'clinic_address' => 'Nairobi, Kenya',
            'max_slots_per_hour' => 4,
            'system_operational_status' => 'online'
        ];
    }
} catch (PDOException $e) {
    $message = "Error extracting clinic variables: " . $e->getMessage();
    $message_class = "msg-danger";
}

// Ingest admin structure layout templates
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="adm-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        .page-title-block p { color: #64748b; font-size: 14px; margin-top: 2px; }
        
        .config-card-canvas {
            background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0;
            padding: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.01); max-width: 900px;
        }
        
        .config-section-heading {
            color: #0f172a; font-size: 16px; font-weight: 600; margin-bottom: 20px;
            padding-bottom: 8px; border-bottom: 1px solid #f1f5f9;
        }

        /* Form Grid mechanics alignment structures */
        .config-form-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px; margin-bottom: 25px;
        }

        .form-group { display: flex; flex-direction: column; margin-bottom: 4px; }
        .form-group label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control {
            padding: 11px 13px; border: 1px solid #cbd5e1; border-radius: 6px;
            font-size: 14px; color: #334155; background-color: #ffffff;
        }
        .form-control:focus { outline: none; border-color: #10b981; }
        textarea.form-control { resize: vertical; min-height: 80px; }

        .action-button-row {
            display: flex; justify-content: flex-end; border-top: 1px solid #f1f5f9;
            padding-top: 20px; margin-top: 10px;
        }
        .save-configs-btn {
            background-color: #10b981; color: #ffffff; border: none; padding: 12px 30px;
            border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px;
            transition: background 0.2s;
        }
        .save-configs-btn:hover { background-color: #059669; }

        /* Alert Status Feedback Banners styles */
        .alert-banner { padding: 12px 15px; border-radius: 6px; margin-bottom: 25px; font-size: 14px; font-weight: 500; max-width: 900px; }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
    </style>

    <div class="page-title-block">
        <h2>Global Clinic Configurations</h2>
        <p>Manage infrastructure variables, baseline branding contexts, and systemic appointment scheduler limits.</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="config-card-canvas">
        <form action="configurations.php" method="POST">
            <input type="hidden" name="action" value="save_configs">

            <div class="config-section-heading">🏢 Enterprise Identity Variables</div>
            <div class="config-form-grid">
                <div class="form-group">
                    <label for="clinic_name">Official Clinic Entity Name *</label>
                    <input type="text" id="clinic_name" name="clinic_name" class="form-control" value="<?php echo htmlspecialchars($current_configs['clinic_name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="clinic_email">Public Support Email Channel *</label>
                    <input type="email" id="clinic_email" name="clinic_email" class="form-control" value="<?php echo htmlspecialchars($current_configs['clinic_email']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="clinic_phone">Official Hotline Phone Contact Key</label>
                    <input type="text" id="clinic_phone" name="clinic_phone" class="form-control" value="<?php echo htmlspecialchars($current_configs['clinic_phone']); ?>">
                </div>

                <div class="form-group">
                    <label for="clinic_address">Physical Location Address Node</label>
                    <textarea id="clinic_address" name="clinic_address" class="form-control"><?php echo htmlspecialchars($current_configs['clinic_address']); ?></textarea>
                </div>
            </div>

            <div class="config-section-heading">⛓️ Engine Parameters & Scheduler Thresholds</div>
            <div class="config-form-grid">
                <div class="form-group">
                    <label for="max_slots_per_hour">Appointment Traffic Cap (Slots Per Hour)</label>
                    <input type="number" id="max_slots_per_hour" name="max_slots_per_hour" class="form-control" min="1" max="20" value="<?php echo (int)$current_configs['max_slots_per_hour']; ?>">
                </div>

                <div class="form-group">
                    <label for="system_operational_status">Global Infrastructure Gateway State</label>
                    <select id="system_operational_status" name="system_operational_status" class="form-control">
                        <option value="online" <?php echo ($current_configs['system_operational_status'] === 'online') ? 'selected' : ''; ?>>Active / Online (Standard Operation)</option>
                        <option value="maintenance" <?php echo ($current_configs['system_operational_status'] === 'maintenance') ? 'selected' : ''; ?>>Maintenance Mode (Lock General Logins)</option>
                    </select>
                </div>
            </div>

            <div class="action-button-row">
                <button type="submit" class="save-configs-btn">💾 Commit Configuration Changes</button>
            </div>

        </form>
    </div>

</div>

<?php 
// Ingest secure bottom layout wrapper block closures framework safely
include('includes/footer.php'); 
?>