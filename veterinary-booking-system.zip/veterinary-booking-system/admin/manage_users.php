<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as system root administrator
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// POST ACTION 1: CREATE SYSTEM USER ACCOUNT (PROVISIONING ENGINE)
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_user') {
    $full_name = trim($_POST['full_name']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $role      = $_POST['role'];
    $password  = $_POST['password'];

    if (!empty($full_name) && !empty($email) && !empty($role) && !empty($password)) {
        try {
            // Enforce system constraint: Verify email uniqueness
            $check_stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
            $check_stmt->execute([$email]);
            
            if ($check_stmt->rowCount() > 0) {
                $message = "❌ Error: A user account with that email address already exists.";
                $message_class = "msg-danger";
            } else {
                // Securely encrypt login credential string strings using strong cryptographic BCRYPT algorithms
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                
                $insert_sql = "INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)";
                $insert_stmt = $pdo->prepare($insert_sql);
                $insert_stmt->execute([$full_name, $email, $phone, $hashed_password, $role]);
                
                $message = "🛡️ New user provisioning successful! Identity mapped to the standard system architecture.";
                $message_class = "msg-success";
            }
        } catch (PDOException $e) {
            $message = "Provisioning Engine Error: " . $e->getMessage();
            $message_class = "msg-danger";
        }
    } else {
        $message = "Please complete all mandatory parameters to generate a safe user credential block.";
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// POST ACTION 2: PURGE SYSTEM USER IDENTITY (DELETE RECORD HOOK)
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    $target_user_id = (int)$_POST['user_id'];

    // Prevent administrative suicide: Prevent active admin session self-deletion
    if ($target_user_id === (int)$_SESSION['user_id']) {
        $message = "❌ Security Restriction: You cannot delete your own active administrator profile context.";
        $message_class = "msg-danger";
    } else {
        try {
            $delete_stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
            $delete_stmt->execute([$target_user_id]);
            
            $message = "🗑️ User account successfully purged from system databases.";
            $message_class = "msg-success";
        } catch (PDOException $e) {
            // Catches constraint errors if user has associated foreign keys (e.g. appointments)
            $message = "Purge Failed: This user profile possesses linked medical records. Clear them before attempting removal. Details: " . $e->getMessage();
            $message_class = "msg-danger";
        }
    }
}

// -------------------------------------------------------------------------
// READ ACTION: FETCH ALL IDENTITY PROFILES AND SORT BY ACCESS NODES
// -------------------------------------------------------------------------
$filter_role  = isset($_GET['filter_role']) ? $_GET['filter_role'] : '';
$search_input = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    $query_str = "SELECT user_id, full_name, email, phone, role, created_at FROM users WHERE 1=1";
    $params = [];

    if (!empty($filter_role)) {
        $query_str .= " AND role = ?";
        $params[] = $filter_role;
    }

    if (!empty($search_input)) {
        $query_str .= " AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)";
        $search_wildcard = '%' . $search_input . '%';
        $params[] = $search_wildcard;
        $params[] = $search_wildcard;
        $params[] = $search_wildcard;
    }

    $query_str .= " ORDER BY role ASC, full_name ASC";
    
    $stmt = $pdo->prepare($query_str);
    $stmt->execute($params);
    $system_users = $stmt->fetchAll();
} catch (PDOException $e) {
    $system_users = [];
    $message = "Error generating user listings: " . $e->getMessage();
    $message_class = "msg-danger";
}

// Ingest admin structure layouts
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="adm-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        
        .management-split-layout { display: flex; flex-direction: column; gap: 30px; }
        @media (min-width: 1200px) {
            .management-split-layout { flex-direction: row; align-items: flex-start; }
            .form-sidebar-container { width: 380px; flex-shrink: 0; }
            .table-main-container { flex-get: 1; width: 100%; }
        }

        /* Workspace Card UI Frames Layout */
        .workspace-admin-card {
            background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0;
            padding: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.01);
        }
        .card-heading {
            color: #0f172a; font-size: 17px; font-weight: 600;
            border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 20px;
        }

        .form-group { display: flex; flex-direction: column; margin-bottom: 16px; }
        .form-group label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control {
            padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px;
            font-size: 14px; color: #334155; background-color: #ffffff;
        }
        .form-control:focus { outline: none; border-color: #10b981; }

        .submit-action-btn {
            background-color: #10b981; color: #ffffff; border: none; padding: 12px;
            border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px;
            width: 100%; transition: background 0.2s; margin-top: 5px;
        }
        .submit-action-btn:hover { background-color: #059669; }

        /* Filtration Framework Controls Styles */
        .filter-controls-row { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
        .filter-controls-row .form-control { flex: 1; min-width: 200px; }
        .filter-action-btn {
            background-color: #0f172a; color: #ffffff; border: none; padding: 0 18px;
            border-radius: 6px; font-weight: 600; font-size: 13.5px; cursor: pointer; height: 40px;
            display: flex; align-items: center; text-decoration: none;
        }
        .filter-action-btn:hover { background-color: #1e293b; }
        .clear-btn { background-color: #64748b; }
        .clear-btn:hover { background-color: #475569; }

        /* Master Directory Users Grid Table Style Sheet formatting rules */
        .identity-table { width: 100%; border-collapse: collapse; font-size: 13.5px; text-align: left; }
        .identity-table th {
            background-color: #f8fafc; color: #64748b; padding: 12px 14px;
            font-weight: 600; font-size: 11.5px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;
        }
        .identity-table td { padding: 12px 14px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: middle; }
        .identity-table tr:hover { background-color: #f8fafc; }

        /* Access Node Roles Mapping System Badge styles */
        .role-badge {
            display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase;
        }
        .role-badge.admin { background-color: #fee2e2; color: #991b1b; }
        .role-badge.vet { background-color: #e0e7ff; color: #3730a3; }
        .role-badge.receptionist { background-color: #fef3c7; color: #92400e; }
        .role-badge.pet_owner { background-color: #f1f5f9; color: #334155; }

        .delete-record-btn {
            background-color: #fff1f2; color: #e11d48; border: 1px solid #ffe4e6; padding: 6px 12px;
            border-radius: 4px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;
        }
        .delete-record-btn:hover { background-color: #ffe4e6; color: #be123c; }

        /* Alert Status Feedback Banners styles */
        .alert-banner { padding: 12px 15px; border-radius: 6px; margin-bottom: 25px; font-size: 14px; font-weight: 500; }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        .meta-subtext { font-size: 12px; color: #64748b; margin-top: 1px; }
    </style>

    <div class="page-title-block">
        <h2>System Identity & User Management Control Node</h2>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="management-split-layout">
        
        <div class="form-sidebar-container">
            <div class="workspace-admin-card">
                <h3 class="card-heading">➕ Provision New Identity</h3>
                <form action="manage_users.php" method="POST" autocomplete="off">
                    <input type="hidden" name="action" value="create_user">
                    
                    <div class="form-group">
                        <label for="full_name">Full Account Name *</label>
                        <input type="text" id="full_name" name="full_name" class="form-control" placeholder="e.g., Jane Karimi" required>
                    </div>

                    <div class="form-group">
                        <label for="email">System Email Address *</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="jane@oaklandvet.com" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Contact *</label>
                        <input type="text" id="phone" name="phone" class="form-control" placeholder="e.g., 0722000111">
                    </div>

                    <div class="form-group">
                        <label for="role">Platform Security Role Access Node *</label>
                        <select id="role" name="role" class="form-control" required>
                            <option value="">-- Choose Access Group --</option>
                            <option value="admin">System Administrator</option>
                            <option value="vet">Veterinary Medical Officer</option>
                            <option value="receptionist">Front Desk Personnel</option>
                            <option value="pet_owner">Standard Client (Owner)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="password">Initial Setup Password *</label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" minlength="6" required>
                    </div>

                    <button type="submit" class="submit-action-btn">🛡️ Execute System Provisioning</button>
                </form>
            </div>
        </div>

        <div class="table-main-container">
            <div class="workspace-admin-card">
                <h3 class="card-heading">🗂️ Central System Accounts Matrix Directory</h3>
                
                <form action="manage_users.php" method="GET">
                    <div class="filter-controls-row">
                        <input type="text" name="search" class="form-control" placeholder="Search parameters by name, email database values, or phones..." value="<?php echo htmlspecialchars($search_input); ?>">
                        
                        <select name="filter_role" class="form-control" style="max-width: 180px;">
                            <option value="">-- View All Roles --</option>
                            <option value="admin" <?php echo ($filter_role === 'admin') ? 'selected' : ''; ?>>Admin</option>
                            <option value="vet" <?php echo ($filter_role === 'vet') ? 'selected' : ''; ?>>Vet Doctor</option>
                            <option value="receptionist" <?php echo ($filter_role === 'receptionist') ? 'selected' : ''; ?>>Receptionist</option>
                            <option value="pet_owner" <?php echo ($filter_role === 'pet_owner') ? 'selected' : ''; ?>>Client (Owner)</option>
                        </select>

                        <button type="submit" class="filter-action-btn">🔍 Sort Directory</button>
                        <a href="manage_users.php" class="filter-action-btn clear-btn">🧹 Clear</a>
                    </div>
                </form>

                <?php if (count($system_users) > 0): ?>
                    <table class="identity-table">
                        <thead>
                            <tr>
                                <th>Account Key ID</th>
                                <th>User Full Profile Information</th>
                                <th>Contact Parameters</th>
                                <th>Access Node</th>
                                <th style="text-align: center;">Destructive Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($system_users as $user): ?>
                                <tr>
                                    <td><strong>#<?php echo $user['user_id']; ?></strong></td>
                                    
                                    <td>
                                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                        <div class="meta-subtext">Onboarding: <?php echo date('M d, Y', strtotime($user['created_at'])); ?></div>
                                    </td>

                                    <td>
                                        <div>📧 <?php echo htmlspecialchars($user['email']); ?></div>
                                        <div class="meta-subtext">📞 <?php echo htmlspecialchars($user['phone'] ?: 'N/A'); ?></div>
                                    </td>

                                    <td>
                                        <span class="role-badge <?php echo htmlspecialchars($user['role']); ?>">
                                            <?php echo htmlspecialchars($user['role'] === 'pet_owner' ? 'Client' : $user['role']); ?>
                                        </span>
                                    </td>

                                    <td style="text-align: center;">
                                        <?php if ($user['user_id'] !== (int)$_SESSION['user_id']): ?>
                                            <form action="manage_users.php" method="POST" onsubmit="return confirm('Security Warning: Are you entirely certain you wish to completely purge this user identity from the framework logs?');">
                                                <input type="hidden" name="action" value="delete_user">
                                                <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                <button type="submit" class="delete-record-btn">🗑️ Purge User</button>
                                            </form>
                                        <?php else: ?>
                                            <span style="font-size: 11px; color: #94a3b8; font-weight: 600; text-transform: uppercase;">🔒 Active Session</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div style="text-align: center; padding: 50px 20px; color: #94a3b8; font-style: italic;">
                        No account credentials or profile matrices match your target exploration sorting filters.
                    </div>
                <?php endif; ?>

            </div>
        </div>

    </div>
</div>

<?php 
// Ingest layout closures safely
include('includes/footer.php'); 
?>