<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as system root administrator
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// POST ACTION: PROCESS CASE ASSIGNMENT / REASSIGNMENT
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // Action A: Create a brand new case assignment (Insert into appointments)
    if ($_POST['action'] === 'new_assignment') {
        $pet_id           = (int)$_POST['pet_id'];
        $vet_id           = (int)$_POST['vet_id'];
        $assignment_date  = $_POST['appointment_date'];
        $assignment_time  = $_POST['appointment_time'];
        $reason           = trim($_POST['reason_for_visit']); // Maps directly to `reason` text length field

        if ($pet_id > 0 && $vet_id > 0 && !empty($assignment_date)) {
            try {
                $insert_sql = "INSERT INTO appointments (pet_id, vet_id, appointment_date, appointment_time, reason, status) 
                               VALUES (?, ?, ?, ?, ?, 'confirmed')";
                $stmt = $pdo->prepare($insert_sql);
                $stmt->execute([$pet_id, $vet_id, $assignment_date, $assignment_time, $reason]);

                $message = "🎯 Case successfully assigned! The selected veterinarian has been allocated to the client's pet.";
                $message_class = "msg-success";
            } catch (PDOException $e) {
                $message = "Assignment Routing Failure: " . $e->getMessage();
                $message_class = "msg-danger";
            }
        } else {
            $message = "Please complete all mandatory parameters to route the assignment.";
            $message_class = "msg-danger";
        }
    }
    
    // Action B: Reassign an existing appointment to a different Vet
    if ($_POST['action'] === 'reassign_vet') {
        $appointment_id = (int)$_POST['appointment_id'];
        $new_vet_id     = (int)$_POST['new_vet_id'];

        if ($appointment_id > 0 && $new_vet_id > 0) {
            try {
                $update_sql = "UPDATE appointments SET vet_id = ? WHERE appointment_id = ?";
                $stmt = $pdo->prepare($update_sql);
                $stmt->execute([$new_vet_id, $appointment_id]);

                $message = "🔄 Case successfully reassigned to the new medical officer.";
                $message_class = "msg-success";
            } catch (PDOException $e) {
                $message = "Reassignment Update Failure: " . $e->getMessage();
                $message_class = "msg-danger";
            }
        }
    }
}

// -------------------------------------------------------------------------
// READ ACTION: INGEST POOLS FOR DROPDOWNS & ACTIVE MATRIX DIRECTORY
// -------------------------------------------------------------------------
try {
    // 1. Fetch all available Veterinary Doctors from users table
    $vets = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'vet' ORDER BY full_name ASC")->fetchAll();

    // 2. Fetch all Patients (Pets) along with their Owner's full name from users table mapping
    $patients_sql = "SELECT p.pet_id, p.pet_name, p.species, u.full_name AS owner_name 
                     FROM pets p 
                     INNER JOIN users u ON p.owner_id = u.user_id 
                     ORDER BY u.full_name ASC, p.pet_name ASC";
    $patients = $pdo->query($patients_sql)->fetchAll();

    // 3. Fetch current active case allocations (pending or confirmed)
    $queue_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status, a.reason,
                         p.pet_name, p.species, u_client.full_name AS owner_name, u_vet.full_name AS vet_name
                  FROM appointments a
                  INNER JOIN pets p ON a.pet_id = p.pet_id
                  INNER JOIN users u_client ON p.owner_id = u_client.user_id
                  INNER JOIN users u_vet ON a.vet_id = u_vet.user_id
                  WHERE a.status IN ('pending', 'confirmed')
                  ORDER BY a.appointment_date ASC, a.appointment_time ASC";
    $active_assignments = $pdo->query($queue_sql)->fetchAll();

} catch (PDOException $e) {
    $message = "Data Sync Interruption: " . $e->getMessage();
    $message_class = "msg-danger";
}

include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="adm-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        
        .assignment-split-layout { display: flex; flex-direction: column; gap: 30px; }
        @media (min-width: 1200px) {
            .assignment-split-layout { flex-direction: row; align-items: flex-start; }
            .form-sidebar { width: 380px; flex-shrink: 0; }
            .queue-main { flex-grow: 1; width: 100%; }
        }

        .workspace-card {
            background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0;
            padding: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.01);
        }
        .card-heading {
            color: #0f172a; font-size: 16px; font-weight: 600;
            border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 20px;
        }

        .form-group { display: flex; flex-direction: column; margin-bottom: 16px; }
        .form-group label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control {
            padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px;
            font-size: 14px; color: #334155; background-color: #ffffff;
        }
        .form-control:focus { outline: none; border-color: #10b981; }

        .submit-btn {
            background-color: #10b981; color: #ffffff; border: none; padding: 12px;
            border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px; width: 100%;
        }
        .submit-btn:hover { background-color: #059669; }

        .queue-table { width: 100%; border-collapse: collapse; font-size: 13.5px; text-align: left; }
        .queue-table th {
            background-color: #f8fafc; color: #64748b; padding: 12px;
            font-weight: 600; font-size: 11.5px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;
        }
        .queue-table td { padding: 12px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        .queue-table tr:hover { background-color: #f8fafc; }

        .reassign-form { display: flex; gap: 6px; align-items: center; }
        .reassign-select { padding: 6px 10px; font-size: 12.5px; border-radius: 4px; border: 1px solid #cbd5e1; color: #334155; background: #fff; }
        .inline-action-btn {
            background-color: #0f172a; color: #ffffff; border: none; padding: 7px 12px;
            border-radius: 4px; font-size: 12px; font-weight: 600; cursor: pointer;
        }
        .inline-action-btn:hover { background-color: #1e293b; }

        .alert-banner { padding: 12px 15px; border-radius: 6px; margin-bottom: 25px; font-size: 14px; font-weight: 500; }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        .sub-text { font-size: 12px; color: #64748b; }
    </style>

    <div class="page-title-block">
        <h2>Veterinary Case Assignment Console</h2>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="assignment-split-layout">
        
        <div class="form-sidebar">
            <div class="workspace-card">
                <h3 class="card-heading">🎯 Allocate New Assignment</h3>
                <form action="assign_vet.php" method="POST">
                    <input type="hidden" name="action" value="new_assignment">

                    <div class="form-group">
                        <label for="pet_id">Select Client & Patient *</label>
                        <select id="pet_id" name="pet_id" class="form-control" required>
                            <option value="">-- Select Client (Pet) --</option>
                            <?php foreach ($patients as $pat): ?>
                                <option value="<?php echo $pat['pet_id']; ?>">
                                    <?php echo htmlspecialchars($pat['owner_name'] . " — [" . ucfirst($pat['pet_name']) . " (" . $pat['species'] . ")]"); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="vet_id">Assign Veterinary Officer *</label>
                        <select id="vet_id" name="vet_id" class="form-control" required>
                            <option value="">-- Select Medical Officer --</option>
                            <?php foreach ($vets as $v): ?>
                                <option value="<?php echo $v['user_id']; ?>">Dr. <?php echo htmlspecialchars($v['full_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="appointment_date">Allocation Target Date *</label>
                        <input type="date" id="appointment_date" name="appointment_date" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="appointment_time">Allocation Target Time *</label>
                        <input type="time" id="appointment_time" name="appointment_time" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="reason_for_visit">Clinical Notes / Reason *</label>
                        <input type="text" id="reason_for_visit" name="reason_for_visit" class="form-control" placeholder="e.g., General Checkup, Vaccination" maxlength="255" required>
                    </div>

                    <button type="submit" class="submit-btn">⚡ Execute Case Assignment</button>
                </form>
            </div>
        </div>

        <div class="queue-main">
            <div class="workspace-card">
                <h3 class="card-heading">📋 Current Active Clinical Allocations</h3>
                
                <?php if (count($active_assignments) > 0): ?>
                    <table class="queue-table">
                        <thead>
                            <tr>
                                <th>Schedule Reference</th>
                                <th>Client / Patient</th>
                                <th>Currently Assigned Vet</th>
                                <th style="min-width: 240px;">Quick Reassign Route</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($active_assignments as $case): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo date('M d, Y', strtotime($case['appointment_date'])); ?></strong>
                                        <div class="sub-text">⏱️ <?php echo date('h:i A', strtotime($case['appointment_time'])); ?></div>
                                    </td>
                                    <td>
                                        <strong>🐾 <?php echo htmlspecialchars(ucfirst($case['pet_name'])); ?></strong> (<?php echo htmlspecialchars($case['species']); ?>)
                                        <div class="sub-text">Owner: <?php echo htmlspecialchars($case['owner_name']); ?></div>
                                    </td>
                                    <td>
                                        <span style="color: #3730a3; font-weight: 600;">Dr. <?php echo htmlspecialchars($case['vet_name']); ?></span>
                                        <div class="sub-text" style="font-style: italic;">"<?php echo htmlspecialchars($case['reason']); ?>"</div>
                                    </td>
                                    <td>
                                        <form action="assign_vet.php" method="POST" class="reassign-form">
                                            <input type="hidden" name="action" value="reassign_vet">
                                            <input type="hidden" name="appointment_id" value="<?php echo $case['appointment_id']; ?>">
                                            
                                            <select name="new_vet_id" class="reassign-select" required>
                                                <option value="">-- Choose New Vet --</option>
                                                <?php foreach ($vets as $v): ?>
                                                    <option value="<?php echo $v['user_id']; ?>">Dr. <?php echo htmlspecialchars($v['full_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" class="inline-action-btn">Route</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: #94a3b8; font-style: italic;">
                        No pending cases currently await clinical officer routing.
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<?php 
include('includes/footer.php'); 
?>