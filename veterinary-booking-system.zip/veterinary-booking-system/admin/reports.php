<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as system root administrator
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

require_once('../config/db.php');

$error_msg = "";
$report_period = isset($_GET['period']) ? $_GET['period'] : 'daily';
$report_date = isset($_GET['report_date']) ? $_GET['report_date'] : date('Y-m-d');
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Filter variables
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : '';
$filter_species = isset($_GET['filter_species']) ? $_GET['filter_species'] : '';
$filter_vet = isset($_GET['filter_vet']) ? $_GET['filter_vet'] : '';
$filter_owner = isset($_GET['filter_owner']) ? $_GET['filter_owner'] : '';
$search_term = isset($_GET['search_term']) ? trim($_GET['search_term']) : '';
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'appointment_date';
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

// -------------------------------------------------------------------------
// HELPER FUNCTIONS FOR PRINT REPORT
// -------------------------------------------------------------------------
function getPeriodLabel($period, $report_date, $start_date, $end_date) {
    switch($period) {
        case 'daily':
            return date('F d, Y', strtotime($report_date));
        case 'monthly':
            return date('F Y', strtotime($report_date));
        case 'yearly':
            return date('Y', strtotime($report_date));
        case 'custom':
            return date('F d, Y', strtotime($start_date)) . ' to ' . date('F d, Y', strtotime($end_date));
        default:
            return 'N/A';
    }
}

function getFiltersSummary($filter_status, $filter_species, $filter_vet, $filter_owner, $search_term, $vet_list, $owner_list) {
    $filters = [];
    
    if (!empty($filter_status)) {
        $status_labels = ['pending' => 'Pending', 'confirmed' => 'Confirmed', 'completed' => 'Completed', 'cancelled' => 'Cancelled'];
        $filters[] = 'Status: ' . ($status_labels[$filter_status] ?? $filter_status);
    }
    
    if (!empty($filter_species)) {
        $filters[] = 'Species: ' . $filter_species;
    }
    
    if (!empty($filter_vet)) {
        $vet_name = '';
        foreach ($vet_list as $vet) {
            if ($vet['user_id'] == $filter_vet) {
                $vet_name = $vet['full_name'];
                break;
            }
        }
        $filters[] = 'Vet: ' . $vet_name;
    }
    
    if (!empty($filter_owner)) {
        $owner_name = '';
        foreach ($owner_list as $owner) {
            if ($owner['user_id'] == $filter_owner) {
                $owner_name = $owner['full_name'];
                break;
            }
        }
        $filters[] = 'Owner: ' . $owner_name;
    }
    
    if (!empty($search_term)) {
        $filters[] = 'Search: "' . $search_term . '"';
    }
    
    return empty($filters) ? 'None' : implode(' | ', $filters);
}

// -------------------------------------------------------------------------
// CENTRALIZED FILTER LOGIC
// -------------------------------------------------------------------------
$where_conditions = [];
$params = [];

// Apply Date Filter
if ($report_period === 'daily') {
    $where_conditions[] = "DATE(a.appointment_date) = ?";
    $params[] = $report_date;
} elseif ($report_period === 'monthly') {
    $where_conditions[] = "DATE_FORMAT(a.appointment_date, '%Y-%m') = ?";
    $params[] = date('Y-m', strtotime($report_date));
} elseif ($report_period === 'yearly') {
    $where_conditions[] = "YEAR(a.appointment_date) = ?";
    $params[] = date('Y', strtotime($report_date));
} elseif ($report_period === 'custom') {
    $where_conditions[] = "DATE(a.appointment_date) BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
}

// Apply other filters
if (!empty($filter_status)) { 
    $where_conditions[] = "a.status = ?"; 
    $params[] = $filter_status; 
}
if (!empty($filter_species)) { 
    $where_conditions[] = "p.species = ?"; 
    $params[] = $filter_species; 
}
if (!empty($filter_vet)) { 
    $where_conditions[] = "a.vet_id = ?"; 
    $params[] = $filter_vet; 
}
if (!empty($filter_owner)) { 
    $where_conditions[] = "o.user_id = ?"; 
    $params[] = $filter_owner; 
}
if (!empty($search_term)) {
    $where_conditions[] = "(p.pet_name LIKE ? OR o.full_name LIKE ? OR u.full_name LIKE ? OR a.reason LIKE ?)";
    $search_param = "%$search_term%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// -------------------------------------------------------------------------
// COMPILATION METRICS: Data Fetching
// -------------------------------------------------------------------------

// 1. Appointment Details with sorting
try {
    $sql = "SELECT a.*, 
            u.full_name as vet_name, 
            p.pet_name, 
            p.species,
            p.breed,
            p.age,
            o.full_name as owner_name,
            o.email as owner_email,
            o.phone as owner_phone,
            (SELECT COUNT(*) FROM treatment_records tr WHERE tr.appointment_id = a.appointment_id) as treatment_count
            FROM appointments a
            LEFT JOIN users u ON a.vet_id = u.user_id
            LEFT JOIN pets p ON a.pet_id = p.pet_id
            LEFT JOIN users o ON p.owner_id = o.user_id
            $where_clause
            ORDER BY a.$sort_by $sort_order";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $appointment_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $appointment_details = []; 
    $error_msg = "Error loading appointments: " . $e->getMessage();
}

// 2. Summary Statistics
try {
    $stats_sql = "SELECT 
                    COUNT(*) as total_appointments,
                    SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed_appointments,
                    SUM(CASE WHEN a.status = 'pending' THEN 1 ELSE 0 END) as pending_appointments,
                    SUM(CASE WHEN a.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_appointments,
                    SUM(CASE WHEN a.status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_appointments
                  FROM appointments a
                  LEFT JOIN pets p ON a.pet_id = p.pet_id
                  $where_clause";
    $stats_stmt = $pdo->prepare($stats_sql);
    $stats_stmt->execute($params);
    $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $stats = [
        'total_appointments' => 0,
        'completed_appointments' => 0,
        'pending_appointments' => 0,
        'cancelled_appointments' => 0,
        'confirmed_appointments' => 0
    ];
}

// 3. Vet Performance
try {
    $vet_sql = "SELECT u.user_id,
                    u.full_name,
                    COUNT(DISTINCT a.appointment_id) as total_appointments,
                    SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed_appointments,
                    SUM(CASE WHEN a.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_appointments,
                    COUNT(DISTINCT p.pet_id) as unique_pets_treated,
                    COUNT(DISTINCT tr.record_id) as treatment_records
                FROM users u 
                LEFT JOIN appointments a ON u.user_id = a.vet_id 
                LEFT JOIN pets p ON a.pet_id = p.pet_id
                LEFT JOIN treatment_records tr ON a.appointment_id = tr.appointment_id
                $where_clause AND u.role = 'vet'
                GROUP BY u.user_id
                ORDER BY total_appointments DESC";
    $v_stmt = $pdo->prepare($vet_sql);
    $v_stmt->execute($params);
    $vet_performance = $v_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $vet_performance = []; 
}

// 4. Species Distribution
try {
    $species_sql = "SELECT p.species,
                        COUNT(DISTINCT a.appointment_id) as appointment_count,
                        COUNT(DISTINCT p.pet_id) as pet_count,
                        COUNT(DISTINCT p.owner_id) as owner_count
                    FROM pets p
                    LEFT JOIN appointments a ON p.pet_id = a.pet_id
                    " . (!empty($where_conditions) ? "WHERE " . implode(" AND ", array_map(function($cond) {
                        return str_replace('a.', 'a.', $cond);
                    }, $where_conditions)) : "") . "
                    GROUP BY p.species
                    ORDER BY appointment_count DESC";
    $species_stmt = $pdo->prepare($species_sql);
    $species_stmt->execute($params);
    $species_distribution = $species_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $species_distribution = []; 
}

// 5. Monthly Trends
try {
    $trend_sql = "SELECT 
                    DATE_FORMAT(a.appointment_date, '%Y-%m') as month,
                    COUNT(*) as total_appointments,
                    SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed
                  FROM appointments a
                  LEFT JOIN pets p ON a.pet_id = p.pet_id
                  $where_clause
                  GROUP BY DATE_FORMAT(a.appointment_date, '%Y-%m')
                  ORDER BY month DESC
                  LIMIT 12";
    $trend_stmt = $pdo->prepare($trend_sql);
    $trend_stmt->execute($params);
    $monthly_trends = $trend_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $monthly_trends = []; 
}

// 6. Owner Statistics
try {
    $owner_sql = "SELECT o.user_id,
                     o.full_name,
                     COUNT(DISTINCT p.pet_id) as pet_count,
                     COUNT(DISTINCT a.appointment_id) as appointment_count,
                     SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed_appointments
                  FROM users o
                  LEFT JOIN pets p ON o.user_id = p.owner_id
                  LEFT JOIN appointments a ON p.pet_id = a.pet_id
                  WHERE o.role = 'pet_owner'
                  " . (!empty($where_conditions) ? "AND " . implode(" AND ", array_map(function($cond) {
                      return str_replace('a.', 'a.', $cond);
                  }, $where_conditions)) : "") . "
                  GROUP BY o.user_id
                  ORDER BY appointment_count DESC
                  LIMIT 10";
    $owner_stmt = $pdo->prepare($owner_sql);
    $owner_stmt->execute($params);
    $owner_stats = $owner_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $owner_stats = []; 
}

// 7. Treatment Records Summary
try {
    $treatment_sql = "SELECT COUNT(*) as total_treatments,
                         COUNT(DISTINCT tr.vet_id) as treating_vets,
                         COUNT(DISTINCT tr.appointment_id) as treated_appointments
                      FROM treatment_records tr
                      JOIN appointments a ON tr.appointment_id = a.appointment_id
                      LEFT JOIN pets p ON a.pet_id = p.pet_id
                      $where_clause";
    $treatment_stmt = $pdo->prepare($treatment_sql);
    $treatment_stmt->execute($params);
    $treatment_stats = $treatment_stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $treatment_stats = [
        'total_treatments' => 0,
        'treating_vets' => 0,
        'treated_appointments' => 0
    ];
}

// Get filter options
try {
    $species_list = $pdo->query("SELECT DISTINCT species FROM pets WHERE species IS NOT NULL ORDER BY species")->fetchAll(PDO::FETCH_COLUMN);
    $vet_list = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'vet' ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);
    $owner_list = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'pet_owner' ORDER BY full_name LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $species_list = [];
    $vet_list = [];
    $owner_list = [];
}

// Prepare report metadata for print
$report_metadata = [
    'report_title' => 'Veterinary Clinic Operations Report',
    'generated_at' => date('F d, Y h:i:s A'),
    'generated_by' => $_SESSION['full_name'] ?? 'Administrator',
    'period' => getPeriodLabel($report_period, $report_date, $start_date, $end_date),
    'period_type' => ucfirst($report_period),
    'filters_applied' => getFiltersSummary($filter_status, $filter_species, $filter_vet, $filter_owner, $search_term, $vet_list, $owner_list),
    'total_records' => count($appointment_details)
];

// -------------------------------------------------------------------------
// UI OUTPUT
// -------------------------------------------------------------------------
include('includes/header.php');
include('includes/sidebar.php');
?>

<style>
@media print {
    .no-print { display: none !important; }
    .report-matrix-card { break-inside: avoid; page-break-inside: avoid; }
    .adm-main-content-canvas { padding: 0 !important; margin: 0 !important; }
    .print-header { display: block !important; }
    .print-footer { display: block !important; }
    .report-matrix-table { font-size: 10px !important; }
    .report-matrix-table td, .report-matrix-table th { padding: 4px 6px !important; }
    .stats-grid .stat-card { background: #f8f9fa !important; }
    .stat-value { font-size: 20px !important; }
}

.print-header { 
    display: none; 
    padding: 20px 0;
    border-bottom: 2px solid #333;
    margin-bottom: 20px;
}

.print-header h1 {
    font-size: 24px;
    margin: 0 0 5px 0;
    color: #2c3e50;
}

.print-header .report-meta {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 5px 20px;
    margin-top: 10px;
    font-size: 12px;
    color: #555;
}

.print-header .report-meta .meta-label {
    font-weight: 600;
    color: #333;
}

.print-footer {
    display: none;
    margin-top: 30px;
    padding-top: 15px;
    border-top: 1px solid #ddd;
    text-align: center;
    font-size: 11px;
    color: #777;
}

.report-controls {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.filter-row {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    align-items: center;
}

.filter-group {
    flex: 1;
    min-width: 150px;
}

.filter-group label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    color: #666;
    margin-bottom: 5px;
}

.filter-group select,
.filter-group input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    margin-bottom: 30px;
}

.stat-card {
    background: #fff;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    text-align: center;
}

.stat-value {
    font-size: 26px;
    font-weight: bold;
    color: #2c3e50;
}

.stat-label {
    color: #7f8c8d;
    font-size: 13px;
    margin-top: 5px;
}

.report-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
}

.report-matrix-card {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow-x: auto;
}

.report-matrix-card.full-width {
    grid-column: 1 / -1;
}

.card-heading {
    color: #2c3e50;
    margin-top: 0;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 2px solid #ecf0f1;
    font-size: 16px;
}

.report-matrix-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.report-matrix-table th {
    background: #f8f9fa;
    padding: 8px 10px;
    text-align: left;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
    font-size: 12px;
}

.report-matrix-table td {
    padding: 8px 10px;
    border-bottom: 1px solid #ecf0f1;
    font-size: 12px;
}

.report-matrix-table tr:hover {
    background: #f8f9fa;
}

.status-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    display: inline-block;
}

.status-pending { background: #fff3cd; color: #856404; }
.status-confirmed { background: #cce5ff; color: #004085; }
.status-completed { background: #d4edda; color: #155724; }
.status-cancelled { background: #f8d7da; color: #721c24; }

.btn-print {
    background: #3498db;
    color: white;
    border: none;
    padding: 10px 24px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.3s;
}

.btn-print:hover {
    background: #2980b9;
}

.btn-filter {
    background: #2ecc71;
    color: white;
    border: none;
    padding: 8px 18px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
}

.btn-filter:hover {
    background: #27ae60;
}

.btn-reset {
    background: #e74c3c;
    color: white;
    border: none;
    padding: 8px 18px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    margin-left: 5px;
}

.btn-reset:hover {
    background: #c0392b;
}

.print-report-summary {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 6px;
    margin-bottom: 20px;
    border-left: 4px solid #3498db;
}

.print-report-summary .summary-row {
    display: flex;
    flex-wrap: wrap;
    gap: 5px 20px;
    margin: 2px 0;
}

.print-report-summary .summary-label {
    font-weight: 600;
    color: #495057;
    min-width: 140px;
}

.page-title-block {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.page-title-block h2 {
    margin: 0;
    color: #2c3e50;
}
</style>

<div class="adm-main-content-canvas">
    <div class="page-title-block">
        <h2>Enterprise System & Operations Reports</h2>
        <div class="no-print">
            <button onclick="window.print()" class="btn-print">🖨️ Print Report</button>
        </div>
    </div>

    <!-- PRINT HEADER -->
    <div class="print-header">
        <h1><?php echo $report_metadata['report_title']; ?></h1>
        <div class="report-meta">
            <div><span class="meta-label">Report Period:</span> <?php echo $report_metadata['period']; ?></div>
            <div><span class="meta-label">Period Type:</span> <?php echo $report_metadata['period_type']; ?></div>
            <div><span class="meta-label">Generated:</span> <?php echo $report_metadata['generated_at']; ?></div>
            <div><span class="meta-label">Generated By:</span> <?php echo $report_metadata['generated_by']; ?></div>
            <div><span class="meta-label">Total Records:</span> <?php echo $report_metadata['total_records']; ?></div>
            <div><span class="meta-label">Filters Applied:</span> <?php echo $report_metadata['filters_applied']; ?></div>
        </div>
    </div>

    <!-- Report Summary (visible on screen and print) -->
    <div class="print-report-summary">
        <div class="summary-row">
            <span class="summary-label">📋 Report Period:</span>
            <span><?php echo $report_metadata['period']; ?></span>
        </div>
        <div class="summary-row">
            <span class="summary-label">📊 Total Records:</span>
            <span><?php echo $report_metadata['total_records']; ?> appointments</span>
        </div>
        <div class="summary-row">
            <span class="summary-label">🔍 Filters Applied:</span>
            <span><?php echo $report_metadata['filters_applied']; ?></span>
        </div>
        <div class="summary-row">
            <span class="summary-label">📅 Generated:</span>
            <span><?php echo $report_metadata['generated_at']; ?></span>
        </div>
    </div>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger no-print"><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <!-- Filter Controls -->
    <div class="report-controls no-print">
        <form method="GET" action="">
            <div class="filter-row">
                <div class="filter-group">
                    <label>Period</label>
                    <select name="period" onchange="this.form.submit()">
                        <option value="daily" <?php echo $report_period === 'daily' ? 'selected' : ''; ?>>Daily</option>
                        <option value="monthly" <?php echo $report_period === 'monthly' ? 'selected' : ''; ?>>Monthly</option>
                        <option value="yearly" <?php echo $report_period === 'yearly' ? 'selected' : ''; ?>>Yearly</option>
                        <option value="custom" <?php echo $report_period === 'custom' ? 'selected' : ''; ?>>Custom Range</option>
                    </select>
                </div>

                <?php if ($report_period === 'daily'): ?>
                <div class="filter-group">
                    <label>Date</label>
                    <input type="date" name="report_date" value="<?php echo $report_date; ?>">
                </div>
                <?php elseif ($report_period === 'custom'): ?>
                <div class="filter-group">
                    <label>Start Date</label>
                    <input type="date" name="start_date" value="<?php echo $start_date; ?>">
                </div>
                <div class="filter-group">
                    <label>End Date</label>
                    <input type="date" name="end_date" value="<?php echo $end_date; ?>">
                </div>
                <?php endif; ?>

                <div class="filter-group">
                    <label>Status</label>
                    <select name="filter_status">
                        <option value="">All Status</option>
                        <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="confirmed" <?php echo $filter_status === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                        <option value="completed" <?php echo $filter_status === 'completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="cancelled" <?php echo $filter_status === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Species</label>
                    <select name="filter_species">
                        <option value="">All Species</option>
                        <?php foreach ($species_list as $species): ?>
                            <option value="<?php echo htmlspecialchars($species); ?>" <?php echo $filter_species === $species ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($species); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Veterinarian</label>
                    <select name="filter_vet">
                        <option value="">All Vets</option>
                        <?php foreach ($vet_list as $vet): ?>
                            <option value="<?php echo $vet['user_id']; ?>" <?php echo $filter_vet == $vet['user_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($vet['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="search_term" placeholder="Search..." value="<?php echo htmlspecialchars($search_term); ?>">
                </div>

                <div class="filter-group" style="min-width: 180px;">
                    <label>&nbsp;</label>
                    <div>
                        <button type="submit" class="btn-filter">Apply Filters</button>
                        <a href="?period=<?php echo $report_period; ?>&report_date=<?php echo $report_date; ?>" class="btn-reset">Reset</a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['total_appointments'] ?? 0; ?></div>
            <div class="stat-label">Total Appointments</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" style="color: #27ae60;"><?php echo $stats['completed_appointments'] ?? 0; ?></div>
            <div class="stat-label">Completed</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" style="color: #f39c12;"><?php echo $stats['pending_appointments'] ?? 0; ?></div>
            <div class="stat-label">Pending</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" style="color: #3498db;"><?php echo $stats['confirmed_appointments'] ?? 0; ?></div>
            <div class="stat-label">Confirmed</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" style="color: #e74c3c;"><?php echo $stats['cancelled_appointments'] ?? 0; ?></div>
            <div class="stat-label">Cancelled</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $treatment_stats['total_treatments'] ?? 0; ?></div>
            <div class="stat-label">Total Treatments</div>
        </div>
    </div>

    <!-- Report Grid -->
    <div class="report-grid">
        <!-- Appointment Details -->
        <div class="report-matrix-card full-width">
            <h3 class="card-heading">
                Appointment Details (<?php echo count($appointment_details); ?> records)
                <span style="float: right; font-size: 12px; font-weight: normal; color: #7f8c8d;" class="no-print">
                    Sort by: 
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['sort_by' => 'appointment_date', 'sort_order' => $sort_order === 'ASC' ? 'DESC' : 'ASC'])); ?>">
                        Date <?php echo $sort_by === 'appointment_date' ? ($sort_order === 'ASC' ? '↑' : '↓') : ''; ?>
                    </a> |
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['sort_by' => 'status', 'sort_order' => $sort_order === 'ASC' ? 'DESC' : 'ASC'])); ?>">
                        Status <?php echo $sort_by === 'status' ? ($sort_order === 'ASC' ? '↑' : '↓') : ''; ?>
                    </a>
                </span>
            </h3>
            <table class="report-matrix-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Pet</th>
                        <th>Species</th>
                        <th>Owner</th>
                        <th>Vet</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Treatments</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($appointment_details)): ?>
                        <tr><td colspan="9" style="text-align: center; color: #7f8c8d;">No appointments found</td></tr>
                    <?php else: ?>
                        <?php foreach ($appointment_details as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['appointment_date']); ?></td>
                                <td><?php echo htmlspecialchars(substr($row['appointment_time'], 0, 5)); ?></td>
                                <td><?php echo htmlspecialchars($row['pet_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['species']); ?></td>
                                <td><?php echo htmlspecialchars($row['owner_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['vet_name']); ?></td>
                                <td><?php echo htmlspecialchars(substr($row['reason'], 0, 30)) . (strlen($row['reason']) > 30 ? '...' : ''); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $row['status']; ?>">
                                        <?php echo ucfirst($row['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $row['treatment_count'] ?? 0; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Vet Performance -->
        <div class="report-matrix-card">
            <h3 class="card-heading">Veterinarian Performance</h3>
            <table class="report-matrix-table">
                <thead>
                    <tr>
                        <th>Vet</th>
                        <th>Total</th>
                        <th>Completed</th>
                        <th>Cancelled</th>
                        <th>Unique Pets</th>
                        <th>Treatments</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($vet_performance)): ?>
                        <tr><td colspan="6" style="text-align: center; color: #7f8c8d;">No data</td></tr>
                    <?php else: ?>
                        <?php foreach ($vet_performance as $vet): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($vet['full_name']); ?></td>
                                <td><?php echo $vet['total_appointments']; ?></td>
                                <td style="color: #27ae60;"><?php echo $vet['completed_appointments']; ?></td>
                                <td style="color: #e74c3c;"><?php echo $vet['cancelled_appointments']; ?></td>
                                <td><?php echo $vet['unique_pets_treated']; ?></td>
                                <td><?php echo $vet['treatment_records']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Species Distribution -->
        <div class="report-matrix-card">
            <h3 class="card-heading">Species Distribution</h3>
            <table class="report-matrix-table">
                <thead>
                    <tr>
                        <th>Species</th>
                        <th>Appointments</th>
                        <th>Pets</th>
                        <th>Owners</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($species_distribution)): ?>
                        <tr><td colspan="4" style="text-align: center; color: #7f8c8d;">No data</td></tr>
                    <?php else: ?>
                        <?php foreach ($species_distribution as $species): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($species['species'] ?: 'Unknown'); ?></td>
                                <td><?php echo $species['appointment_count']; ?></td>
                                <td><?php echo $species['pet_count']; ?></td>
                                <td><?php echo $species['owner_count']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Monthly Trends -->
        <div class="report-matrix-card">
            <h3 class="card-heading">Monthly Trends (Last 12 Months)</h3>
            <table class="report-matrix-table">
                <thead>
                    <tr>
                        <th>Month</th>
                        <th>Total</th>
                        <th>Completed</th>
                        <th>Completion Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($monthly_trends)): ?>
                        <tr><td colspan="4" style="text-align: center; color: #7f8c8d;">No data</td></tr>
                    <?php else: ?>
                        <?php foreach ($monthly_trends as $trend): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($trend['month']); ?></td>
                                <td><?php echo $trend['total_appointments']; ?></td>
                                <td style="color: #27ae60;"><?php echo $trend['completed']; ?></td>
                                <td>
                                    <?php 
                                    $rate = $trend['total_appointments'] > 0 
                                        ? round(($trend['completed'] / $trend['total_appointments']) * 100, 1) 
                                        : 0;
                                    echo $rate . '%';
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Top Owners -->
        <div class="report-matrix-card">
            <h3 class="card-heading">Top Pet Owners</h3>
            <table class="report-matrix-table">
                <thead>
                    <tr>
                        <th>Owner</th>
                        <th>Pets</th>
                        <th>Appointments</th>
                        <th>Completed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($owner_stats)): ?>
                        <tr><td colspan="4" style="text-align: center; color: #7f8c8d;">No data</td></tr>
                    <?php else: ?>
                        <?php foreach ($owner_stats as $owner): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($owner['full_name']); ?></td>
                                <td><?php echo $owner['pet_count']; ?></td>
                                <td><?php echo $owner['appointment_count']; ?></td>
                                <td style="color: #27ae60;"><?php echo $owner['completed_appointments']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Treatment Summary -->
        <div class="report-matrix-card">
            <h3 class="card-heading">Treatment Summary</h3>
            <table class="report-matrix-table">
                <tbody>
                    <tr>
                        <td><strong>Total Treatments</strong></td>
                        <td><?php echo $treatment_stats['total_treatments']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Treating Veterinarians</strong></td>
                        <td><?php echo $treatment_stats['treating_vets']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Treated Appointments</strong></td>
                        <td><?php echo $treatment_stats['treated_appointments']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Average Treatments per Appointment</strong></td>
                        <td>
                            <?php 
                            $avg = ($treatment_stats['treated_appointments'] > 0) 
                                ? round($treatment_stats['total_treatments'] / $treatment_stats['treated_appointments'], 2) 
                                : 0;
                            echo $avg;
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- PRINT FOOTER -->
    <div class="print-footer">
        <p>This report was generated automatically by the Veterinary Clinic Management System.</p>
        <p>Report ID: <?php echo 'RPT-' . date('Ymd') . '-' . strtoupper(substr(md5(time()), 0, 6)); ?></p>
        <p>&copy; <?php echo date('Y'); ?> Veterinary Clinic. All rights reserved.</p>
    </div>
</div>

<?php include('includes/footer.php'); ?>