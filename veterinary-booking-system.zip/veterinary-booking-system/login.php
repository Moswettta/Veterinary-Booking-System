<?php
// Initialize the session framework
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ingest secure database config connection
require_once('config/db.php');

$message = "";
$message_class = "";
$active_tab = "login";

// -------------------------------------------------------------------------
// POST ACTION: Process Client Registration
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {
    $active_tab = "register";

    $full_name = isset($_POST['reg_full_name']) ? trim($_POST['reg_full_name']) : '';
    $email     = isset($_POST['reg_email']) ? trim($_POST['reg_email']) : '';
    $phone     = isset($_POST['reg_phone']) ? trim($_POST['reg_phone']) : '';
    $password  = isset($_POST['reg_password']) ? $_POST['reg_password'] : '';
    $confirm_password = isset($_POST['reg_confirm_password']) ? $_POST['reg_confirm_password'] : '';

    if (!empty($full_name) && !empty($email) && !empty($password)) {

        if ($password !== $confirm_password) {
            $message = "⚠️ Passwords do not match.";
            $message_class = "msg-danger";
        } else {

            try {
                $check_stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
                $check_stmt->execute([$email]);

                if ($check_stmt->rowCount() > 0) {

                    $message = "❌ Email already exists.";
                    $message_class = "msg-danger";

                } else {

                    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                    $insert_sql = "INSERT INTO users (full_name, email, phone, password, role)
                                   VALUES (?, ?, ?, ?, 'pet_owner')";

                    $insert_stmt = $pdo->prepare($insert_sql);
                    $insert_stmt->execute([$full_name, $email, $phone, $hashed_password]);

                    $message = "🎉 Registration successful! Login below.";
                    $message_class = "msg-success";

                    $active_tab = "login";
                }

            } catch (PDOException $e) {

                $message = "System error: " . $e->getMessage();
                $message_class = "msg-danger";
            }
        }

    } else {

        $message = "Please fill all required fields.";
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// POST ACTION: LOGIN
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {

    $active_tab = "login";

    $email    = isset($_POST['log_email']) ? trim($_POST['log_email']) : '';
    $password = isset($_POST['log_password']) ? $_POST['log_password'] : '';

    if (!empty($email) && !empty($password)) {

        try {

            $stmt = $pdo->prepare("SELECT user_id, full_name, password, role FROM users WHERE email = ?");
            $stmt->execute([$email]);

            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {

                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];

                switch ($user['role']) {

                    case 'admin':
                        header("Location: admin/dashboard.php");
                        break;

                    case 'vet':
                        header("Location: veterinarian/dashboard.php");
                        break;

                    case 'receptionist':
                        header("Location: receptionist/dashboard.php");
                        break;

                    case 'pet_owner':
                    default:
                        header("Location: pet_owner/dashboard.php");
                        break;
                }

                exit;

            } else {

                $message = "❌ Invalid email or password.";
                $message_class = "msg-danger";
            }

        } catch (PDOException $e) {

            $message = "Authentication error: " . $e->getMessage();
            $message_class = "msg-danger";
        }

    } else {

        $message = "Please fill all login fields.";
        $message_class = "msg-danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Oakland Veterinary Clinic | Login</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
    background:
        linear-gradient(rgba(8,15,35,.78), rgba(8,15,35,.82)),
        url('https://images.unsplash.com/photo-1517849845537-4d257902454a?q=80&w=1600&auto=format&fit=crop') center/cover no-repeat;
}

.gateway-card{
    width:100%;
    max-width:450px;
    background:rgba(255,255,255,0.12);
    backdrop-filter:blur(14px);
    border:1px solid rgba(255,255,255,0.18);
    border-radius:25px;
    padding:40px 35px;
    box-shadow:0 20px 40px rgba(0,0,0,0.35);
    animation:fadeIn .6s ease;
}

@keyframes fadeIn{
    from{
        opacity:0;
        transform:translateY(20px);
    }
    to{
        opacity:1;
        transform:translateY(0);
    }
}

.logo-box{
    width:85px;
    height:85px;
    margin:0 auto 18px;
    border-radius:50%;
    background:linear-gradient(135deg,#22c55e,#0f766e);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:40px;
    box-shadow:0 10px 25px rgba(34,197,94,.4);
}

.brand-title{
    text-align:center;
    font-size:28px;
    font-weight:700;
    color:#fff;
    margin-bottom:6px;
}

.brand-subtitle{
    text-align:center;
    color:#dbeafe;
    font-size:14px;
    margin-bottom:30px;
    line-height:1.5;
}

.alert-banner{
    padding:14px;
    border-radius:12px;
    margin-bottom:20px;
    font-size:14px;
    font-weight:500;
    text-align:center;
}

.msg-success{
    background:#dcfce7;
    color:#166534;
}

.msg-danger{
    background:#fee2e2;
    color:#991b1b;
}

.form-group{
    margin-bottom:18px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    color:#fff;
    font-size:14px;
    font-weight:500;
}

.form-control{
    width:100%;
    padding:14px 16px;
    border:none;
    border-radius:14px;
    background:rgba(255,255,255,0.15);
    color:#fff;
    font-size:14px;
    transition:.3s ease;
    border:1px solid transparent;
}

.form-control::placeholder{
    color:#d1d5db;
}

.form-control:focus{
    outline:none;
    border-color:#22c55e;
    background:rgba(255,255,255,0.2);
    box-shadow:0 0 0 4px rgba(34,197,94,.15);
}

.submit-btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:14px;
    background:linear-gradient(135deg,#22c55e,#0f766e);
    color:#fff;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:.3s ease;
    margin-top:10px;
}

.submit-btn:hover{
    transform:translateY(-2px);
    box-shadow:0 12px 20px rgba(34,197,94,.35);
}

.home-btn{
    width:100%;
    display:flex;
    justify-content:center;
    margin-top:15px;
}

.home-btn a{
    text-decoration:none;
    color:#fff;
    background:rgba(255,255,255,0.15);
    padding:12px 20px;
    border-radius:12px;
    font-size:14px;
    transition:.3s ease;
}

.home-btn a:hover{
    background:rgba(255,255,255,0.25);
}

.toggle-view-text{
    text-align:center;
    margin-top:20px;
    font-size:14px;
    color:#e2e8f0;
}

.toggle-view-text a{
    color:#4ade80;
    font-weight:600;
    cursor:pointer;
    text-decoration:none;
}

.toggle-view-text a:hover{
    text-decoration:underline;
}

.hidden-form{
    display:none;
}

@media(max-width:500px){

    .gateway-card{
        padding:30px 22px;
    }

    .brand-title{
        font-size:24px;
    }
}

</style>
</head>

<body>

<div class="gateway-card">

    <div class="logo-box">🐾</div>

    <div class="brand-title">Oakland Vet Clinic</div>

    <div class="brand-subtitle" id="gateway-subtitle">
        Access your veterinary care portal securely
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <!-- LOGIN FORM -->
    <form id="login-form" action="login.php" method="POST"
        class="<?php echo $active_tab !== 'login' ? 'hidden-form' : ''; ?>">

        <input type="hidden" name="action" value="login">

        <div class="form-group">
            <label>Email Address</label>
            <input type="email"
                   name="log_email"
                   class="form-control"
                   placeholder="Enter your email"
                   required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password"
                   name="log_password"
                   class="form-control"
                   placeholder="Enter password"
                   required>
        </div>

        <button type="submit" class="submit-btn">
            🔐 Secure Login
        </button>

        <div class="home-btn">
            <a href="index.php">🏠 Return Home</a>
        </div>

        <div class="toggle-view-text">
            Don't have an account?
            <a onclick="togglePortalView('register')">Register here</a>
        </div>

    </form>

    <!-- REGISTER FORM -->
    <form id="register-form" action="login.php" method="POST"
        class="<?php echo $active_tab !== 'register' ? 'hidden-form' : ''; ?>">

        <input type="hidden" name="action" value="register">

        <div class="form-group">
            <label>Full Name *</label>
            <input type="text"
                   name="reg_full_name"
                   class="form-control"
                   placeholder="Jane Doe"
                   required>
        </div>

        <div class="form-group">
            <label>Email Address *</label>
            <input type="email"
                   name="reg_email"
                   class="form-control"
                   placeholder="jane@example.com"
                   required>
        </div>

        <div class="form-group">
            <label>Phone Number</label>
            <input type="text"
                   name="reg_phone"
                   class="form-control"
                   placeholder="0700000000">
        </div>

        <div class="form-group">
            <label>Password *</label>
            <input type="password"
                   name="reg_password"
                   class="form-control"
                   placeholder="Create password"
                   required>
        </div>

        <div class="form-group">
            <label>Confirm Password *</label>
            <input type="password"
                   name="reg_confirm_password"
                   class="form-control"
                   placeholder="Confirm password"
                   required>
        </div>

        <button type="submit" class="submit-btn">
            🐶 Create Account
        </button>

        <div class="toggle-view-text">
            Already have an account?
            <a onclick="togglePortalView('login')">Login here</a>
        </div>

    </form>

</div>

<script>

function togglePortalView(viewMode){

    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const subTitle = document.getElementById('gateway-subtitle');

    if(viewMode === 'register'){

        loginForm.classList.add('hidden-form');
        registerForm.classList.remove('hidden-form');

        subTitle.textContent =
            "Create your pet owner account and manage appointments";

    } else {

        registerForm.classList.add('hidden-form');
        loginForm.classList.remove('hidden-form');

        subTitle.textContent =
            "Access your veterinary care portal securely";
    }
}

</script>

</body>
</html>