<?php
// Automated Clinical Roster Mapping Cache Engine File - Do Not Edit Manually
$vet_rosters = array (
  7 => 
  array (
    'Monday' => 
    array (
      'active' => 0,
      'start_time' => '08:00',
      'end_time' => '17:00',
    ),
    'Tuesday' => 
    array (
      'active' => 0,
      'start_time' => '08:00',
      'end_time' => '17:00',
    ),
    'Wednesday' => 
    array (
      'active' => 1,
      'start_time' => '08:00',
      'end_time' => '17:00',
    ),
    'Thursday' => 
    array (
      'active' => 1,
      'start_time' => '08:00',
      'end_time' => '17:00',
    ),
    'Friday' => 
    array (
      'active' => 1,
      'start_time' => '08:00',
      'end_time' => '17:00',
    ),
    'Saturday' => 
    array (
      'active' => 1,
      'start_time' => '08:00',
      'end_time' => '17:00',
    ),
    'Sunday' => 
    array (
      'active' => 1,
      'start_time' => '08:00',
      'end_time' => '17:00',
    ),
  ),
);
