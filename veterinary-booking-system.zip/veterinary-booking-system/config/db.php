<?php
// config/db.php

// Database connection parameters
$host     = 'localhost';
$dbname   = 'vet_booking_db';
$username = 'root';
$password = ''; // Default XAMPP password is empty
$charset  = 'utf8mb4';

// Data Source Name (DSN) specifies the driver, host, database name, and charset
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

// Set configuration options for PDO
$options = [
    // Throws exceptions when SQL errors occur so you can debug easily
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    // Fetches data as associative arrays (e.g., $row['full_name'])
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    // Disables emulation of prepared statements for better security
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Create the PDO instance (establish connection)
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    // If connection fails, stop execution and show the error
    die("Database connection failed: " . $e->getMessage());
}
?>