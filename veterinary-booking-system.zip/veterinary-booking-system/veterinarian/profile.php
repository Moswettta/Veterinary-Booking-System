<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as a Veterinary Medical Officer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

require_once('../config/db.php');

$vet_id = (int)$_SESSION['user_id'];
$message = "";
$message_class = "";

// -------------------------------------------------------------------------
// POST ACTION: PROCESS UPDATES
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // Update Personal Information
    if ($_POST['action'] === 'update_profile') {
        $full_name = trim($_POST['full_name']);
        $email     = trim($_POST['email']);
        $phone     = trim($_POST['phone']);

        try {
            $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ? AND role = 'vet'");
            $stmt->execute([$full_name, $email, $phone, $vet_id]);
            $_SESSION['full_name'] = $full_name; // Refresh session cache
            $message = "Profile updated successfully.";
            $message_class = "msg-success";
        } catch (PDOException $e) {
            $message = "Error: " . $e->getMessage();
            $message_class = "msg-danger";
        }
    }

    // Update Password
    if ($_POST['action'] === 'change_password') {
        $current_pass = $_POST['current_password'];
        $new_pass     = $_POST['new_password'];
        
        $stmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
        $stmt->execute([$vet_id]);
        $user = $stmt->fetch();

        if ($user && password_verify($current_pass, $user['password'])) {
            $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
            $upd = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $upd->execute([$hashed, $vet_id]);
            $message = "Password updated successfully.";
            $message_class = "msg-success";
        } else {
            $message = "Current password invalid.";
            $message_class = "msg-danger";
        }
    }
}

// Fetch current data
$stmt = $pdo->prepare("SELECT full_name, email, phone FROM users WHERE user_id = ?");
$stmt->execute([$vet_id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="vet-main-content-canvas">
    <style>
        .profile-container { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        .card { background: #fff; padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 5px; }
        input { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; }
        .btn { background: #0f172a; color: #fff; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; }
        .msg-success { padding: 10px; background: #d1fae5; color: #065f46; margin-bottom: 20px; border-radius: 6px; }
        .msg-danger { padding: 10px; background: #fee2e2; color: #991b1b; margin-bottom: 20px; border-radius: 6px; }
    </style>

    <h2>Profile Settings</h2>
    <?php if ($message): ?><div class="<?php echo $message_class; ?>"><?php echo $message; ?></div><?php endif; ?>

    <div class="profile-container">
        <div class="card">
            <h3>Personal Details</h3>
            <form method="POST">
                <input type="hidden" name="action" value="update_profile">
                <div class="form-group"><label>Full Name</label><input type="text" name="full_name" value="<?php echo htmlspecialchars($profile['full_name']); ?>" required></div>
                <div class="form-group"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($profile['email']); ?>" required></div>
                <div class="form-group"><label>Phone</label><input type="text" name="phone" value="<?php echo htmlspecialchars($profile['phone']); ?>" required></div>
                <button type="submit" class="btn">Update Profile</button>
            </form>
        </div>

        <div class="card">
            <h3>Change Password</h3>
            <form method="POST">
                <input type="hidden" name="action" value="change_password">
                <div class="form-group"><label>Current Password</label><input type="password" name="current_password" required></div>
                <div class="form-group"><label>New Password</label><input type="password" name="new_password" required></div>
                <button type="submit" class="btn">Update Password</button>
            </form>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>