<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as a Veterinary Medical Officer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$vet_id = (int)$_SESSION['user_id'];
$error_msg = "";

// -------------------------------------------------------------------------
// AGGREGATION METRICS: Compute Summary Operational Statistics
// -------------------------------------------------------------------------
$stats = ['pending' => 0, 'confirmed' => 0, 'completed' => 0];
try {
    $stats_sql = "SELECT status, COUNT(*) as volume FROM appointments WHERE vet_id = ? GROUP BY status";
    $stats_stmt = $pdo->prepare($stats_sql);
    $stats_stmt->execute([$vet_id]);
    while ($row = $stats_stmt->fetch(PDO::FETCH_ASSOC)) {
        $stats[$row['status']] = (int)$row['volume'];
    }
} catch (PDOException $e) {
    $error_msg = "Metrics sync failure: " . $e->getMessage();
}

// -------------------------------------------------------------------------
// READ ACTION: FETCH ASSIGNED CLIENTS AND PETS QUEUE FOR TODAY AND BEYOND
// -------------------------------------------------------------------------
try {
    $dashboard_queue_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status, a.reason,
                                   p.pet_name, p.species, p.breed,
                                   u_client.full_name AS client_name, u_client.phone AS client_phone
                            FROM appointments a
                            INNER JOIN pets p ON a.pet_id = p.pet_id
                            INNER JOIN users u_client ON p.owner_id = u_client.user_id
                            WHERE a.vet_id = ? AND a.status IN ('pending', 'confirmed')
                            ORDER BY a.appointment_date ASC, a.appointment_time ASC
                            LIMIT 10"; // Keep dashboard clean, limit to top 10 imminent allocations
    
    $queue_stmt = $pdo->prepare($dashboard_queue_sql);
    $queue_stmt->execute([$vet_id]);
    $assigned_workload = $queue_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $assigned_workload = [];
    if (empty($error_msg)) {
        $error_msg = "Error extracting workload assignments: " . $e->getMessage();
    }
}

include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="vet-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        .page-title-block p { color: #64748b; font-size: 14px; margin-top: 2px; }

        /* Summary Statistics Cards Row Grid */
        .stats-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px;
            display: flex; flex-direction: column; justify-content: space-between;
        }
        .stat-meta { font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-value { font-size: 28px; font-weight: 700; color: #0f172a; margin-top: 5px; }
        
        .border-confirmed { border-left: 4px solid #3563eb; }
        .border-pending { border-left: 4px solid #d97706; }
        .border-completed { border-left: 4px solid #10b981; }

        /* Workspace Core Table layouts */
        .workspace-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 25px; }
        .card-heading { color: #0f172a; font-size: 16px; font-weight: 600; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 20px; }

        .dashboard-table { width: 100%; border-collapse: collapse; font-size: 13.5px; text-align: left; }
        .dashboard-table th { background: #f8fafc; color: #64748b; padding: 12px; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
        .dashboard-table td { padding: 14px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        .dashboard-table tr:hover { background-color: #f8fafc; }

        /* Hyperlink Active Context Transformation Rules */
        .client-link-node {
            color: #3b82f6; text-decoration: none; font-weight: 600; display: inline-flex; align-items: center; gap: 4px;
            padding: 4px 8px; background-color: #eff6ff; border-radius: 4px; border: 1px solid #dbeafe; transition: all 0.2s;
        }
        .client-link-node:hover {
            color: #1d4ed8; background-color: #dbeafe; border-color: #bfdbfe; transform: translateY(-1px);
        }

        .sub-text { font-size: 12px; color: #64748b; }
        .badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
        .badge.confirmed { background: #e0e7ff; color: #3730a3; }
        .badge.pending { background: #fef3c7; color: #92400e; }
    </style>

    <div class="page-title-block">
        <h2>Medical Officer Command Room</h2>
       <p>Welcome back, Dr. <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Officer'); ?>. Here is your clinical workload status blueprint.</p>
    </div>

    <?php if (!empty($error_msg)): ?>
        <div style="padding: 12px; background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; border-radius: 6px; margin-bottom: 20px;">
            <?php echo htmlspecialchars($error_msg); ?>
        </div>
    <?php endif; ?>

    <div class="stats-summary-grid">
        <div class="stat-card border-confirmed">
            <span class="stat-meta">Active Assigned Clients</span>
            <span class="stat-value"><?php echo $stats['confirmed']; ?></span>
        </div>
        <div class="stat-card border-pending">
            <span class="stat-meta">Pending Review Cases</span>
            <span class="stat-value"><?php echo $stats['pending']; ?></span>
        </div>
        <div class="stat-card border-completed">
            <span class="stat-meta">Historical Total Resolved</span>
            <span class="stat-value"><?php echo $stats['completed']; ?></span>
        </div>
    </div>

    <div class="workspace-card">
        <h3 class="card-heading">📆 Imminent Allocated Patient Pipelines (Top 10 Schedules)</h3>
        
        <?php if (count($assigned_workload) > 0): ?>
            <table class="dashboard-table">
                <thead>
                    <tr>
                        <th>Time Allocation</th>
                        <th>Assigned Client Profile</th>
                        <th>Patient Context</th>
                        <th>Clinical Intention</th>
                        <th>State</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($assigned_workload as $case): ?>
                        <tr>
                            <td>
                                <strong><?php echo date('M d, Y', strtotime($case['appointment_date'])); ?></strong>
                                <div class="sub-text">⏱️ <?php echo date('h:i A', strtotime($case['appointment_time'])); ?></div>
                            </td>

                            <td>
                                <a href="treat_patient.php?appointment_id=<?php echo $case['appointment_id']; ?>" class="client-link-node" title="Click to launch triage treatment workspace for this client">
                                    👤 <?php echo htmlspecialchars($case['client_name']); ?> ↗
                                </a>
                                <div class="sub-text" style="margin-top: 4px; padding-left: 8px;">📞 <?php echo htmlspecialchars($case['client_phone']); ?></div>
                            </td>

                            <td>
                                <strong>🐾 <?php echo htmlspecialchars(ucfirst($case['pet_name'])); ?></strong>
                                <div class="sub-text">Species: <?php echo htmlspecialchars($case['species']); ?> (<?php echo htmlspecialchars($case['breed'] ?: 'Mixed'); ?>)</div>
                            </td>

                            <td>
                                <span style="color: #334155; font-weight: 500;">"<?php echo htmlspecialchars($case['reason']); ?>"</span>
                            </td>

                            <td>
                                <span class="badge <?php echo $case['status']; ?>"><?php echo $case['status']; ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div style="text-align: center; color: #94a3b8; font-style: italic; padding: 40px 0;">
                🎉 Outstanding! No assigned clients await processing in your clinic pipeline stream right now.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php 
include('includes/footer.php'); 
?>