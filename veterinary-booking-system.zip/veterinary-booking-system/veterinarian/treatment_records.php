<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as a Veterinary Medical Officer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$vet_id = (int)$_SESSION['user_id'];
$error_msg = "";
$search_query = "";

// Handle search functionality if a search term is submitted
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $search_query = trim($_GET['search']);
}

try {
    // Base SQL string optimized for your schema to extract comprehensive historical treatment logs
    $records_sql = "SELECT tr.record_id, tr.diagnosis, tr.treatment, tr.follow_up_date, tr.created_at AS treatment_date,
                           p.pet_name, p.species, p.breed,
                           u_client.full_name AS client_name, u_client.phone AS client_phone
                    FROM treatment_records tr
                    INNER JOIN appointments a ON tr.appointment_id = a.appointment_id
                    INNER JOIN pets p ON a.pet_id = p.pet_id
                    INNER JOIN users u_client ON p.owner_id = u_client.user_id
                    WHERE tr.vet_id = ?";
    
    // Dynamically append search filters for Client or Pet Name if active
    if (!empty($search_query)) {
        $records_sql .= " AND (p.pet_name LIKE ? OR u_client.full_name LIKE ?)";
    }
    
    $records_sql .= " ORDER BY tr.created_at DESC";
    
    $stmt = $pdo->prepare($records_sql);
    
    if (!empty($search_query)) {
        $wildcard = "%" . $search_query . "%";
        $stmt->execute([$vet_id, $wildcard, $wildcard]);
    } else {
        $stmt->execute([$vet_id]);
    }
    
    $historical_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $historical_logs = [];
    $error_msg = "Error compiling historical diagnostic data: " . $e->getMessage();
}

include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="vet-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        .page-title-block p { color: #64748b; font-size: 14px; margin-top: 2px; }

        /* Search Filtering Control Panel */
        .search-filter-card {
            background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px;
            padding: 15px 20px; margin-bottom: 25px; display: flex; align-items: center; justify-content: space-between; gap: 15px;
        }
        .search-form { display: flex; gap: 10px; width: 100%; max-width: 500px; }
        .search-input {
            flex-grow: 1; padding: 9px 14px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13.5px; color: #334155;
        }
        .search-input:focus { outline: none; border-color: #10b981; }
        .btn-search {
            background-color: #0f172a; color: #ffffff; border: none; padding: 9px 16px; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 13.5px;
        }
        .btn-search:hover { background-color: #1e293b; }
        .clear-link { font-size: 13px; color: #64748b; text-decoration: none; display: flex; align-items: center; }
        .clear-link:hover { color: #dc2626; }

        /* Master Records Board Workspace */
        .workspace-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 25px; }
        
        .records-table { width: 100%; border-collapse: collapse; font-size: 13.5px; text-align: left; }
        .records-table th { background: #f8fafc; color: #64748b; padding: 12px; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
        .records-table td { padding: 16px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
        .records-table tr:hover { background-color: #f8fafc; }

        /* Document Text Blocks Blockquote Formatting */
        .clinical-text-block {
            background-color: #f8fafc; border-left: 3px solid #cbd5e1; padding: 8px 12px; border-radius: 0 6px 6px 0; margin-top: 5px; font-size: 13px; color: #475569; line-height: 1.4;
        }
        .border-diagnosis { border-left-color: #f59e0b; }
        .border-treatment { border-left-color: #10b981; }

        .meta-label { font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; display: block; margin-top: 4px; }
        .sub-text { font-size: 12px; color: #64748b; margin-top: 2px; }
        .badge-date { background-color: #f1f5f9; color: #334155; padding: 3px 6px; border-radius: 4px; font-size: 12px; font-weight: 600; }
        .badge-followup { background-color: #fff7ed; color: #c2410c; border: 1px solid #ffedd5; padding: 2px 6px; border-radius: 4px; font-size: 11.5px; font-weight: 600; display: inline-block; margin-top: 5px; }
    </style>

    <div class="page-title-block">
        <h2>Historical Patient Medical Logs</h2>
        <p>Complete clinical database records of diagnoses, treatment actions, and case histories resolved under your desk.</p>
    </div>

    <?php if (!empty($error_msg)): ?>
        <div style="padding: 12px; background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; border-radius: 6px; margin-bottom: 20px;">
            <?php echo htmlspecialchars($error_msg); ?>
        </div>
    <?php endif; ?>

    <div class="search-filter-card">
        <form action="treatment_records.php" method="GET" class="search-form">
            <input type="text" name="search" class="search-input" placeholder="Search by Client Name or Patient (Pet) Name..." value="<?php echo htmlspecialchars($search_query); ?>">
            <button type="submit" class="btn-search">🔎 Filter Logs</button>
        </form>
        <?php if (!empty($search_query)): ?>
            <a href="treatment_records.php" class="clear-link">❌ Clear Active Filter</a>
        <?php endif; ?>
    </div>

    <div class="workspace-card">
        <?php if (count($historical_logs) > 0): ?>
            <table class="records-table">
                <thead>
                    <tr>
                        <th style="width: 15%;">Session Date</th>
                        <th style="width: 25%;">Patient (Pet Context)</th>
                        <th style="width: 25%;">Client Details</th>
                        <th style="width: 35%;">Clinical Findings & Resolutions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($historical_logs as $log): ?>
                        <tr>
                            <td>
                                <span class="badge-date"><?php echo date('M d, Y', strtotime($log['treatment_date'])); ?></span>
                                <div class="sub-text" style="padding-left: 2px; margin-top: 5px;">⏱️ <?php echo date('h:i A', strtotime($log['treatment_date'])); ?></div>
                            </td>

                            <td>
                                <strong style="color: #0f172a; font-size: 14px;">🐾 <?php echo htmlspecialchars(ucfirst($log['pet_name'])); ?></strong>
                                <div class="sub-text">
                                    Species: <strong><?php echo htmlspecialchars($log['species']); ?></strong><br>
                                    Breed: <?php echo htmlspecialchars($log['breed'] ?: 'Mixed Breed'); ?>
                                </div>
                            </td>

                            <td>
                                <strong style="color: #0f172a;">👤 <?php echo htmlspecialchars($log['client_name']); ?></strong>
                                <div class="sub-text" style="margin-top: 4px;">
                                    📞 <?php echo htmlspecialchars($log['client_phone']); ?>
                                </div>
                            </td>

                            <td>
                                <span class="meta-label">Verified Diagnosis Findings</span>
                                <div class="clinical-text-block border-diagnosis">
                                    <?php echo nl2br(htmlspecialchars($log['diagnosis'])); ?>
                                </div>

                                <span class="meta-label" style="margin-top: 12px;">Administered Treatment Interventions</span>
                                <div class="clinical-text-block border-treatment">
                                    <?php echo nl2br(htmlspecialchars($log['treatment'])); ?>
                                </div>

                                <?php if (!empty($log['follow_up_date'])): ?>
                                    <div class="badge-followup">
                                        📅 Follow-Up Threshold: <?php echo date('M d, Y', strtotime($log['follow_up_date'])); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div style="text-align: center; padding: 50px 20px; color: #94a3b8; font-style: italic;">
                No historical medical records match your selected query criteria inside the clinical repository database.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php 
include('includes/footer.php'); 
?>