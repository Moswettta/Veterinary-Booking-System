<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as a Veterinary Medical Officer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

$vet_id = (int)$_SESSION['user_id'];
$message = "";
$message_class = "";

// Define filesystem path for the standalone roster caching engine matrix
$cache_dir  = '../config';
$cache_file = $cache_dir . '/vet_schedule_cache.php';

// Ensure config array framework structure is initialized cleanly if missing
if (!file_exists($cache_file)) {
    if (!is_dir($cache_dir)) {
        mkdir($cache_dir, 0755, true);
    }
    file_put_contents($cache_file, "<?php\n\$vet_rosters = [];\n");
}

// Ingest the persistent data file state mapping array
include($cache_file);

// Standard default operating calendar matrix model framework
$days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// -------------------------------------------------------------------------
// POST ACTION: PROCESS AVAILABILITY ROSTER STATE WRITES
// -------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_roster') {
    
    $submitted_roster = [];
    
    foreach ($days_of_week as $day) {
        $is_active = isset($_POST['active_' . $day]) ? 1 : 0;
        $start_time = $_POST['start_' . $day] ?? '08:00';
        $end_time   = $_POST['end_' . $day] ?? '17:00';
        
        $submitted_roster[$day] = [
            'active'     => $is_active,
            'start_time' => $start_time,
            'end_time'   => $end_time
        ];
    }
    
    // Update global collection with active practitioner token index data
    $vet_rosters[$vet_id] = $submitted_roster;
    
    // Compile clean, structured PHP source data to output to the cache block file
    $export_content = "<?php\n// Automated Clinical Roster Mapping Cache Engine File - Do Not Edit Manually\n";
    $export_content .= "\$vet_rosters = " . var_export($vet_rosters, true) . ";\n";
    
    if (file_put_contents($cache_file, $export_content)) {
        $message = "📆 Operational roster availability guidelines locked and cached successfully!";
        $message_class = "msg-success";
    } else {
        $message = "System I/O Failure: Inability to write configuration matrix state tokens to storage disk.";
        $message_class = "msg-danger";
    }
}

// -------------------------------------------------------------------------
// READ ACTION: ISOLATE WORK SCHEDULE RECORD APPERTAINING TO ACTIVE SESSION
// -------------------------------------------------------------------------
$my_roster = $vet_rosters[$vet_id] ?? [];
?>

<?php 
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="vet-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        .page-title-block p { color: #64748b; font-size: 14px; margin-top: 2px; }

        .workspace-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 25px; }
        .card-heading { color: #0f172a; font-size: 16px; font-weight: 600; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 20px; }

        /* Roster Matrix Table Grid Styling Framework */
        .roster-table { width: 100%; border-collapse: collapse; font-size: 13.5px; text-align: left; }
        .roster-table th { background: #f8fafc; color: #64748b; padding: 12px; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
        .roster-table td { padding: 14px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        .roster-table tr:hover { background-color: #f8fafc; }

        /* Custom Interactive Controls Design UI rules */
        .switch-control { position: relative; display: inline-block; width: 42px; height: 22px; }
        .switch-control input { opacity: 0; width: 0; height: 0; }
        .slider-node {
            position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
            background-color: #cbd5e1; transition: .3s; border-radius: 34px;
        }
        .slider-node:before {
            position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px;
            background-color: white; transition: .3s; border-radius: 50%;
        }
        input:checked + .slider-node { background-color: #10b981; }
        input:checked + .slider-node:before { transform: translateX(20px); }

        .time-picker {
            padding: 6px 10px; border: 1px solid #cbd5e1; border-radius: 6px;
            font-size: 13px; color: #334155; background: #ffffff;
        }
        .time-picker:focus { outline: none; border-color: #10b981; }

        .action-submit-btn {
            background-color: #0f172a; color: #ffffff; border: none; padding: 12px 24px;
            border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px; margin-top: 25px; transition: background 0.2s;
        }
        .action-submit-btn:hover { background-color: #1e293b; }

        .alert-banner { padding: 12px 15px; border-radius: 6px; margin-bottom: 25px; font-size: 14px; font-weight: 500; }
        .msg-success { background-color: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .msg-danger { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        
        .day-highlight { font-weight: 600; color: #0f172a; font-size: 14px; }
        .range-divider { color: #94a3b8; font-weight: 500; margin: 0 5px; }
    </style>

    <div class="page-title-block">
        <h2>Roster Shift Availability Parameters</h2>
        <p>Configure weekly duty time loops. This matrix dictates case routing allocation structures for the administration console.</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert-banner <?php echo $message_class; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="workspace-card">
        <h3 class="card-heading">🛠️ Weekly Duty Scheduling Matrix</h3>
        
        <form action="availability.php" method="POST">
            <input type="hidden" name="action" value="save_roster">
            
            <table class="roster-table">
                <thead>
                    <tr>
                        <th style="width: 20%;">Calendar Target Day</th>
                        <th style="width: 25%;">Active Duty Availability Toggle</th>
                        <th style="width: 55%;">Shift Operational Time Windows</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($days_of_week as $day): 
                        // Resolve previously saved structural layout states or apply defaults fallback structures
                        $day_active = isset($my_roster[$day]) ? (int)$my_roster[$day]['active'] : 1;
                        $start_val  = $my_roster[$day]['start_time'] ?? '08:00';
                        $end_val    = $my_roster[$day]['end_time'] ?? '17:00';
                    ?>
                        <tr>
                            <td>
                                <span class="day-highlight"><?php echo $day; ?></span>
                            </td>

                            <td>
                                <label class="switch-control">
                                    <input type="checkbox" name="active_<?php echo $day; ?>" value="1" <?php echo ($day_active === 1) ? 'checked' : ''; ?>>
                                    <span class="slider-node"></span>
                                </label>
                            </td>

                            <td>
                                <input type="time" name="start_<?php echo $day; ?>" class="time-picker" value="<?php echo htmlspecialchars($start_val); ?>">
                                <span class="range-divider">to</span>
                                <input type="time" name="end_<?php echo $day; ?>" class="time-picker" value="<?php echo htmlspecialchars($end_val); ?>">
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <button type="submit" class="action-submit-btn">💾 Commit Schedule Parameters</button>
        </form>
    </div>

</div>

<?php 
include('includes/footer.php'); 
?>