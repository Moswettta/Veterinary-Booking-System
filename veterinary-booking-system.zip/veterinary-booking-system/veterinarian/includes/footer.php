<?php
// Secure session framework validation
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Re-verify server context to prevent isolated directory traversal vulnerabilities
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    exit;
}
?>
    </div> <footer class="vet-portal-footer">
        <div class="footer-layout-alignment">
            <div>&copy; <?php echo date('Y'); ?> <strong>Oakland Veterinary Clinic</strong>. All Rights Reserved.</div>
            <div class="terminal-status-cluster">
                <span class="pulse-indicator"></span>
                <span class="node-label">Medical Node Active</span>
            </div>
        </div>
    </footer>

    <style>
        .vet-portal-footer {
            background-color: #ffffff;
            border-top: 1px solid var(--border-color);
            padding: 18px 30px;
            font-size: 13px;
            color: var(--text-muted);
            width: 100%;
            position: relative;
            z-index: 998;
            margin-top: auto; /* Clean layout engine mechanism to anchor the footer perfectly at viewport base */
        }

        .footer-layout-alignment {
            display: flex;
            justify-content: space-between;
            align-items: center;
            /* Perfectly offsets content canvas based on sidebar dimension values */
            margin-left: var(--sidebar-width);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .terminal-status-cluster {
            display: flex;
            align-items: center;
            gap: 8px;
            background-color: #f8fafc;
            border: 1px solid var(--border-color);
            padding: 4px 10px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 11.5px;
            font-weight: 600;
        }

        .pulse-indicator {
            width: 7px;
            height: 7px;
            background-color: var(--accent-primary); /* Uses green operation token from layout parameters */
            border-radius: 50%;
            display: inline-block;
            position: relative;
        }

        /* Subtle diagnostic pulse ring effect */
        .pulse-indicator::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background-color: var(--accent-primary);
            border-radius: 50%;
            animation: nodePulse 2s infinite ease-in-out;
            opacity: 0.6;
        }

        @keyframes nodePulse {
            0% { transform: scale(1); opacity: 0.6; }
            100% { transform: scale(2.8); opacity: 0; }
        }

        /* Responsive Metric Adaptability Rule Shifts for Mobile Layout Breakpoints */
        @media (max-width: 992px) {
            .footer-layout-alignment {
                margin-left: 0;
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }
    </style>
</body>
</html>