<?php
// Secure session framework validation
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Re-verify server context to prevent isolated directory traversal vulnerabilities
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    exit;
}

// Sniff the exact file location string to toggle the active-link CSS class layout state
$active_script = basename($_SERVER['PHP_SELF']);
?>

<aside class="vet-portal-sidebar">
    
    <div class="sidebar-branding-plate">
        <div class="brand-glyph">🐾</div>
        <div class="brand-identity-meta">
            <h1>Oakland Vet</h1>
            <span>Clinical Node Console</span>
        </div>
    </div>

    <nav class="sidebar-nav-group">
        
        <div class="nav-section-label">Medical Workspaces</div>

        <a href="assigned_clients.php" class="sidebar-link <?php echo ($active_script === 'assigned_clients.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">👥</span>
            <span class="link-label">Assigned Workload</span>
        </a>

        <a href="queue.php" class="sidebar-link <?php echo ($active_script === 'queue.php' || $active_script === 'treat_patient.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">⏳</span>
            <span class="link-label">Triage & Queue</span>
        </a>

        <a href="treatment_records.php" class="sidebar-link <?php echo ($active_script === 'treatment_records.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">🗂️</span>
            <span class="link-label">Treatment Logs</span>
        </a>

        <div class="nav-section-label">Practitioner Profiles</div>

        <a href="availability.php" class="sidebar-link <?php echo ($active_script === 'availability.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">📆</span>
            <span class="link-label">My Availability</span>
        </a>

        <a href="profile.php" class="sidebar-link <?php echo ($active_script === 'profile.php') ? 'active-link' : ''; ?>">
            <span class="link-icon">⚙️</span>
            <span class="link-label">Profile Settings</span>
        </a>

    </nav>

    <div class="sidebar-termination-block">
        <a href="../logout.php" class="sidebar-logout-trigger">
            <span class="logout-icon">🚪</span>
            <span>Invalidate Session</span>
        </a>
    </div>

</aside>

<style>
    .vet-portal-sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        width: var(--sidebar-width);
        background-color: #0f172a; /* Deep charcoal slate providing distinct contrast to canvas */
        border-right: 1px solid #1e293b;
        display: flex;
        flex-direction: column;
        z-index: 1000;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .sidebar-branding-plate {
        height: var(--topbar-height);
        padding: 0 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        border-bottom: 1px solid #1e293b;
    }

    .brand-glyph {
        font-size: 24px;
        background-color: #1e293b;
        width: 40px;
        height: 40px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .brand-identity-meta h1 {
        font-size: 15px;
        font-weight: 700;
        color: #f8fafc;
        line-height: 1.2;
    }

    .brand-identity-meta span {
        font-size: 11px;
        color: #94a3b8;
        font-weight: 500;
    }

    .sidebar-nav-group {
        flex-grow: 1;
        padding: 24px 16px;
        display: flex;
        flex-direction: column;
        gap: 4px;
        overflow-y: auto;
    }

    .nav-section-label {
        font-size: 10.5px;
        font-weight: 700;
        color: #475569;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        padding: 15px 12px 6px 12px;
    }

    .sidebar-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 14px;
        color: #94a3b8;
        text-decoration: none;
        font-size: 13.5px;
        font-weight: 500;
        border-radius: 6px;
        transition: all 0.2s ease;
    }

    .sidebar-link:hover {
        background-color: #1e293b;
        color: #f8fafc;
    }

    .sidebar-link.active-link {
        background-color: var(--accent-primary); /* Illumination active indicator color matching header blueprint */
        color: #ffffff;
        font-weight: 600;
    }

    .link-icon {
        font-size: 16px;
        display: inline-block;
        width: 20px;
        text-align: center;
    }

    .sidebar-termination-block {
        padding: 16px;
        border-top: 1px solid #1e293b;
    }

    .sidebar-logout-trigger {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 14px;
        background-color: #1e293b;
        color: #f1f5f9;
        text-decoration: none;
        font-size: 13px;
        font-weight: 600;
        border-radius: 6px;
        text-align: center;
        justify-content: center;
        transition: background 0.2s;
    }

    .sidebar-logout-trigger:hover {
        background-color: #991b1b; /* High risk critical indicator execution flag */
        color: #ffffff;
    }

    /* Screen metric layout override handling rules */
    @media (max-width: 992px) {
        .vet-portal-sidebar {
            transform: translateX(-100%); /* Hides navigation off canvas matrix elements automatically on low DPI arrays */
        }
        /* Touch point trigger toggle states can be appended using an alternate reactive class flag layer if required */
        .vet-portal-sidebar.drawer-active {
            transform: translateX(0);
        }
    }
</style>