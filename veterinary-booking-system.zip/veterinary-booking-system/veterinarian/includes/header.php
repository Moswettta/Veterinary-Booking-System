<?php
// Secure session framework validation
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Global Security Guardrail: Redirect to login if user session context is corrupted or non-vet
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

// Determine the current active page filename context for dynamic sidebar link illumination
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinary Medical Portal - Oakland Vet Clinic</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --font-primary: 'Inter', sans-serif;
            --bg-canvas: #f8fafc;
            --surface-card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --accent-primary: #10b981; /* Emerald Green representing Medical Operation Active states */
            --accent-hover: #059669;
            --sidebar-width: 260px;
            --topbar-height: 70px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: var(--font-primary);
        }


        body {
            background-color: var(--bg-canvas);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Master System Frame Work Wrapper Canvas Container */
        .vet-portal-layout-wrapper {
            display: flex;
            flex: 1;
            width: 100%;
            position: relative;
        }

        /* Central Working Canvas Node Content Window Restrictor Offset */
        .vet-main-content-canvas {
            flex-grow: 1;
            padding: 40px 30px;
            margin-left: var(--sidebar-width);
            margin-top: var(--topbar-height);
            min-height: calc(100vh - var(--topbar-height));
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            width: calc(100% - var(--sidebar-width));
            display: flex;
            flex-direction: column;
        }

        /* Top Control Bar Structural Framework Definition */
        .vet-portal-topbar {
            position: fixed;
            top: 0;
            right: 0;
            left: var(--sidebar-width);
            height: var(--topbar-height);
            background-color: var(--surface-card);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 30px;
            z-index: 999;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .topbar-branding-context {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .portal-env-badge {
            background-color: #e0f2fe;
            color: #0369a1;
            font-size: 11px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .topbar-identity-cluster {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .practitioner-meta {
            text-align: right;
        }

        .practitioner-name {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-main);
        }

        .practitioner-title-tag {
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 1px;
        }

        .avatar-circle {
            width: 40px;
            height: 40px;
            background-color: #ecfdf5;
            border: 1px solid #a7f3d0;
            color: var(--accent-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 15px;
        }
        .alert{
    display:block;
    width:100%;
    margin-bottom:25px;
    padding:16px 20px;
    background:#d4edda;
    color:#155724;
    border-left:5px solid #28a745;
    border-radius:6px;
}

        /* Adaptive Responsive Rule Breakpoints for Mobile Interactivity Layout Blocks */
        @media (max-width: 992px) {
            .vet-main-content-canvas {
                margin-left: 0;
                width: 100%;
                padding: 30px 20px;
            }
            .vet-portal-topbar {
                left: 0;
                padding: 0 20px;
            }
        }
    </style>
</head>
<body>

    <header class="vet-portal-topbar">
        <div class="topbar-branding-context">
            <span class="portal-env-badge">🥼 Practitioner Roster Node</span>
        </div>

        <div class="topbar-identity-cluster">
            <div class="practitioner-meta">
                <div class="practitioner-name">Dr. <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Medical Officer'); ?></div>
                <div class="practitioner-title-tag">Veterinary Surgeon</div>
            </div>
            <div class="avatar-circle">
                <?php 
                    // Extract initials from full name parameter strings dynamically 
                    $words = explode(' ', $_SESSION['full_name'] ?? 'Vet Officer');
                    echo strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));
                ?>
            </div>
        </div>
    </header>

    <div class="vet-portal-layout-wrapper">