<?php
// ============================================
// 1. SESSION & SECURITY
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

require_once('../config/db.php');

$appointment_id = isset($_GET['appointment_id']) ? (int)$_GET['appointment_id'] : 0;
$vet_id = (int)$_SESSION['user_id'];
$message = "";
$message_type = "success";

// ============================================
// 2. HANDLE FORM SUBMISSIONS
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'save_treatment') {
            $diagnosis = trim($_POST['diagnosis']);
            $treatment = trim($_POST['treatment']);
            $follow_up = !empty($_POST['follow_up']) ? $_POST['follow_up'] : null;

            try {
                $pdo->beginTransaction();
                
                $stmt = $pdo->prepare("INSERT INTO treatment_records (appointment_id, vet_id, diagnosis, treatment, follow_up_date) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$appointment_id, $vet_id, $diagnosis, $treatment, $follow_up]);
                
                $upd = $pdo->prepare("UPDATE appointments SET status = 'completed' WHERE appointment_id = ?");
                $upd->execute([$appointment_id]);
                
                $pdo->commit();
                $message = "✓ Clinical session finalized successfully.";
                $message_type = "success";
                
                // Redirect to avoid form resubmission
                header("Location: " . $_SERVER['REQUEST_URI'] . "&success=1");
                exit;
                
            } catch (PDOException $e) {
                $pdo->rollBack();
                $message = "✗ Error: " . $e->getMessage();
                $message_type = "error";
            }
            
        } elseif ($_POST['action'] === 'cancel_appointment') {
            $reason = trim($_POST['cancellation_reason']);
            $upd = $pdo->prepare("UPDATE appointments SET status = 'cancelled', cancellation_reason = ? WHERE appointment_id = ?");
            $upd->execute([$reason, $appointment_id]);
            header("Location: queue.php?msg=cancelled");
            exit;
        }
    }
}

// Check for success parameter
if (isset($_GET['success']) && $_GET['success'] == 1 && empty($message)) {
    $message = "✓ Clinical session finalized successfully.";
    $message_type = "success";
}

// ============================================
// 3. FETCH APPOINTMENT DATA
// ============================================
$stmt = $pdo->prepare("SELECT a.reason, p.pet_name, u.full_name as owner_name, 
                              a.appointment_date, a.appointment_time,
                              p.species, p.breed, p.age
                       FROM appointments a 
                       JOIN pets p ON a.pet_id = p.pet_id 
                       JOIN users u ON p.owner_id = u.user_id 
                       WHERE a.appointment_id = ?");
$stmt->execute([$appointment_id]);
$apt = $stmt->fetch();

// ============================================
// 4. INCLUDE TEMPLATES
// ============================================
include('includes/header.php');
include('includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Session - Vet Dashboard</title>
    <style>
        /* ============================================
           RESET & BASE LAYOUT
           ============================================ */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
        }

        .content-area {
            margin-left: 260px;
            padding: 30px 40px 40px 40px;
            min-height: 100vh;
            background: #f0f4f8;
        }

        /* ============================================
           PAGE HEADER
           ============================================ */
        .page-header {
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #1a202c;
            margin-bottom: 6px;
        }

        .page-header p {
            color: #718096;
            font-size: 15px;
        }

        /* ============================================
           ALERT / MESSAGE SYSTEM
           ============================================ */
        .alert-container {
            margin-bottom: 25px;
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert {
            padding: 18px 24px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 5px solid;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .alert-success {
            background: #f0fdf4;
            border-left-color: #22c55e;
            color: #166534;
        }

        .alert-success .alert-icon {
            color: #22c55e;
            font-size: 22px;
        }

        .alert-error {
            background: #fef2f2;
            border-left-color: #ef4444;
            color: #991b1b;
        }

        .alert-error .alert-icon {
            color: #ef4444;
            font-size: 22px;
        }

        .alert-close {
            margin-left: auto;
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: inherit;
            opacity: 0.6;
            transition: opacity 0.2s;
            padding: 0 5px;
        }

        .alert-close:hover {
            opacity: 1;
        }

        /* ============================================
           INFO BAR - APPOINTMENT DETAILS
           ============================================ */
        .info-bar {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            background: #ffffff;
            padding: 28px 30px;
            border-radius: 14px;
            border: 1px solid #e2e8f0;
            margin-bottom: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            transition: box-shadow 0.3s;
        }

        .info-bar:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        }

        .info-item {
            display: flex;
            flex-direction: column;
        }

        .info-item .label {
            font-size: 11px;
            text-transform: uppercase;
            color: #94a3b8;
            font-weight: 700;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }

        .info-item .value {
            font-size: 18px;
            color: #0f172a;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-item .value .badge {
            font-size: 11px;
            font-weight: 600;
            padding: 2px 12px;
            border-radius: 20px;
            background: #dbeafe;
            color: #1e40af;
        }

        .info-divider {
            width: 1px;
            background: #e2e8f0;
        }

        /* ============================================
           FORM CARD
           ============================================ */
        .form-card {
            background: #ffffff;
            padding: 40px 45px;
            border-radius: 14px;
            border: 1px solid #e2e8f0;
            max-width: 850px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            transition: box-shadow 0.3s;
        }

        .form-card:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        }

        .form-card-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a202c;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f4f8;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #2d3748;
            font-size: 14px;
        }

        .form-label .required {
            color: #ef4444;
            margin-left: 3px;
        }

        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s;
            background: #fafbfc;
            color: #1a202c;
        }

        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15);
            background: #ffffff;
        }

        .form-control::placeholder {
            color: #a0aec0;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }

        .form-hint {
            font-size: 13px;
            color: #a0aec0;
            margin-top: 5px;
        }

        /* ============================================
           BUTTONS
           ============================================ */
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 10px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 14px 32px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            flex: 1;
            min-width: 180px;
        }

        .btn-submit {
            background: #2563eb;
            color: white;
        }

        .btn-submit:hover {
            background: #1d4ed8;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(37, 99, 235, 0.3);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .btn-cancel {
            background: #ef4444;
            color: white;
        }

        .btn-cancel:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.3);
        }

        .btn-cancel:active {
            transform: translateY(0);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #4a5568;
        }

        .btn-secondary:hover {
            background: #cbd5e1;
        }

        /* ============================================
           DIVIDER
           ============================================ */
        .form-divider {
            margin: 35px 0 30px 0;
            border: 0;
            border-top: 2px dashed #e2e8f0;
            position: relative;
        }

        .form-divider::after {
            content: "OR";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #ffffff;
            padding: 0 20px;
            color: #a0aec0;
            font-weight: 700;
            font-size: 13px;
            letter-spacing: 1px;
        }

        /* ============================================
           RESPONSIVE
           ============================================ */
        @media (max-width: 1024px) {
            .content-area {
                margin-left: 0;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .content-area {
                padding: 15px;
            }

            .form-card {
                padding: 25px;
            }

            .info-bar {
                grid-template-columns: 1fr 1fr;
                padding: 20px;
            }

            .info-divider {
                display: none;
            }

            .btn-group {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                min-width: unset;
            }

            .page-header h1 {
                font-size: 22px;
            }

            .info-item .value {
                font-size: 16px;
            }
        }

        @media (max-width: 480px) {
            .info-bar {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .form-card {
                padding: 20px;
                border-radius: 10px;
            }

            .alert {
                padding: 14px 18px;
                font-size: 14px;
            }
        }

        /* ============================================
           PRINT STYLES
           ============================================ */
        @media print {
            .btn-group {
                display: none;
            }
            .form-card {
                box-shadow: none;
                border: 1px solid #ddd;
            }
            .content-area {
                background: white;
            }
        }
    </style>
</head>
<body>

<div class="content-area">
    
    <!-- ==========================================
    PAGE HEADER
    ========================================== -->
    <div class="page-header">
        <h1>🐾 Clinical Session</h1>
        <p>Document diagnosis, treatment plan, and manage appointment</p>
    </div>

    <!-- ==========================================
    ALERT MESSAGE (VISIBLE ABOVE HEADER)
    ========================================== -->
    <?php if ($message): ?>
    <div class="alert-container">
        <div class="alert alert-<?php echo $message_type; ?>">
            <span class="alert-icon"><?php echo $message_type === 'success' ? '✅' : '⚠️'; ?></span>
            <span><?php echo htmlspecialchars($message); ?></span>
            <button class="alert-close" onclick="this.parentElement.parentElement.style.display='none'">✕</button>
        </div>
    </div>
    <?php endif; ?>

    <!-- ==========================================
    APPOINTMENT INFO BAR
    ========================================== -->
    <div class="info-bar">
        <div class="info-item">
            <span class="label">🐶 Patient</span>
            <span class="value">
                <?php echo htmlspecialchars($apt['pet_name'] ?? 'N/A'); ?>
                <?php if (!empty($apt['species'])): ?>
                <span class="badge"><?php echo htmlspecialchars($apt['species']); ?></span>
                <?php endif; ?>
            </span>
            <?php if (!empty($apt['breed']) || !empty($apt['age'])): ?>
            <span style="font-size: 13px; color: #64748b; margin-top: 3px;">
                <?php echo htmlspecialchars($apt['breed'] ?? ''); ?>
                <?php if (!empty($apt['age'])): ?>
                • <?php echo htmlspecialchars($apt['age']); ?> yrs
                <?php endif; ?>
            </span>
            <?php endif; ?>
        </div>
        
        <div class="info-divider"></div>
        
        <div class="info-item">
            <span class="label">👤 Client</span>
            <span class="value"><?php echo htmlspecialchars($apt['owner_name'] ?? 'N/A'); ?></span>
        </div>
        
        <div class="info-divider"></div>
        
        <div class="info-item">
            <span class="label">📋 Reason</span>
            <span class="value" style="font-size: 15px; font-weight: 500;"><?php echo htmlspecialchars($apt['reason'] ?? 'N/A'); ?></span>
        </div>
        
        <?php if (!empty($apt['appointment_date'])): ?>
        <div class="info-divider"></div>
        <div class="info-item">
            <span class="label">📅 Scheduled</span>
            <span class="value" style="font-size: 15px; font-weight: 500;">
                <?php echo date('M d, Y', strtotime($apt['appointment_date'])); ?>
                <?php if (!empty($apt['appointment_time'])): ?>
                at <?php echo date('g:i A', strtotime($apt['appointment_time'])); ?>
                <?php endif; ?>
            </span>
        </div>
        <?php endif; ?>
    </div>

    <!-- ==========================================
    MAIN FORM
    ========================================== -->
    <div class="form-card">
        <div class="form-card-title">📝 Medical Record</div>
        
        <form method="POST" id="clinicalForm">
            <input type="hidden" name="action" value="save_treatment">
            
            <!-- Diagnosis -->
            <div class="form-group">
                <label class="form-label" for="diagnosis">
                    Clinical Diagnosis <span class="required">*</span>
                </label>
                <textarea 
                    id="diagnosis"
                    name="diagnosis" 
                    class="form-control" 
                    rows="4" 
                    required 
                    placeholder="Describe the diagnosis based on examination findings..."
                ></textarea>
                <div class="form-hint">Provide a clear, concise diagnosis based on clinical findings.</div>
            </div>

            <!-- Treatment Plan -->
            <div class="form-group">
                <label class="form-label" for="treatment">
                    Treatment Plan <span class="required">*</span>
                </label>
                <textarea 
                    id="treatment"
                    name="treatment" 
                    class="form-control" 
                    rows="4" 
                    required 
                    placeholder="Outline the treatment protocol, medications, dosage, and procedures..."
                ></textarea>
                <div class="form-hint">Include medications, dosage, frequency, and any special instructions.</div>
            </div>

            <!-- Follow-up Date -->
            <div class="form-group">
                <label class="form-label" for="follow_up">
                    Follow-up Appointment Date
                </label>
                <input 
                    type="date" 
                    id="follow_up"
                    name="follow_up" 
                    class="form-control"
                    min="<?php echo date('Y-m-d'); ?>"
                >
                <div class="form-hint">Select a date for the next scheduled follow-up, if applicable.</div>
            </div>

            <!-- Action Buttons -->
            <div class="btn-group">
                <button type="submit" class="btn btn-submit">
                    ✅ Finalize Clinical Session
                </button>
            </div>

            <!-- Divider -->
            <hr class="form-divider">

            <!-- Cancellation Section -->
            <div style="margin-top: 10px;">
                <div class="form-group">
                    <label class="form-label" for="cancellation_reason">
                        Cancellation Reason
                    </label>
                    <textarea 
                        id="cancellation_reason"
                        name="cancellation_reason" 
                        class="form-control" 
                        rows="2" 
                        placeholder="Provide reason if cancelling this appointment..."
                    ></textarea>
                    <div class="form-hint">Only required if you need to cancel this appointment.</div>
                </div>

                <button 
                    type="button" 
                    class="btn btn-cancel"
                    onclick="confirmCancellation()"
                >
                    ❌ Cancel Booking
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================
JAVASCRIPT
========================================== -->
<script>
// Auto-dismiss alert after 6 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alertContainer = document.querySelector('.alert-container');
    if (alertContainer) {
        setTimeout(function() {
            alertContainer.style.transition = 'opacity 0.6s';
            alertContainer.style.opacity = '0';
            setTimeout(function() {
                alertContainer.style.display = 'none';
            }, 600);
        }, 6000);
    }
});

// Confirmation dialog for cancellation
function confirmCancellation() {
    const reason = document.getElementById('cancellation_reason').value.trim();
    if (!reason) {
        alert('Please provide a cancellation reason.');
        document.getElementById('cancellation_reason').focus();
        return;
    }
    
    if (confirm('Are you sure you want to cancel this appointment?\n\nReason: ' + reason)) {
        const form = document.getElementById('clinicalForm');
        const actionInput = document.querySelector('input[name="action"]');
        actionInput.value = 'cancel_appointment';
        form.submit();
    }
}

// Set minimum date for follow-up to today
document.addEventListener('DOMContentLoaded', function() {
    const followUpInput = document.getElementById('follow_up');
    if (followUpInput) {
        const today = new Date().toISOString().split('T')[0];
        followUpInput.setAttribute('min', today);
    }
});
</script>

<?php include('includes/footer.php'); ?>
</body>
</html>