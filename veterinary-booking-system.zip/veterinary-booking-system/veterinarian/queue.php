<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as a Veterinary Medical Officer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

require_once('../config/db.php');

$vet_id = (int)$_SESSION['user_id'];
$message = "";

// -------------------------------------------------------------------------
// READ ACTION: FETCH CLINICAL QUEUE
// -------------------------------------------------------------------------
try {
    $queue_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status, a.reason,
                         p.pet_name, p.species, p.breed, u.full_name AS client_name
                  FROM appointments a
                  INNER JOIN pets p ON a.pet_id = p.pet_id
                  INNER JOIN users u ON p.owner_id = u.user_id
                  WHERE a.vet_id = ? AND a.status IN ('pending', 'confirmed')
                  ORDER BY a.appointment_date ASC, a.appointment_time ASC";
    
    $stmt = $pdo->prepare($queue_sql);
    $stmt->execute([$vet_id]);
    $queue = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $queue = [];
    $message = "Database synchronization error: " . $e->getMessage();
}

include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="vet-main-content-canvas">
    <style>
        .page-title-block { margin-bottom: 25px; }
        .queue-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 25px; }
        .queue-table { width: 100%; border-collapse: collapse; }
        .queue-table th { background: #f8fafc; padding: 12px; text-align: left; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
        .queue-table td { padding: 16px 12px; border-bottom: 1px solid #f1f5f9; }
        .action-link { background: #10b981; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px; font-weight: 600; }
        .action-link:hover { background: #059669; }
    </style>

    <div class="page-title-block">
        <h2>Clinical Triage Queue</h2>
        <p>Manage pending appointments and initiate treatment sessions.</p>
    </div>

    <div class="queue-card">
        <?php if (count($queue) > 0): ?>
            <table class="queue-table">
                <thead>
                    <tr>
                        <th>Date / Time</th>
                        <th>Client</th>
                        <th>Patient</th>
                        <th>Reason</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($queue as $row): ?>
                        <tr>
                            <td>
                                <strong><?php echo date('M d, Y', strtotime($row['appointment_date'])); ?></strong><br>
                                <small style="color: #64748b;"><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['client_name']); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong><br>
                                <small><?php echo htmlspecialchars($row['species']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['reason']); ?></td>
                            <td>
                                <a href="treat_patient.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="action-link">Start Session</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center; color: #64748b; padding: 20px;">No patients currently in queue.</p>
        <?php endif; ?>
    </div>
</div>

<?php include('includes/footer.php'); ?>