<?php
// Secure session framework initialization
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not authenticated as a Veterinary Medical Officer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vet') {
    header("Location: ../login.php");
    exit;
}

// Ingest secure database configuration connection
require_once('../config/db.php');

$vet_id = (int)$_SESSION['user_id'];
$message = "";

try {
    // Cross-table optimization query mapping the active session Vet ID to pets and clients
    $query_sql = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status, a.reason, a.notes,
                         p.pet_name, p.species, p.breed, p.age,
                         u_client.full_name AS client_name, u_client.phone AS client_phone, u_client.email AS client_email
                  FROM appointments a
                  INNER JOIN pets p ON a.pet_id = p.pet_id
                  INNER JOIN users u_client ON p.owner_id = u_client.user_id
                  WHERE a.vet_id = ? 
                  ORDER BY a.appointment_date ASC, a.appointment_time ASC";
                  
    $stmt = $pdo->prepare($query_sql);
    $stmt->execute([$vet_id]);
    $assigned_cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $assigned_cases = [];
    $message = "Database connection link error: " . $e->getMessage();
}

// Ingest Vet-specific structural components (Adjust paths if your structure differs)
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="vet-main-content-canvas">

    <style>
        .page-title-block { margin-bottom: 25px; }
        .page-title-block h2 { color: #0f172a; font-size: 24px; font-weight: 700; }
        .page-title-block p { color: #64748b; font-size: 14px; margin-top: 2px; }

        .workspace-card {
            background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0;
            padding: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.01);
        }
        
        /* Layout Grid Matrix Table */
        .case-matrix-table { width: 100%; border-collapse: collapse; font-size: 13.5px; text-align: left; }
        .case-matrix-table th {
            background-color: #f8fafc; color: #64748b; padding: 12px;
            font-weight: 600; font-size: 11.5px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;
        }
        .case-matrix-table td { padding: 14px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
        .case-matrix-table tr:hover { background-color: #f8fafc; }

        /* Status UI Badges framework styling */
        .status-badge {
            display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase;
        }
        .status-badge.pending { background-color: #fef3c7; color: #92400e; }
        .status-badge.confirmed { background-color: #e0e7ff; color: #3730a3; }
        .status-badge.completed { background-color: #d1fae5; color: #065f46; }
        .status-badge.cancelled { background-color: #fee2e2; color: #991b1b; }

        .meta-subtext { font-size: 12px; color: #64748b; margin-top: 3px; }
        .case-notes-block { background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 8px 12px; border-radius: 6px; font-size: 12.5px; margin-top: 4px; color: #475569; }
        .action-link { display: inline-block; padding: 5px 10px; background-color: #10b981; color: white; border-radius: 4px; text-decoration: none; font-weight: 600; font-size: 12px; }
        .action-link:hover { background-color: #059669; }
    </style>

    <div class="page-title-block">
        <h2>My Assigned Patients & Clients</h2>
        <p>Real-time schedule allocation pipeline for cases assigned directly to your medical desk.</p>
    </div>

    <?php if (!empty($message)): ?>
        <div style="padding: 12px; background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; border-radius: 6px; margin-bottom: 20px;">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="workspace-card">
        <?php if (count($assigned_cases) > 0): ?>
            <table class="case-matrix-table">
                <thead>
                    <tr>
                        <th>Schedule parameters</th>
                        <th>Patient (Pet Context)</th>
                        <th>Assigned Client Details</th>
                        <th>Case Clinical Objective</th>
                        <th>Pipeline Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($assigned_cases as $case): ?>
                        <tr>
                            <td>
                                <strong>📅 <?php echo date('M d, Y', strtotime($case['appointment_date'])); ?></strong>
                                <div class="meta-subtext">⏱️ <?php echo date('h:i A', strtotime($case['appointment_time'])); ?></div>
                            </td>

                            <td>
                                <strong style="color: #0f172a; font-size: 14px;">🐾 <?php echo htmlspecialchars(ucfirst($case['pet_name'])); ?></strong>
                                <div class="meta-subtext">
                                    Type: <strong><?php echo htmlspecialchars($case['species']); ?></strong><br>
                                    Breed: <?php echo htmlspecialchars($case['breed'] ?: 'Not Specified'); ?><br>
                                    Age: <?php echo $case['age'] ? $case['age'] . ' Yrs' : 'Unknown'; ?>
                                </div>
                            </td>

                            <td>
                                <strong style="color: #0f172a;">👤 <?php echo htmlspecialchars($case['client_name']); ?></strong>
                                <div class="meta-subtext">
                                    📞 <?php echo htmlspecialchars($case['client_phone']); ?><br>
                                    ✉️ <?php echo htmlspecialchars($case['client_email']); ?>
                                </div>
                            </td>

                            <td>
                                <div><strong>Reason:</strong> <?php echo htmlspecialchars($case['reason']); ?></div>
                                <?php if (!empty($case['notes'])): ?>
                                    <div class="case-notes-block"><strong>Internal Notes:</strong> <?php echo htmlspecialchars($case['notes']); ?></div>
                                <?php endif; ?>
                            </td>

                            <td>
                                <span class="status-badge <?php echo $case['status']; ?>"><?php echo $case['status']; ?></span>
                                <?php if ($case['status'] !== 'completed' && $case['status'] !== 'cancelled'): ?>
                                    <div style="margin-top: 10px;">
                                        <a href="treat_patient.php?appointment_id=<?php echo $case['appointment_id']; ?>" class="action-link">🩺 Attend Case</a>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div style="text-align: center; padding: 50px 20px; color: #94a3b8; font-style: italic;">
                No client or pet assignments are currently mapped onto your veterinary roster layout profile.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php 
include('includes/footer.php'); 
?>